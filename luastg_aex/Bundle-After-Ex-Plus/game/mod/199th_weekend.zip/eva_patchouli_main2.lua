---@diagnostic disable: undefined-field, inject-field
--//白桦「银箔之森纪行」
--//总时长90s

--//思路：（同时对抗类）①开花弹②自机狙③反射弹⑤激光阵⑥设置系（循环往复）

local wait = task.Wait

local function EvaBossOrbitCommon(objE, iniAng, d)
    EvaTask(function()
        local theta = iniAng
        local aSpeed = 0
        local count = 0
        while (IsValid(objE)) do
            local x = 0 + 256 * cos(theta)
            local y = 0 + 160 * sin(theta)
            EvaSetPosition(objE, x, y, 0)
            theta = theta + d * aSpeed
            if(count <= 60) then
                aSpeed = aSpeed + (0.2/60)
            else
                aSpeed =  min(aSpeed + (0.3/720), 0.5)
            end
            count = count + 1
            wait()
        end
    end)
end

function EvaPatchouliMain2(self)
    --针对符卡练习(因为正常流程爱丽丝是在对话里被召唤出来的)
    if(not IsValid(self.aliceObject) and not lstg.tmpvar.MENU_SCPR_MODE )then
        local alice = EvaSummonAlice(self)
        EvaAliceMain(alice, true)
    end
    if(not lstg.tmpvar.MENU_SCPR_MODE and not lstg.tmpvar.packageSet) then
        --针对符卡练习
        SetWorld(0, 0, 640, 480, 90, false)
        EvaClampPlayer()
        EvaDrawFrame()
        local BaseX = -128
        local BaseY = 128
        EvaSetMovePositionBraking01(self, BaseX, BaseY, 60)
    end
    --||||||||||| Main ||||||||||||||||
    self.scRing = EvaCallSCRing(self, 90)
    self.hpText = New(_editor_class["eva_showText"], self.x, self.y, self, "hp", 20)
    wait(90)
    EvaSetMovePositionBraking01(self, 256, 0, 90)
    wait(90)
    EvaCallSE(EVA_SE_CHARGE3)
    EvaLeafConcentration(self, 0, 0, 60, EVA_COLOR_WHITE)
    wait(60)
    EvaBossOrbitCommon(self, 0, -1)
    while true do
        wait(320)
        EvaPatchouliTShotType1(self)
        wait(100)
        EvaPatchouliTShotType2(self)
        wait(270)
    end
end


--||||||||||||||||||||||| 爱丽丝助阵 |||||||||||||||||||||||||

DoFile("eva_alice_anim.lua")

local EvaAliceTCommon

function EvaSummonAlice(objE)
    local alice = EvaSimpleDummyBoss(objE, 256, 320, 2400, EVA_COLOR_YELLOW)
    EvaSetAliceAnimation(alice)
    EvaSetMagicCircle(alice)
    objE.aliceObject = alice
    return alice
end

function EvaAliceMain(alice, is_sc_pr)
    EvaTask(function()
        if(is_sc_pr) then
            EvaAliceTCommon(alice)
            alice.hpText = New(_editor_class["eva_showText"], alice.x, alice.y, alice, "hp", 20)
            EvaCallSCRing(alice, 90)
        end
        local baseX = 128
        local baseY = 128
        local time = is_sc_pr and 60 or 60
        EvaSetMovePositionBraking01(alice, baseX, baseY, time)
        wait(time)
        if(not is_sc_pr) then
            wait(30)
            EvaSetAliceCast(alice, 1, 60)
            wait(16)
            EvaCallSCRing(alice, 90)
            alice.hpText = New(_editor_class["eva_showText"], alice.x, alice.y, alice, "hp", 20)
            EvaAliceTCommon(alice)
        end
        wait(is_sc_pr and 30 or 90)
        EvaSetMovePositionBraking01(alice, -256, 0, 90)
        wait(90)
        EvaCallSE(EVA_SE_CHARGE3)
        EvaLeafConcentration(alice, 0, 0, 60, EVA_COLOR_WHITE)
        wait(60)
        EvaBossOrbitCommon(alice, 180, -1)
        while IsValid(alice.masterBoss) do
            EvaAliceTShotType1(alice, 4)
            wait(400)
            EvaAliceTShotType2(alice)
            wait(320)
        end
    end)
end


function EvaAliceTCommon(alice)
    EvaTask(function()
        while (EvaIsInDialogue()) do
            wait()
        end
        while (IsValid(alice.masterBoss)) do
            alice.hp = alice.masterBoss.hp
            wait()
        end
        local flag = IsValid(alice.masterBoss) --若为true则并非击破而是时间到了
        EvaShakeSTGFrame(10, 20)
        EvaExplosionB2Type(alice.x, alice.y, 30, 3.0, EVA_COLOR_YELLOW)
        Del(alice)
    end)
end