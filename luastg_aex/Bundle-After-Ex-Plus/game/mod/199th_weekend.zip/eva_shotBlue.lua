local sin, cos = sin, cos
local atan2 = atan2
local wait = EvaWait

local EvaTask = EvaTask
local EvaCreateUserShotA2 = EvaCreateUserShotA2
local EvaCreateStraightLaserA1 = EvaCreateStraightLaserA1
local EvaSetLaserLength = EvaSetLaserLength
local EvaSetLaserWidth  = EvaSetLaserWidth
local EvaSetPosition    = EvaSetPosition
local EvaSetAlpha       = EvaSetAlpha
local EvaSetColor       = EvaSetColor
local IsValid           = IsValid
local Del               = Del
local Kill              = Kill
local Angle             = Angle
local ran_Float         = function(a, b) return ran:Float(a, b) end
local ran_Sign          = function() return ran:Sign() end

EvaShotBlueA = {}
EvaShotBlue_Count = 0
EvaShotBlueA_Chosen = 0
EvaShotBlueA_Add = 0
EvaShotBlueA_Reset = {
    EVA_SP1_SHOT_BLUE_01,
    EVA_SP1_SHOT_BLUE_02,
    EVA_SP1_SHOT_BLUE_03,
    EVA_SP1_SHOT_BLUE_04
}

function EvaResetShotBlueArray()
    EvaShotBlueA = CopyArray(EvaShotBlueA_Reset)
end

function EvaGetShotBlueArrayLength()
    return #EvaShotBlueA
end

function EvaEraseShotBlueArray(num)
    table.remove(EvaShotBlueA, num)
end

function EvaEraseShotBlueArray2(num)
    for iQ = 1, EvaGetShotBlueArrayLength() do
        if EvaShotBlueA[iQ] == num then
            table.remove(EvaShotBlueA, iQ)
            break
        end
    end
end

function EvaAddShotBlueArray(num)
    table.insert(EvaShotBlueA, num)
end

function EvaTShotBlue(objE, currentPhase, wt)
    task.New(objE, function()
        wait(wt)
        if(not EvaIsCurrentPhase(currentPhase)) then return end
        local color = EVA_COLOR_BLUE
        local num = ran:Int(1, EvaGetShotBlueArrayLength())
        EvaShotBlueA_Chosen = EvaShotBlueA[num]
        EvaTShotColorNum(EvaShotBlueA[num], objE, currentPhase, color)
        EvaEraseShotBlueArray(num)
        EvaShotBlue_Count = EvaShotBlue_Count + 1
    end)
end

-- |||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||

local EvaTLaser, EvaTShot, EvaLaserAI, EvaTIce2, EvaTIce, EvaIce, EvaIceEffect

function EvaTShotBlueType1(objE, currentPhase, color)
    local way = EvaArray(3, 5, 7, 9, 11)[currentPhase]
    local way2 = EvaArray(1, 1, 2, 2, 2)[currentPhase]
    local alpha = EvaArray(191, 191, 95, 95, 95)[currentPhase]
    local wt = EvaArray(5, 3, 2, 2, 2)[currentPhase]
    local arc = EvaArray(30, 30, 24, 20, 16)[currentPhase]
    local lLeng = EvaArray(100, 110, 120, 135, 150)[currentPhase]
    local bQnt = 4
    local ang = Angle(objE, lstg.player)
    local D = ran_Sign()

    task.New(objE, function ()
        for iW = 0, way - 1 do
            local a = ang + arc * (iW - (way - 1)/2)*D
            EvaTLaser(objE, EvaGetX(objE), EvaGetY(objE), 40, 16, a, 60, lLeng, alpha, true, color, bQnt)
            for iW2 = 1, way2 - 1 do
                EvaTLaser(objE, EvaGetX(objE), EvaGetY(objE), 40, 16, a+1.5*iW2, 60, lLeng, alpha, false, color, bQnt)
                EvaTLaser(objE, EvaGetX(objE), EvaGetY(objE), 40, 16, a-1.5*iW2, 60, lLeng, alpha, false, color, bQnt)
            end
            wait(wt)
        end
    end)
end

function EvaTLaser(objE, x, y, spd, wid, ang, time, lLeng, alpha, flag, color, bQnt)
    local lState = EvaGetScreenLineStates(x, y, 0, ang)
    local tx = lState[1]
    local ty = lState[2]
    local l = lState[3]
    EvaCallSE(EVA_SE_WAVE)
    EvaEffect_LaserWarning2(x, y, ang, wid, 800, 15, alpha, color)
    local objL2 = EvaCreateStraightLaserA1(x, y, ang, l, wid*5, 999999, ADD_BGW_BEAM_ST_RED + color, 999999)
    EvaObjRender_SetColor_ColorNum(objL2, color)
    EvaTask(function ()
        wait(time)
        EvaCallSE(EVA_SE_LASER1)
        local time2 = math.ceil(l/spd)
        local objL = EvaCreateStraightLaserA1(x, y, ang, 0, wid, 999999, ADD_BGW_BALL_M_RED + color, 0)
        for t = 1, time2 do
            if(not IsValid(objE)) then
                Del(objL)
                Del(objL2)
                return
            end
            local rate = (t/time2)
            EvaSetLaserLength(objL, l*rate)
            EvaLaserAI(tx, ty, l*rate, ang, wid, 20, color)
            wait()
        end
        Del(objL2)
        if(flag)then
            EvaTShot(tx, ty, color, lLeng, bQnt)
        end
        EvaSetLaserLength(objL, l)
        --
        for _ = 1, 5 do
            EvaLaserAI(x, y, l, ang, wid, 20, color)
            wait()
        end
        objL.colli = false
        for t = 10, 1, -1 do
            local rate = t/10
            EvaSetLaserWidth(objL, wid*rate)
            wait()
        end
        --
        Del(objL)
    end)
end

function EvaTShot(tx, ty, color, lLeng, bQnt)
    local objS = EvaCreateUserShotA1(tx, ty, 0, 0, ADD_BGW_BALL_M_RED + color, 10)
    EvaExplosionB2Type(tx, ty, 45, 1.0, color)
	EvaExplosionB2Type(tx, ty, 45, 1.5, color)

    local ang2 = 270
    if(tx <= -320) then ang2 = 0
    elseif(tx >= 320) then ang2 = 180
    elseif(ty <= -240) then ang2 = 90
    elseif(ty >= 240) then ang2 = 270 end

    EvaTIce2(objS, tx, ty, ang2, lLeng, 60, bQnt, color)
    task.New(objS, function ()
        task.Wait(15)
        for t = 1, 30 do
            local rate = t/30
            EvaSetPosition(objS, tx +4*rate*cos(ang2), ty +4*rate*sin(ang2), 0)
            ang2 = ang2 + 76
            task.Wait()
        end
        Kill(objS)
    end)
end

function EvaTIce2(objS, x, y, ang, leng, time, bQnt, color)
    local D = ran_Sign()
    for _ = 1, 15 do
        leng = leng * 0.85
    end
    EvaTask(function ()
        for iQ = 14, 0, -1 do
            if(not IsValid(objS))then return end
            local l = leng/75*(14-iQ)
            local l2 = leng/150*iQ*D
            leng = leng/0.85
            EvaTIce(x+l*cos(ang)+l2*cos(ang+90), y+l*sin(ang)+l2*sin(ang+90), ang+4*iQ*D, leng, time-(14-iQ), color)
            D = -D
            wait()
        end
        wait(time - 15)
        local bWay = 2
        local bArc = 15
        local bSpd = 2.0
        local bLeng = 30
        for iQ = bQnt - 1, 0, -1 do
            local rate2 = 1 - 0.15*iQ
            local bS2 = bSpd*(1 - 0.02*iQ)
            for iW = bWay - 1, 1, -1 do
                local rate = 1 - 0.3*iW/(bWay - 1)
                local aa = bArc*iW/(bWay - 1)
                local a1 = ang + aa + ran_Float(-0.5, 0.5)
                local a2 = ang - aa + ran_Float(-0.5, 0.5)
                local bS = bS2 * rate
                local bLeng2 = bLeng*rate*rate2
                EvaCreateUserShotA2(x+bLeng2*cos(a1), y+bLeng2*sin(a1), 0, a1, bS/50, bS, BGW_ICE_RED + color, 10)
                EvaCreateUserShotA2(x+bLeng2*cos(a2), y+bLeng2*sin(a2), 0, a2, bS/50, bS, BGW_ICE_RED + color, 10)
            end
            local bLeng2 = bLeng * rate2
            local a = ang + ran_Float(-0.5, 0.5)
            EvaCreateUserShotA2(x+bLeng2*cos(a), y+bLeng2*sin(a), 0, a, bS2/50, bS2, BGW_ICE_RED + color, 10)
        end
    end)
end

function EvaTIce(x, y, ang, leng, time, color)
    local objL = EvaCreateStraightLaserA1(x, y, ang, leng, leng*1.0, time, ADD_BGW_ICE_RED + color, 99999)
    task.New(objL, function ()
        task.Wait(time)
        EvaCallSE(EVA_SE_SHOT4)
        EvaCallSE(EVA_SE_FREEZE)
        EvaIce(x, y, ang, leng, leng*0.4, 30, color)
        Del(objL)
    end)
end

-- |||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||

local EvaTShot2, EvaCrystal

function EvaTShotBlueType2(objE, currentPhase, color)
    local way = EvaArray(6, 8, 10, 8, 14)[currentPhase]
	local spd = EvaArray(2.4, 3.0, 3.6, 4.8, 7.2)[currentPhase]
	local qnt = EvaArray(1, 1, 1, 2, 2)[currentPhase]
	local ang = Angle(objE, lstg.player)
	local bQnt = 3
	local bSpd = 1.5
	local D = ran_Sign()

    EvaTask(function()
        for iW = 0, way - 1 do
            if(not IsValid(objE)) then return end
            EvaCallSE(EVA_SE_SHOT3)
            for iQ = 0, qnt - 1 do
                local s = spd*(1-0.4*iQ)
                EvaTShot2(EvaGetX(objE), EvaGetY(objE), s, ang+360*(iW+(1/qnt)*iQ-(way-1)/2)/way*D, bQnt, bSpd, color)
            end
            wait(2)
        end
    end)
end

function EvaTShot2(x, y, spd, ang, bQnt, bSpd, color)
    local graphic = ADD_BGW_BALL_M_RED + color
    local objS = EvaCreateUserShotA2(x, y, spd, ang, -spd/60, 0, graphic, 10)

    EvaTask(function()
        wait(60)

        -- 这里用局部，把 EvaGetX/Y 的结果存下来
        local tx = EvaGetX(objS)
        local ty = EvaGetY(objS)
        local ang2 = ran_Float(0, 360)

        for t = 1, 30 do
            local rate = t * (1/30) -- 避免每次除法
            local dx = 4 * rate * cos(ang2)
            local dy = 4 * rate * sin(ang2)
            EvaSetPosition(objS, tx + dx, ty + dy, 0)
            ang2 = ang2 + 76
            wait()
        end

        EvaCrystal(tx, ty, 80, Angle(objS, lstg.player), bQnt, bSpd, color)
        Kill(objS)
    end)
end

function EvaCrystal(x, y, leng, ang, bQnt, bSpd, color)
    if(ang == -9999) then ang = atan2(lstg.player.y - y, lstg.player.x - x) end
    EvaCallSE(EVA_SE_SHOT4)
    EvaCallSE(EVA_SE_FREEZE)
    for iW = 0, 5 do
        local a = ang + 60*iW
        EvaIce(x, y, a   , leng     , leng*0.40, 30, color)
        EvaIce(x, y, a+15, leng*0.50, leng*0.20, 30, color)
        EvaIce(x, y, a+30, leng*0.75, leng*0.30, 30, color)
        EvaIce(x, y, a+45, leng*0.50, leng*0.20, 30, color)
        for iQ = bQnt - 1, 0, -1 do
            local s = bSpd*(1-0.03*iQ)
            EvaCreateUserShotA2(x, y, 0, a   +ran_Float(-0.5, 0.5), s*0.02     , s     , BGW_ICE_RED + color, 10)
            EvaCreateUserShotA2(x, y, 0, a+30+ran_Float(-0.5, 0.5), s*0.02*0.75, s*0.75, BGW_ICE_RED + color, 10)
        end
    end
end

-- |||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||

local EvaTShotBlueType3_TShot

function EvaTShotBlueType3(objE, currentPhase, color)
    local way = EvaArray(4, 5, 7, 8, 10)[currentPhase]
	local arc = 360/(way*2+1)
	local wt = EvaArray(5, 5, 4, 4, 3)[currentPhase]
	local r = 10
	local spd = 3
	local ang = Angle(objE, lstg.player)
	local lSpd = 30

    EvaTask(function()
        EvaTShotBlueType3_TShot(EvaGetX(objE) + r*cos(ang), EvaGetY(objE) + r*sin(ang), spd, ang, lSpd, color)
        wait(wt)
        for iW = 1, way do
            if(not IsValid(objE)) then return end
            local a = ang+arc*iW
            local a2 = ang-arc*iW
            local sRate = 1.0+0.25*iW/way
            EvaTShotBlueType3_TShot(EvaGetX(objE) +  r*cos(a), EvaGetY(objE) +  r*sin(a), spd*sRate, a, lSpd*sRate, color)
            EvaTShotBlueType3_TShot(EvaGetX(objE) + r*cos(a2), EvaGetY(objE) + r*sin(a2), spd*sRate, a2, lSpd*sRate, color)
            wait(wt)
        end
    end)
end

function EvaTShotBlueType3_TShot(x, y, spd, ang, lSpd, color)
    local objS = EvaCreateUserShotA1(x, y, spd, ang, ADD_BGW_BALL_M_RED + color, 10)
    local lState = EvaGetScreenLineStates(x, y, 0, ang);
    local c = math.ceil(lState[3]/spd)
    EvaTask(function()
        while true do
            if(not IsValid(objS)) then return end
			if(c<=0) then break end
			EvaIce(EvaGetX(objS), EvaGetY(objS), ang + ran_Float(-15,15), 60, 24, 30, color)
			for _ = 1, 4 do
				if(c<=0) then break end
				c = c - 1
				wait(1)
			end
        end
        if(not IsValid(objS)) then return end
        Del(objS)
        EvaCallSE(EVA_SE_SHOT3)
		if(lState[1] <= -320) then ang = 180-ang
        elseif(lState[1] >= 320) then ang = 180-ang
        elseif(lState[2] >=  240) then ang = 360-ang
        elseif(lState[2] <= -240) then ang = 360-ang end
        for iQ = 0, 2 do
            EvaEffect_LaserWarning3(lState[1], lState[2], ang, 16, 800, 18, 15, 63+32*iQ, color)
            wait(15)
        end
        EvaCallSE(EVA_SE_LASER1)
		local objS2 = EvaCreateUserShotA1(lState[1], lState[2], 20, ang, ADD_BGW_BALL_M_RED + color, 10)
		while(not EvaIsOutScreen(EvaGetX(objS2), EvaGetY(objS2), 32) and IsValid(objS2)) do
			EvaIce(EvaGetX(objS2), EvaGetY(objS2), ang + ran_Float(-7.5,7.5), 60, 24, 20, color)
			wait(1)
		end
		Kill(objS2)
    end)
end

-- |||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||

local EvaTShotBlueType4_TLaser

function EvaTShotBlueType4(objE, currentPhase, color)
    local way_arr = {4, 4, 6, 8, 12}
    local wt_arr = {8, 6, 5, 4, 2}
    local bWay_arr = {32, 40, 32, 32, 40}
    local bSpd_arr = {1.2, 1.2, 1.2, 1.2, 1.2}

    local way = way_arr[currentPhase]
    local wt = wt_arr[currentPhase]
    local spd = 12
    local time = 30
    local bWay = bWay_arr[currentPhase]
    local bSpd = bSpd_arr[currentPhase]
    local ang = Angle(objE, lstg.player)

    EvaTask(function()
        for iW = 0, way - 1 do
            if(not IsValid(objE)) then return end
            EvaCallSE(EVA_SE_SHOT5)
            EvaTShotBlueType4_TLaser(objE, EvaGetX(objE), EvaGetY(objE), spd, ang+360*(iW+0.5)/way, bWay, bSpd, color, time)
            wait(wt)
        end
    end)
end

function EvaTShotBlueType4_TLaser(objE, x, y, spd, ang, bWay, bSpd, color, time)
    local lState = EvaGetScreenLineStates(x, y, 0, ang);
    local tx = lState[1]
    local ty = lState[2]
    local l = lState[3]
    EvaCallSE(EVA_SE_WAVE)
    EvaEffect_LaserWarning2(x, y, ang, 32, 800, 12, 255, color)
    local objL2 = EvaCreateStraightLaserA1(x, y, ang, 800, 16, 999999, ADD_BGW_BEAM_ST_RED + color, 999999)
    EvaObjRender_SetColor_ColorNum(objL2, color)
    EvaTask(function()
        wait(time)
        if(not IsValid(objE)) then
			Del(objL2)
			return
		end
        local time2 = math.ceil(l/spd)
		local objS = EvaCreateUserShotA1(x, y, spd, ang, ADD_BGW_BALL_M_RED + color, 10);
		objS.colli = false
        objS.hide = true
        while true do
            if(not IsValid(objS)) then Del(objL2) return end
			if(time2<=0) then break end
			EvaIce(EvaGetX(objS), EvaGetY(objS), ang + ran_Float(-15,15), spd*6, spd*3.6, 75, color)
			for _ = 1, 2 do
				if(time2<=0) then break end
				time2 = time2 - 1
				EvaSetPosition(objL2, EvaGetX(objS), EvaGetY(objS), 0)
				wait(1)
			end
        end
        if(not IsValid(objS) or ty <= -240) then Del(objL2) return end
		EvaCallSE(EVA_SE_SHOT5)
		local bAng = ran_Float(0, 360)
		for iW = 0, bWay - 1 do
			local bS = bSpd*(1-0.2*(iW%2))
			EvaCreateUserShotA2(tx, ty, 0, bAng+360*iW/bWay, bS/100, bS, ADD_BGW_BALL_M_RED + color, 10)
		end
		Del(objL2)
		Del(objS)
    end)
end

-- |||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||

function EvaLaserAI(x, y, leng, ang, wid, time, color)
    local objLaser = EvaCreateStraightLaserA1(x, y, ang, leng, wid*10, 99999, ADD_BGW_BALL_M_RED + color, 99999)
    EvaTask(function ()
        for t = time, 1, -1 do
            if not IsValid(objLaser) then return end
            local alpha = 127*t/time
            EvaSetAlpha(objLaser, alpha)
            wait()
        end
        Del(objLaser)
    end)
end


function EvaIce(x, y, ang, lLeng, lWid, time, color)
    local objL = EvaCreateStraightLaserA1(x, y, ang, lLeng, lWid, time+30, ADD_BGW_ICE_RED + color, 0)
    EvaIceEffect(x, y, ang, lLeng, lWid, 20, color)
    EvaSetAlpha(objL, 191)
    EvaObjRender_SetColor_ColorNum(objL, color)
    objL.ratioX = 0.25
    objL.ratioY = 0.5

    local time2 = 10

    EvaTask(function ()
        for t = 1, time2 do
            if not IsValid(objL) then return end
            local rate = t/time2
            EvaSetLaserLength(objL, lLeng*rate)
            EvaSetLaserWidth(objL, lWid*rate)
            wait()
        end
        wait(time - 10)
        if not IsValid(objL) then return end
        objL.colli = false
        time2 = 15
        for t = time2, 1, -1 do
            if not IsValid(objL) then return end
            local rate = t/time2
            EvaSetPosition(objL, x + lLeng * (1 - rate) * cos(ang), y + lLeng*(1-rate)*sin(ang))
            EvaSetAlpha(objL, 191*rate)
            EvaSetLaserLength(objL, lLeng * rate)
            EvaSetLaserWidth(objL, lWid * rate)
            wait()
        end
        if not IsValid(objL) then return end
        Del(objL)
    end)
end

local EvaObjRender_SetColor_ColorNum_Ex, EvaGetColorArray_Ex

function EvaIceEffect(x, y, angle, leng, wid, time, color)
    local objL = EvaCreateStraightLaserA1(x, y, angle, 0, 2*wid, 30, ADD_BGW_ICE_RED + color, 0, true)
    EvaObjRender_SetColor_ColorNum_Ex(objL, color)
    EvaTask(function()
        for t = 1, time do
            if not IsValid(objL) then return end
            local rate = t/time
            EvaSetLaserLength(objL, leng + 2 * leng * rate)
            EvaSetLaserWidth(objL, 3 * wid * (1 - rate))
            EvaSetAlpha(objL, 191 * (1 - rate))
            wait()
        end
        if not IsValid(objL) then return end
        Del(objL)
    end)
end

function EvaObjRender_SetColor_ColorNum_Ex(obj, colorNum)
    local c = EvaGetColorArray_Ex(colorNum)
    EvaSetColor(obj, c[1], c[2], c[3])
end

function EvaGetColorArray_Ex(colorNum)
    local color = {159, 159, 159}
    local cal = colorNum%8
    if(cal == EVA_COLOR_RED)    then color = {255, 127, 127} end
    if(cal == EVA_COLOR_GREEN)  then color = {127, 255, 127} end
    if(cal == EVA_COLOR_BLUE)   then color = {127, 127, 255} end
    if(cal == EVA_COLOR_YELLOW) then color = {255, 255, 127} end
    if(cal == EVA_COLOR_PURPLE) then color = {255, 127, 255} end
    if(cal == EVA_COLOR_AQUA)   then color = {127, 255, 255} end
    if(cal == EVA_COLOR_ORANGE) then color = {255, 127, 63}  end
    return color
end