EVA_SE_SHOT1 =			0
EVA_SE_SHOT2 =			1
EVA_SE_SHOT3 =			2
EVA_SE_SHOT4 =			3
EVA_SE_SHOT5 =			4
EVA_SE_SHOT6 =			5
EVA_SE_SHOT7 =			6
EVA_SE_FIRE1 =			7
EVA_SE_FIRE2 =			8
EVA_SE_WAVE =			9
EVA_SE_NUCLEAR =		10
EVA_SE_STOP =			11
EVA_SE_LASER1 =			12
EVA_SE_LASER2 =			13
EVA_SE_LASER3 =			14
EVA_SE_MSP =			15
EVA_SE_CHARGE1 =		16
EVA_SE_CHARGE2 =		17
EVA_SE_CHARGE3 =		18
EVA_SE_FREEZE =			19
EVA_SE_ROAR =			20
EVA_SE_BOSS_VANISH =	21
EVA_SE_USE_SPELL =		22
EVA_SE_SPELL_FAILED = 	23
EVA_SE_GAIN_SPELL =		24
EVA_SE_VANISH1 =		25
EVA_SE_DAMAGE1 =		26
EVA_SE_DAMAGE2 =		27

function EvaCallSE(ID, volume, target)
    volume = volume or 1.0
    local pan = IsValid(target) and (target.x/448) or 0
    PlaySound("EVA_SE"..ID, volume, pan)
end