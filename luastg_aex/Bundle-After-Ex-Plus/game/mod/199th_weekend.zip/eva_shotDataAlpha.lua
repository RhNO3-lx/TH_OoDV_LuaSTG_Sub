---@diagnostic disable: undefined-field
local data = {}
local data_n = 1

function EvaNewShotData(tab)
    data[data_n] = tab
    data_n = data_n + 1
end


----------------------------------------------------------------------------------------------------------------
	--　BALL_S　丸弾
	
	--　黒透過
	EvaNewShotData{	id = 1		,rect = {0,112,16,128}		,delay_color = {255,32,32}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	EvaNewShotData{	id = 2		,rect = {16,112,32,128}		,delay_color = {32,255,32}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	EvaNewShotData{	id = 3		,rect = {32,112,48,128}		,delay_color = {32,32,255}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	EvaNewShotData{	id = 4		,rect = {48,112,64,128}		,delay_color = {255,255,32}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	EvaNewShotData{	id = 5		,rect = {64,112,80,128}		,delay_color = {255,32,255}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	EvaNewShotData{	id = 6		,rect = {80,112,96,128}		,delay_color = {32,255,255}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	EvaNewShotData{	id = 7		,rect = {96,112,112,128}		,delay_color = {255,128,32}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	EvaNewShotData{	id = 8		,rect = {112,112,128,128}	,delay_color = {255,255,255}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	
	--　黒透過ナシ
	EvaNewShotData{	id = 9		,rect = {128,112,144,128}	,delay_color = {255,32,32}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	EvaNewShotData{	id = 10		,rect = {144,112,160,128}	,delay_color = {32,255,32}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	EvaNewShotData{	id = 11		,rect = {160,112,176,128}	,delay_color = {32,32,255}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	EvaNewShotData{	id = 12		,rect = {176,112,192,128}	,delay_color = {255,255,32}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	EvaNewShotData{	id = 13		,rect = {192,112,208,128}	,delay_color = {255,32,255}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	EvaNewShotData{	id = 14		,rect = {208,112,224,128}	,delay_color = {32,255,255}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	EvaNewShotData{	id = 15		,rect = {224,112,240,128}	,delay_color = {255,128,32}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	EvaNewShotData{	id = 16		,rect = {240,112,256,128}	,delay_color = {255,255,255}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　02　中丸弾
	
	EvaNewShotData{	id = 17		,rect = {0,192,32,224}		,delay_color = {255,32,32}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	EvaNewShotData{	id = 18		,rect = {32,192,64,224}		,delay_color = {32,255,32}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	EvaNewShotData{	id = 19		,rect = {64,192,96,224}		,delay_color = {32,32,255}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	EvaNewShotData{	id = 20		,rect = {96,192,128,224}		,delay_color = {255,255,32}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	EvaNewShotData{	id = 21		,rect = {128,192,160,224}	,delay_color = {255,32,255}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	EvaNewShotData{	id = 22		,rect = {160,192,192,224}	,delay_color = {32,255,255}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	EvaNewShotData{	id = 23		,rect = {192,192,224,224}	,delay_color = {255,128,32}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	EvaNewShotData{	id = 24		,rect = {224,192,256,224}	,delay_color = {255,255,255}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　03　大弾
	
	EvaNewShotData{	id = 25		,rect = {0,448,64,512}		,delay_color = {255,32,32}	,render = EVA_BLEND_ALPHA	,angular_velocity = 128	}
	EvaNewShotData{	id = 26		,rect = {64,448,128,512}		,delay_color = {32,255,32}	,render = EVA_BLEND_ALPHA	,angular_velocity = 128	}
	EvaNewShotData{	id = 27		,rect = {128,448,192,512}	,delay_color = {32,32,255}	,render = EVA_BLEND_ALPHA	,angular_velocity = 128	}
	EvaNewShotData{	id = 28		,rect = {192,448,256,512}	,delay_color = {255,255,32}	,render = EVA_BLEND_ALPHA	,angular_velocity = 128	}
	EvaNewShotData{	id = 29		,rect = {0,512,64,576}		,delay_color = {255,32,255}	,render = EVA_BLEND_ALPHA	,angular_velocity = 128	}
	EvaNewShotData{	id = 30		,rect = {64,512,128,576}		,delay_color = {32,255,255}	,render = EVA_BLEND_ALPHA	,angular_velocity = 128	}
	EvaNewShotData{	id = 31		,rect = {128,512,192,576}	,delay_color = {255,128,32}	,render = EVA_BLEND_ALPHA	,angular_velocity = 128	}
	EvaNewShotData{	id = 32		,rect = {192,512,256,576}	,delay_color = {255,255,255}	,render = EVA_BLEND_ALPHA	,angular_velocity = 128	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　04　二重丸弾
	
	--　黒透過
	EvaNewShotData{	id = 33		,rect = {0,128,16,144}		,delay_color = {255,32,32}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	EvaNewShotData{	id = 34		,rect = {16,128,32,144}		,delay_color = {32,255,32}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	EvaNewShotData{	id = 35		,rect = {32,128,48,144}		,delay_color = {32,32,255}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	EvaNewShotData{	id = 36		,rect = {48,128,64,144}		,delay_color = {255,255,32}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	EvaNewShotData{	id = 37		,rect = {64,128,80,144}		,delay_color = {255,32,255}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	EvaNewShotData{	id = 38		,rect = {80,128,96,144}		,delay_color = {32,255,255}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	EvaNewShotData{	id = 39		,rect = {96,128,112,144}		,delay_color = {255,128,32}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	EvaNewShotData{	id = 40		,rect = {112,128,128,144}	,delay_color = {255,255,255}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	
	--　黒透過ナシ
	EvaNewShotData{	id = 41		,rect = {128,128,144,144}	,delay_color = {255,32,32}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	EvaNewShotData{	id = 42		,rect = {144,128,160,144}	,delay_color = {32,255,32}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	EvaNewShotData{	id = 43		,rect = {160,128,176,144}	,delay_color = {32,32,255}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	EvaNewShotData{	id = 44		,rect = {176,128,192,144}	,delay_color = {255,255,32}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	EvaNewShotData{	id = 45		,rect = {192,128,208,144}	,delay_color = {255,32,255}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	EvaNewShotData{	id = 46		,rect = {208,128,224,144}	,delay_color = {32,255,255}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	EvaNewShotData{	id = 47		,rect = {224,128,240,144}	,delay_color = {255,128,32}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	EvaNewShotData{	id = 48		,rect = {240,128,256,144}	,delay_color = {255,255,255}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　05　小弾
	
	--　黒透過
	EvaNewShotData{	id = 49		,rect = {0,320,8,328}		,delay_color = {255,32,32}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	EvaNewShotData{	id = 50		,rect = {8,320,16,328}		,delay_color = {32,255,32}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	EvaNewShotData{	id = 51		,rect = {16,320,24,328}		,delay_color = {32,32,255}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	EvaNewShotData{	id = 52		,rect = {24,320,32,328}		,delay_color = {255,255,32}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	EvaNewShotData{	id = 53		,rect = {32,320,40,328}		,delay_color = {255,32,255}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	EvaNewShotData{	id = 54		,rect = {40,320,48,328}		,delay_color = {32,255,255}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	EvaNewShotData{	id = 55		,rect = {48,320,56,328}		,delay_color = {255,128,32}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	EvaNewShotData{	id = 56		,rect = {56,320,64,328}		,delay_color = {255,255,255}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	
	--　黒透過ナシ
	EvaNewShotData{	id = 57		,rect = {64,320,72,328}		,delay_color = {255,32,32}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	EvaNewShotData{	id = 58		,rect = {72,320,80,328}		,delay_color = {32,255,32}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	EvaNewShotData{	id = 59		,rect = {80,320,88,328}		,delay_color = {32,32,255}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	EvaNewShotData{	id = 60		,rect = {88,320,96,328}		,delay_color = {255,255,32}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	EvaNewShotData{	id = 61		,rect = {96,320,104,328}		,delay_color = {255,32,255}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	EvaNewShotData{	id = 62		,rect = {104,320,112,328}	,delay_color = {32,255,255}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	EvaNewShotData{	id = 63		,rect = {112,320,120,328}	,delay_color = {255,128,32}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	EvaNewShotData{	id = 64		,rect = {120,320,128,328}	,delay_color = {255,255,255}	,render = EVA_BLEND_ALPHA, fixed_angle = true	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　06　菌弾
	
	--　黒透過
	EvaNewShotData{	id = 65		,rect = {0,432,16,448}		,delay_color = {255,32,32}	,render = EVA_BLEND_ALPHA	,angular_velocity = ran:Float(-8,8)	,collision = 2	}
	EvaNewShotData{	id = 66		,rect = {16,432,32,448}		,delay_color = {32,255,32}	,render = EVA_BLEND_ALPHA	,angular_velocity = ran:Float(-8,8)	,collision = 2	}
	EvaNewShotData{	id = 67		,rect = {32,432,48,448}		,delay_color = {32,32,255}	,render = EVA_BLEND_ALPHA	,angular_velocity = ran:Float(-8,8)	,collision = 2	}
	EvaNewShotData{	id = 68		,rect = {48,432,64,448}		,delay_color = {255,255,32}	,render = EVA_BLEND_ALPHA	,angular_velocity = ran:Float(-8,8)	,collision = 2	}
	EvaNewShotData{	id = 69		,rect = {64,432,80,448}		,delay_color = {255,32,255}	,render = EVA_BLEND_ALPHA	,angular_velocity = ran:Float(-8,8)	,collision = 2	}
	EvaNewShotData{	id = 70		,rect = {80,432,96,448}		,delay_color = {32,255,255}	,render = EVA_BLEND_ALPHA	,angular_velocity = ran:Float(-8,8)	,collision = 2	}
	EvaNewShotData{	id = 71		,rect = {96,432,112,448}		,delay_color = {255,128,32}	,render = EVA_BLEND_ALPHA	,angular_velocity = ran:Float(-8,8)	,collision = 2	}
	EvaNewShotData{	id = 72		,rect = {112,432,128,448}	,delay_color = {255,255,255}	,render = EVA_BLEND_ALPHA	,angular_velocity = ran:Float(-8,8)	,collision = 2	}
	
	--　黒透過ナシ
	EvaNewShotData{	id = 73		,rect = {128,432,144,448}	,delay_color = {255,32,32}	,render = EVA_BLEND_ALPHA	,angular_velocity = ran:Float(-8,8)	,collision = 2	}
	EvaNewShotData{	id = 74		,rect = {144,432,160,448}	,delay_color = {32,255,32}	,render = EVA_BLEND_ALPHA	,angular_velocity = ran:Float(-8,8)	,collision = 2	}
	EvaNewShotData{	id = 75		,rect = {160,432,176,448}	,delay_color = {32,32,255}	,render = EVA_BLEND_ALPHA	,angular_velocity = ran:Float(-8,8)	,collision = 2	}
	EvaNewShotData{	id = 76		,rect = {176,432,192,448}	,delay_color = {255,255,32}	,render = EVA_BLEND_ALPHA	,angular_velocity = ran:Float(-8,8)	,collision = 2	}
	EvaNewShotData{	id = 77		,rect = {192,432,208,448}	,delay_color = {255,32,255}	,render = EVA_BLEND_ALPHA	,angular_velocity = ran:Float(-8,8)	,collision = 2	}
	EvaNewShotData{	id = 78		,rect = {208,432,224,448}	,delay_color = {32,255,255}	,render = EVA_BLEND_ALPHA	,angular_velocity = ran:Float(-8,8)	,collision = 2	}
	EvaNewShotData{	id = 79		,rect = {224,432,240,448}	,delay_color = {255,128,32}	,render = EVA_BLEND_ALPHA	,angular_velocity = ran:Float(-8,8)	,collision = 2	}
	EvaNewShotData{	id = 80		,rect = {240,432,256,448}	,delay_color = {255,255,255}	,render = EVA_BLEND_ALPHA	,angular_velocity = ran:Float(-8,8)	,collision = 2	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　07　銃弾
	
	--　黒透過
	EvaNewShotData{	id = 81		,rect = {0,32,16,48}			,delay_color = {255,32,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 82		,rect = {16,32,32,48}		,delay_color = {32,255,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 83		,rect = {32,32,48,48}		,delay_color = {32,32,255}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 84		,rect = {48,32,64,48}		,delay_color = {255,255,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 85		,rect = {64,32,80,48}		,delay_color = {255,32,255}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 86		,rect = {80,32,96,48}		,delay_color = {32,255,255}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 87		,rect = {96,32,112,48}		,delay_color = {255,128,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 88		,rect = {112,32,128,48}		,delay_color = {255,255,255}	,render = EVA_BLEND_ALPHA	}
	
	--　黒透過ナシ
	EvaNewShotData{	id = 89		,rect = {128,32,144,48}		,delay_color = {255,32,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 90		,rect = {144,32,160,48}		,delay_color = {32,255,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 91		,rect = {160,32,176,48}		,delay_color = {32,32,255}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 92		,rect = {176,32,192,48}		,delay_color = {255,255,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 93		,rect = {192,32,208,48}		,delay_color = {255,32,255}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 94		,rect = {208,32,224,48}		,delay_color = {32,255,255}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 95		,rect = {224,32,240,48}		,delay_color = {255,128,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 96		,rect = {240,32,256,48}		,delay_color = {255,255,255}	,render = EVA_BLEND_ALPHA	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　08　米弾
	
	--　黒透過
	EvaNewShotData{	id = 97		,rect = {0,16,16,32}			,delay_color = {255,32,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 98		,rect = {16,16,32,32}		,delay_color = {32,255,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 99		,rect = {32,16,48,32}		,delay_color = {32,32,255}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 100	,rect = {48,16,64,32}		,delay_color = {255,255,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 101	,rect = {64,16,80,32}		,delay_color = {255,32,255}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 102	,rect = {80,16,96,32}		,delay_color = {32,255,255}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 103	,rect = {96,16,112,32}		,delay_color = {255,128,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 104	,rect = {112,16,128,32}		,delay_color = {255,255,255}	,render = EVA_BLEND_ALPHA	}
	
	--　黒透過ナシ
	EvaNewShotData{	id = 105	,rect = {128,16,144,32}		,delay_color = {255,32,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 106	,rect = {144,16,160,32}		,delay_color = {32,255,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 107	,rect = {160,16,176,32}		,delay_color = {32,32,255}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 108	,rect = {176,16,192,32}		,delay_color = {255,255,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 109	,rect = {192,16,208,32}		,delay_color = {255,32,255}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 110	,rect = {208,16,224,32}		,delay_color = {32,255,255}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 111	,rect = {224,16,240,32}		,delay_color = {255,128,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 112	,rect = {240,16,256,32}		,delay_color = {255,255,255}	,render = EVA_BLEND_ALPHA	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　09　星弾
	
	--　黒透過
	EvaNewShotData{	id = 113	,rect = {0,64,16,80}			,delay_color = {255,32,32}	,render = EVA_BLEND_ALPHA	,angular_velocity = 5	}
	EvaNewShotData{	id = 114	,rect = {16,64,32,80}		,delay_color = {32,255,32}	,render = EVA_BLEND_ALPHA	,angular_velocity = 5	}
	EvaNewShotData{	id = 115	,rect = {32,64,48,80}		,delay_color = {32,32,255}	,render = EVA_BLEND_ALPHA	,angular_velocity = 5	}
	EvaNewShotData{	id = 116	,rect = {48,64,64,80}		,delay_color = {255,255,32}	,render = EVA_BLEND_ALPHA	,angular_velocity = 5	}
	EvaNewShotData{	id = 117	,rect = {64,64,80,80}		,delay_color = {255,32,255}	,render = EVA_BLEND_ALPHA	,angular_velocity = 5	}
	EvaNewShotData{	id = 118	,rect = {80,64,96,80}		,delay_color = {32,255,255}	,render = EVA_BLEND_ALPHA	,angular_velocity = 5	}
	EvaNewShotData{	id = 119	,rect = {96,64,112,80}		,delay_color = {255,128,32}	,render = EVA_BLEND_ALPHA	,angular_velocity = 5	}
	EvaNewShotData{	id = 120	,rect = {112,64,128,80}		,delay_color = {255,255,255}	,render = EVA_BLEND_ALPHA	,angular_velocity = 5	}
	
	--　黒透過ナシ
	EvaNewShotData{	id = 121	,rect = {128,64,144,80}		,delay_color = {255,32,32}	,render = EVA_BLEND_ALPHA	,angular_velocity = 5	}
	EvaNewShotData{	id = 122	,rect = {144,64,160,80}		,delay_color = {32,255,32}	,render = EVA_BLEND_ALPHA	,angular_velocity = 5	}
	EvaNewShotData{	id = 123	,rect = {160,64,176,80}		,delay_color = {32,32,255}	,render = EVA_BLEND_ALPHA	,angular_velocity = 5	}
	EvaNewShotData{	id = 124	,rect = {176,64,192,80}		,delay_color = {255,255,32}	,render = EVA_BLEND_ALPHA	,angular_velocity = 5	}
	EvaNewShotData{	id = 125	,rect = {192,64,208,80}		,delay_color = {255,32,255}	,render = EVA_BLEND_ALPHA	,angular_velocity = 5	}
	EvaNewShotData{	id = 126	,rect = {208,64,224,80}		,delay_color = {32,255,255}	,render = EVA_BLEND_ALPHA	,angular_velocity = 5	}
	EvaNewShotData{	id = 127	,rect = {224,64,240,80}		,delay_color = {255,128,32}	,render = EVA_BLEND_ALPHA	,angular_velocity = 5	}
	EvaNewShotData{	id = 128	,rect = {240,64,256,80}		,delay_color = {255,255,255}	,render = EVA_BLEND_ALPHA	,angular_velocity = 5	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　10　クナイ弾
	
	--　黒透過
	EvaNewShotData{	id = 129	,rect = {0,0,16,16}			,delay_color = {255,32,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 130	,rect = {16,0,32,16}			,delay_color = {32,255,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 131	,rect = {32,0,48,16}			,delay_color = {32,32,255}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 132	,rect = {48,0,64,16}			,delay_color = {255,255,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 133	,rect = {64,0,80,16}			,delay_color = {255,32,255}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 134	,rect = {80,0,96,16}			,delay_color = {32,255,255}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 135	,rect = {96,0,112,16}		,delay_color = {255,128,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 136	,rect = {112,0,128,16}		,delay_color = {255,255,255}	,render = EVA_BLEND_ALPHA	}
	
	--　黒透過ナシ
	EvaNewShotData{	id = 137	,rect = {128,0,144,16}		,delay_color = {255,32,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 138	,rect = {144,0,160,16}		,delay_color = {32,255,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 139	,rect = {160,0,176,16}		,delay_color = {32,32,255}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 140	,rect = {176,0,192,16}		,delay_color = {255,255,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 141	,rect = {192,0,208,16}		,delay_color = {255,32,255}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 142	,rect = {208,0,224,16}		,delay_color = {32,255,255}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 143	,rect = {224,0,240,16}		,delay_color = {255,128,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 144	,rect = {240,0,256,16}		,delay_color = {255,255,255}	,render = EVA_BLEND_ALPHA	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　11　細弾
	
	--　黒透過
	EvaNewShotData{	id = 145	,rect = {0,144,16,160}		,delay_color = {255,32,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 146	,rect = {16,144,32,160}		,delay_color = {32,255,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 147	,rect = {32,144,48,160}		,delay_color = {32,32,255}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 148	,rect = {48,144,64,160}		,delay_color = {255,255,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 149	,rect = {64,144,80,160}		,delay_color = {255,32,255}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 150	,rect = {80,144,96,160}		,delay_color = {32,255,255}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 151	,rect = {96,144,112,160}		,delay_color = {255,128,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 152	,rect = {112,144,128,160}	,delay_color = {255,255,255}	,render = EVA_BLEND_ALPHA	}
	
	--　黒透過ナシ
	EvaNewShotData{	id = 153	,rect = {128,144,144,160}	,delay_color = {255,32,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 154	,rect = {144,144,160,160}	,delay_color = {32,255,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 155	,rect = {160,144,176,160}	,delay_color = {32,32,255}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 156	,rect = {176,144,192,160}	,delay_color = {255,255,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 157	,rect = {192,144,208,160}	,delay_color = {255,32,255}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 158	,rect = {208,144,224,160}	,delay_color = {32,255,255}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 159	,rect = {224,144,240,160}	,delay_color = {255,128,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 160	,rect = {240,144,256,160}	,delay_color = {255,255,255}	,render = EVA_BLEND_ALPHA	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　12　札弾
	
	--　黒透過
	EvaNewShotData{	id = 161	,rect = {0,96,16,112}		,delay_color = {255,32,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 162	,rect = {16,96,32,112}		,delay_color = {32,255,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 163	,rect = {32,96,48,112}		,delay_color = {32,32,255}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 164	,rect = {48,96,64,112}		,delay_color = {255,255,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 165	,rect = {64,96,80,112}		,delay_color = {255,32,255}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 166	,rect = {80,96,96,112}		,delay_color = {32,255,255}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 167	,rect = {96,96,112,112}		,delay_color = {255,128,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 168	,rect = {112,96,128,112}		,delay_color = {255,255,255}	,render = EVA_BLEND_ALPHA	}
	
	--　黒透過ナシ
	EvaNewShotData{	id = 169	,rect = {128,96,144,112}		,delay_color = {255,32,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 170	,rect = {144,96,160,112}		,delay_color = {32,255,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 171	,rect = {160,96,176,112}		,delay_color = {32,32,255}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 172	,rect = {176,96,192,112}		,delay_color = {255,255,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 173	,rect = {192,96,208,112}		,delay_color = {255,32,255}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 174	,rect = {208,96,224,112}		,delay_color = {32,255,255}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 175	,rect = {224,96,240,112}		,delay_color = {255,128,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 176	,rect = {240,96,256,112}		,delay_color = {255,255,255}	,render = EVA_BLEND_ALPHA	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　13　ゾウリムシ弾　（永琳奴）
	
	--　黒透過
	EvaNewShotData{	id = 177	,rect = {0,48,16,64}			,delay_color = {255,32,32}	,render = EVA_BLEND_ALPHA	,collision = 1	}
	EvaNewShotData{	id = 178	,rect = {16,48,32,64}		,delay_color = {32,255,32}	,render = EVA_BLEND_ALPHA	,collision = 1	}
	EvaNewShotData{	id = 179	,rect = {32,48,48,64}		,delay_color = {32,32,255}	,render = EVA_BLEND_ALPHA	,collision = 1	}
	EvaNewShotData{	id = 180	,rect = {48,48,64,64}		,delay_color = {255,255,32}	,render = EVA_BLEND_ALPHA	,collision = 1	}
	EvaNewShotData{	id = 181	,rect = {64,48,80,64}		,delay_color = {255,32,255}	,render = EVA_BLEND_ALPHA	,collision = 1	}
	EvaNewShotData{	id = 182	,rect = {80,48,96,64}		,delay_color = {32,255,255}	,render = EVA_BLEND_ALPHA	,collision = 1	}
	EvaNewShotData{	id = 183	,rect = {96,48,112,64}		,delay_color = {255,128,32}	,render = EVA_BLEND_ALPHA	,collision = 1	}
	EvaNewShotData{	id = 184	,rect = {112,48,128,64}		,delay_color = {255,255,255}	,render = EVA_BLEND_ALPHA	,collision = 1	}
	
	--　黒透過ナシ
	EvaNewShotData{	id = 185	,rect = {128,48,144,64}		,delay_color = {255,32,32}	,render = EVA_BLEND_ALPHA	,collision = 1	}
	EvaNewShotData{	id = 186	,rect = {144,48,160,64}		,delay_color = {32,255,32}	,render = EVA_BLEND_ALPHA	,collision = 1	}
	EvaNewShotData{	id = 187	,rect = {160,48,176,64}		,delay_color = {32,32,255}	,render = EVA_BLEND_ALPHA	,collision = 1	}
	EvaNewShotData{	id = 188	,rect = {176,48,192,64}		,delay_color = {255,255,32}	,render = EVA_BLEND_ALPHA	,collision = 1	}
	EvaNewShotData{	id = 189	,rect = {192,48,208,64}		,delay_color = {255,32,255}	,render = EVA_BLEND_ALPHA	,collision = 1	}
	EvaNewShotData{	id = 190	,rect = {208,48,224,64}		,delay_color = {32,255,255}	,render = EVA_BLEND_ALPHA	,collision = 1	}
	EvaNewShotData{	id = 191	,rect = {224,48,240,64}		,delay_color = {255,128,32}	,render = EVA_BLEND_ALPHA	,collision = 1	}
	EvaNewShotData{	id = 192	,rect = {240,48,256,64}		,delay_color = {255,255,255}	,render = EVA_BLEND_ALPHA	,collision = 1	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　14　鱗弾
	
	--　黒透過
	EvaNewShotData{	id = 193	,rect = {0,80,16,96}			,delay_color = {255,32,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 194	,rect = {16,80,32,96}		,delay_color = {32,255,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 195	,rect = {32,80,48,96}		,delay_color = {32,32,255}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 196	,rect = {48,80,64,96}		,delay_color = {255,255,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 197	,rect = {64,80,80,96}		,delay_color = {255,32,255}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 198	,rect = {80,80,96,96}		,delay_color = {32,255,255}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 199	,rect = {96,80,112,96}		,delay_color = {255,128,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 200	,rect = {112,80,128,96}		,delay_color = {255,255,255}	,render = EVA_BLEND_ALPHA	}
	
	--　黒透過ナシ
	EvaNewShotData{	id = 201	,rect = {128,80,144,96}		,delay_color = {255,32,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 202	,rect = {144,80,160,96}		,delay_color = {32,255,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 203	,rect = {160,80,176,96}		,delay_color = {32,32,255}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 204	,rect = {176,80,192,96}		,delay_color = {255,255,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 205	,rect = {192,80,208,96}		,delay_color = {255,32,255}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 206	,rect = {208,80,224,96}		,delay_color = {32,255,255}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 207	,rect = {224,80,240,96}		,delay_color = {255,128,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 208	,rect = {240,80,256,96}		,delay_color = {255,255,255}	,render = EVA_BLEND_ALPHA	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　15　大星弾
	
	EvaNewShotData{	id = 209	,rect = {0,160,32,192}		,delay_color = {255,32,32}	,render = EVA_BLEND_ALPHA	,angular_velocity = 5	}
	EvaNewShotData{	id = 210	,rect = {32,160,64,192}		,delay_color = {32,255,32}	,render = EVA_BLEND_ALPHA	,angular_velocity = 5	}
	EvaNewShotData{	id = 211	,rect = {64,160,96,192}		,delay_color = {32,32,255}	,render = EVA_BLEND_ALPHA	,angular_velocity = 5	}
	EvaNewShotData{	id = 212	,rect = {96,160,128,192}		,delay_color = {255,255,32}	,render = EVA_BLEND_ALPHA	,angular_velocity = 5	}
	EvaNewShotData{	id = 213	,rect = {128,160,160,192}	,delay_color = {255,32,255}	,render = EVA_BLEND_ALPHA	,angular_velocity = 5	}
	EvaNewShotData{	id = 214	,rect = {160,160,192,192}	,delay_color = {32,255,255}	,render = EVA_BLEND_ALPHA	,angular_velocity = 5	}
	EvaNewShotData{	id = 215	,rect = {192,160,224,192}	,delay_color = {255,128,32}	,render = EVA_BLEND_ALPHA	,angular_velocity = 5	}
	EvaNewShotData{	id = 216	,rect = {224,160,256,192}	,delay_color = {255,255,255}	,render = EVA_BLEND_ALPHA	,angular_velocity = 5	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　16　蝶弾
	
	EvaNewShotData{	id = 217	,rect = {0,224,32,256}		,delay_color = {255,32,32}	,render = EVA_BLEND_ALPHA	,collision = {4,0,0}	}
	EvaNewShotData{	id = 218	,rect = {32,224,64,256}		,delay_color = {32,255,32}	,render = EVA_BLEND_ALPHA	,collision = {4,0,0}	}
	EvaNewShotData{	id = 219	,rect = {64,224,96,256}		,delay_color = {32,32,255}	,render = EVA_BLEND_ALPHA	,collision = {4,0,0}	}
	EvaNewShotData{	id = 220	,rect = {96,224,128,256}		,delay_color = {255,255,32}	,render = EVA_BLEND_ALPHA	,collision = {4,0,0}	}
	EvaNewShotData{	id = 221	,rect = {128,224,160,256}	,delay_color = {255,32,255}	,render = EVA_BLEND_ALPHA	,collision = {4,0,0}	}
	EvaNewShotData{	id = 222	,rect = {160,224,192,256}	,delay_color = {32,255,255}	,render = EVA_BLEND_ALPHA	,collision = {4,0,0}	}
	EvaNewShotData{	id = 223	,rect = {192,224,224,256}	,delay_color = {255,128,32}	,render = EVA_BLEND_ALPHA	,collision = {4,0,0}	}
	EvaNewShotData{	id = 224	,rect = {224,224,256,256}	,delay_color = {255,255,255}	,render = EVA_BLEND_ALPHA	,collision = {4,0,0}	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　17　ナイフ弾
	
	EvaNewShotData{	id = 225	,rect = {0,256,32,288}		,delay_color = {255,32,32}	,render = EVA_BLEND_ALPHA	,collision = {3,0,4}	}
	EvaNewShotData{	id = 226	,rect = {32,256,64,288}		,delay_color = {32,255,32}	,render = EVA_BLEND_ALPHA	,collision = {3,0,4}	}
	EvaNewShotData{	id = 227	,rect = {64,256,96,288}		,delay_color = {32,32,255}	,render = EVA_BLEND_ALPHA	,collision = {3,0,4}	}
	EvaNewShotData{	id = 228	,rect = {96,256,128,288}		,delay_color = {255,255,32}	,render = EVA_BLEND_ALPHA	,collision = {3,0,4}	}
	EvaNewShotData{	id = 229	,rect = {128,256,160,288}	,delay_color = {255,32,255}	,render = EVA_BLEND_ALPHA	,collision = {3,0,4}	}
	EvaNewShotData{	id = 230	,rect = {160,256,192,288}	,delay_color = {32,255,255}	,render = EVA_BLEND_ALPHA	,collision = {3,0,4}	}
	EvaNewShotData{	id = 231	,rect = {192,256,224,288}	,delay_color = {255,128,32}	,render = EVA_BLEND_ALPHA	,collision = {3,0,4}	}
	EvaNewShotData{	id = 232	,rect = {224,256,256,288}	,delay_color = {255,255,255}	,render = EVA_BLEND_ALPHA	,collision = {3,0,4}	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　18　グミ弾
	
	EvaNewShotData{	id = 233	,rect = {0,289,32,319}		,delay_color = {255,32,32}	,render = EVA_BLEND_ALPHA	,collision = 4	}
	EvaNewShotData{	id = 234	,rect = {32,289,64,319}		,delay_color = {32,255,32}	,render = EVA_BLEND_ALPHA	,collision = 4	}
	EvaNewShotData{	id = 235	,rect = {64,289,96,319}		,delay_color = {32,32,255}	,render = EVA_BLEND_ALPHA	,collision = 4	}
	EvaNewShotData{	id = 236	,rect = {96,289,128,319}		,delay_color = {255,255,32}	,render = EVA_BLEND_ALPHA	,collision = 4	}
	EvaNewShotData{	id = 237	,rect = {128,289,160,319}	,delay_color = {255,32,255}	,render = EVA_BLEND_ALPHA	,collision = 4	}
	EvaNewShotData{	id = 238	,rect = {160,289,192,319}	,delay_color = {32,255,255}	,render = EVA_BLEND_ALPHA	,collision = 4	}
	EvaNewShotData{	id = 239	,rect = {192,289,224,319}	,delay_color = {255,128,32}	,render = EVA_BLEND_ALPHA	,collision = 4	}
	EvaNewShotData{	id = 240	,rect = {224,289,256,319}	,delay_color = {255,255,255}	,render = EVA_BLEND_ALPHA	,collision = 4	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　19　ハート弾
	
	EvaNewShotData{	id = 241	,rect = {256,0,288,32}	,delay_color = {255,32,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 242	,rect = {288,0,320,32}	,delay_color = {32,255,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 243	,rect = {320,0,352,32}	,delay_color = {32,32,255}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 244	,rect = {352,0,384,32}	,delay_color = {255,255,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 245	,rect = {384,0,416,32}	,delay_color = {255,32,255}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 246	,rect = {416,0,448,32}	,delay_color = {32,255,255}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 247	,rect = {448,0,480,32}	,delay_color = {255,128,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 248	,rect = {480,0,512,32}	,delay_color = {255,255,255}	,render = EVA_BLEND_ALPHA	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　20　矢弾
	
	EvaNewShotData{	id = 249	,rect = {256,32,288,64}	,delay_color = {255,32,32}	,render = EVA_BLEND_ALPHA	,collision = {2,0,8}	}
	EvaNewShotData{	id = 250	,rect = {288,32,320,64}	,delay_color = {32,255,32}	,render = EVA_BLEND_ALPHA	,collision = {2,0,8}	}
	EvaNewShotData{	id = 251	,rect = {320,32,352,64}	,delay_color = {32,32,255}	,render = EVA_BLEND_ALPHA	,collision = {2,0,8}	}
	EvaNewShotData{	id = 252	,rect = {352,32,384,64}	,delay_color = {255,255,32}	,render = EVA_BLEND_ALPHA	,collision = {2,0,8}	}
	EvaNewShotData{	id = 253	,rect = {384,32,416,64}	,delay_color = {255,32,255}	,render = EVA_BLEND_ALPHA	,collision = {2,0,8}	}
	EvaNewShotData{	id = 254	,rect = {416,32,448,64}	,delay_color = {32,255,255}	,render = EVA_BLEND_ALPHA	,collision = {2,0,8}	}
	EvaNewShotData{	id = 255	,rect = {448,32,480,64}	,delay_color = {255,128,32}	,render = EVA_BLEND_ALPHA	,collision = {2,0,8}	}
	EvaNewShotData{	id = 256	,rect = {480,32,512,64}	,delay_color = {255,255,255}	,render = EVA_BLEND_ALPHA	,collision = {2,0,8}	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　21　神霊弾の元
	
	EvaNewShotData{	id = 257	,rect = {256,96,288,128}	,delay_color = {255,32,32}	,render = EVA_BLEND_ALPHA	,collision = 6	}
	EvaNewShotData{	id = 258	,rect = {288,96,320,128}	,delay_color = {32,255,32}	,render = EVA_BLEND_ALPHA	,collision = 6	}
	EvaNewShotData{	id = 259	,rect = {320,96,352,128}	,delay_color = {32,32,255}	,render = EVA_BLEND_ALPHA	,collision = 6	}
	EvaNewShotData{	id = 260	,rect = {352,96,384,128}	,delay_color = {255,255,32}	,render = EVA_BLEND_ALPHA	,collision = 6	}
	EvaNewShotData{	id = 261	,rect = {384,96,416,128}	,delay_color = {255,32,255}	,render = EVA_BLEND_ALPHA	,collision = 6	}
	EvaNewShotData{	id = 262	,rect = {416,96,448,128}	,delay_color = {32,255,255}	,render = EVA_BLEND_ALPHA	,collision = 6	}
	EvaNewShotData{	id = 263	,rect = {448,96,480,128}	,delay_color = {255,128,32}	,render = EVA_BLEND_ALPHA	,collision = 6	}
	EvaNewShotData{	id = 264	,rect = {480,96,512,128}	,delay_color = {255,255,255}	,render = EVA_BLEND_ALPHA	,collision = 6	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　22　神霊弾
	
	EvaNewShotData{	id = 265	,rect = {260,132,316,188}	,delay_color = {255,32,32}	,render = EVA_BLEND_ALPHA	,collision = 15	}
	EvaNewShotData{	id = 266	,rect = {324,132,380,188}	,delay_color = {32,255,32}	,render = EVA_BLEND_ALPHA	,collision = 15	}
	EvaNewShotData{	id = 267	,rect = {388,132,444,188}	,delay_color = {32,32,255}	,render = EVA_BLEND_ALPHA	,collision = 15	}
	EvaNewShotData{	id = 268	,rect = {452,132,508,188}	,delay_color = {255,255,32}	,render = EVA_BLEND_ALPHA	,collision = 15	}
	EvaNewShotData{	id = 269	,rect = {260,196,316,252}	,delay_color = {255,32,255}	,render = EVA_BLEND_ALPHA	,collision = 15	}
	EvaNewShotData{	id = 270	,rect = {324,196,380,252}	,delay_color = {32,255,255}	,render = EVA_BLEND_ALPHA	,collision = 15	}
	EvaNewShotData{	id = 271	,rect = {388,196,444,252}	,delay_color = {255,128,32}	,render = EVA_BLEND_ALPHA	,collision = 15	}
	EvaNewShotData{	id = 272	,rect = {452,196,508,252}	,delay_color = {255,255,255}	,render = EVA_BLEND_ALPHA	,collision = 15	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　23　サニーレーザーの先っちょ
	
	EvaNewShotData{	id = 273	,rect = {256,384,288,416}	,delay_color = {255,32,32}	,render = EVA_BLEND_ALPHA	,angular_velocity = 6	}
	EvaNewShotData{	id = 274	,rect = {288,384,320,416}	,delay_color = {32,255,32}	,render = EVA_BLEND_ALPHA	,angular_velocity = 6	}
	EvaNewShotData{	id = 275	,rect = {320,384,352,416}	,delay_color = {32,32,255}	,render = EVA_BLEND_ALPHA	,angular_velocity = 6	}
	EvaNewShotData{	id = 276	,rect = {352,384,384,416}	,delay_color = {255,255,32}	,render = EVA_BLEND_ALPHA	,angular_velocity = 6	}
	EvaNewShotData{	id = 277	,rect = {384,384,416,416}	,delay_color = {255,32,255}	,render = EVA_BLEND_ALPHA	,angular_velocity = 6	}
	EvaNewShotData{	id = 278	,rect = {416,384,448,416}	,delay_color = {32,255,255}	,render = EVA_BLEND_ALPHA	,angular_velocity = 6	}
	EvaNewShotData{	id = 279	,rect = {448,384,480,416}	,delay_color = {255,128,32}	,render = EVA_BLEND_ALPHA	,angular_velocity = 6	}
	EvaNewShotData{	id = 280	,rect = {480,384,512,416}	,delay_color = {255,255,255}	,render = EVA_BLEND_ALPHA	,angular_velocity = 6	}
	
	--　階調反転
	EvaNewShotData{	id = 281	,rect = {256,416,288,448}	,delay_color = {255,32,32}	,render = EVA_BLEND_ALPHA	,angular_velocity = 6	}
	EvaNewShotData{	id = 282	,rect = {288,416,320,448}	,delay_color = {32,255,32}	,render = EVA_BLEND_ALPHA	,angular_velocity = 6	}
	EvaNewShotData{	id = 283	,rect = {320,416,352,448}	,delay_color = {32,32,255}	,render = EVA_BLEND_ALPHA	,angular_velocity = 6	}
	EvaNewShotData{	id = 284	,rect = {352,416,384,448}	,delay_color = {255,255,32}	,render = EVA_BLEND_ALPHA	,angular_velocity = 6	}
	EvaNewShotData{	id = 285	,rect = {384,416,416,448}	,delay_color = {255,32,255}	,render = EVA_BLEND_ALPHA	,angular_velocity = 6	}
	EvaNewShotData{	id = 286	,rect = {416,416,448,448}	,delay_color = {32,255,255}	,render = EVA_BLEND_ALPHA	,angular_velocity = 6	}
	EvaNewShotData{	id = 287	,rect = {448,416,480,448}	,delay_color = {255,128,32}	,render = EVA_BLEND_ALPHA	,angular_velocity = 6	}
	EvaNewShotData{	id = 288	,rect = {480,416,512,448}	,delay_color = {255,255,255}	,render = EVA_BLEND_ALPHA	,angular_velocity = 6	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　FIRE　炎弾
	EvaNewShotData{
		id = 289
		,delay_color = {255,32,32}
		,render = EVA_BLEND_ALPHA
		,collision = 4
		,AnimationData={
			{4, 256, 256, 288, 288 },
			{4, 256, 288, 288, 320 },
			{4, 256, 320, 288, 352 },
			{4, 256, 352, 288, 384 },
		}
	}
	EvaNewShotData{
		id = 290
		,delay_color = {32,255,32}
		,render = EVA_BLEND_ALPHA
		,collision = 4
		,AnimationData={
			{4, 288, 256, 320, 288 },
			{4, 288, 288, 320, 320 },
			{4, 288, 320, 320, 352 },
			{4, 288, 352, 320, 384 },
		}
	}
	EvaNewShotData{
		id = 291
		,delay_color = {32,32,255}
		,render = EVA_BLEND_ALPHA
		,collision = 4
		,AnimationData={
			{4, 320, 256, 352, 288 },
			{4, 320, 288, 352, 320 },
			{4, 320, 320, 352, 352 },
			{4, 320, 352, 352, 384 },
		}
	}
	EvaNewShotData{
		id = 292
		,delay_color = {255,255,32}
		,render = EVA_BLEND_ALPHA
		,collision = 4
		,AnimationData={
			{4, 352, 256, 384, 288 },
			{4, 352, 288, 384, 320 },
			{4, 352, 320, 384, 352 },
			{4, 352, 352, 384, 384 },
		}
	}
	EvaNewShotData{
		id = 293
		,delay_color = {255,32,255}
		,render = EVA_BLEND_ALPHA
		,collision = 4
		,AnimationData={
			{4, 384, 256, 416, 288 },
			{4, 384, 288, 416, 320 },
			{4, 384, 320, 416, 352 },
			{4, 384, 352, 416, 384 },
		}
	}
	EvaNewShotData{
		id = 294
		,delay_color = {32,255,255}
		,render = EVA_BLEND_ALPHA
		,collision = 4
		,AnimationData={
			{4, 416, 256, 448, 288 },
			{4, 416, 288, 448, 320 },
			{4, 416, 320, 448, 352 },
			{4, 416, 352, 448, 384 },
		}
	}
	EvaNewShotData{
		id = 295
		,delay_color = {255,128,32}
		,render = EVA_BLEND_ALPHA
		,collision = 4
		,AnimationData={
			{4, 448, 256, 480, 288 },
			{4, 448, 288, 480, 320 },
			{4, 448, 320, 480, 352 },
			{4, 448, 352, 480, 384 },
		}
	}
	EvaNewShotData{
		id = 296
		,delay_color = {255,255,255}
		,render = EVA_BLEND_ALPHA
		,collision = 4
		,AnimationData={
			{4, 480, 256, 512, 288 },
			{4, 480, 288, 512, 320 },
			{4, 480, 320, 512, 352 },
			{4, 480, 352, 512, 384 },
		}
	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　WATER　水滴弾
	
	--　黒透過
	EvaNewShotData{	id = 297	,rect = {  0,416, 16,432}	,delay_color = {255,32,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 298	,rect = { 16,416, 32,432}	,delay_color = {32,255,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 299	,rect = { 32,416, 48,432}	,delay_color = {32,32,255}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 300	,rect = { 48,416, 64,432}	,delay_color = {255,255,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 301	,rect = { 64,416, 80,432}	,delay_color = {255,32,255}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 302	,rect = { 80,416, 96,432}	,delay_color = {32,255,255}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 303	,rect = { 96,416,112,432}	,delay_color = {255,128,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 304	,rect = {112,416,128,432}	,delay_color = {255,255,255}	,render = EVA_BLEND_ALPHA	}
	
	--　黒透過ナシ
	EvaNewShotData{	id = 305	,rect = {128,416,144,432}	,delay_color = {255,32,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 306	,rect = {144,416,160,432}	,delay_color = {32,255,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 307	,rect = {160,416,176,432}	,delay_color = {32,32,255}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 308	,rect = {176,416,192,432}	,delay_color = {255,255,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 309	,rect = {192,416,208,432}	,delay_color = {255,32,255}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 310	,rect = {208,416,224,432}	,delay_color = {32,255,255}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 311	,rect = {224,416,240,432}	,delay_color = {255,128,32}	,render = EVA_BLEND_ALPHA	}
	EvaNewShotData{	id = 312	,rect = {240,416,256,432}	,delay_color = {255,255,255}	,render = EVA_BLEND_ALPHA	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　29　金弾　回転　-8,8
	
	EvaNewShotData{	id = 313	,rect = {128,320,144,336}	,delay_color = {255,32,32}	,render = EVA_BLEND_ALPHA	,angular_velocity = 6	}
	EvaNewShotData{	id = 314	,rect = {144,320,160,336}	,delay_color = {32,255,32}	,render = EVA_BLEND_ALPHA	,angular_velocity = 6	}
	EvaNewShotData{	id = 315	,rect = {160,320,176,336}	,delay_color = {32,32,255}	,render = EVA_BLEND_ALPHA	,angular_velocity = 6	}
	EvaNewShotData{	id = 316	,rect = {176,320,192,336}	,delay_color = {255,255,32}	,render = EVA_BLEND_ALPHA	,angular_velocity = 6	}
	EvaNewShotData{	id = 317	,rect = {192,320,208,336}	,delay_color = {255,32,255}	,render = EVA_BLEND_ALPHA	,angular_velocity = 6	}
	EvaNewShotData{	id = 318	,rect = {208,320,224,336}	,delay_color = {32,255,255}	,render = EVA_BLEND_ALPHA	,angular_velocity = 6	}
	EvaNewShotData{	id = 319	,rect = {224,320,240,336}	,delay_color = {255,128,32}	,render = EVA_BLEND_ALPHA	,angular_velocity = 6	}
	EvaNewShotData{	id = 320	,rect = {240,320,256,336}	,delay_color = {255,255,255}	,render = EVA_BLEND_ALPHA	,angular_velocity = 6	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　30　へにょり用
	
	EvaNewShotData{	id = 321	,rect = {256,64,288,96}	,delay_color = {255,32,32}	,render = EVA_BLEND_ALPHA	,collision = 1;	}
	EvaNewShotData{	id = 322	,rect = {288,64,320,96}	,delay_color = {32,255,32}	,render = EVA_BLEND_ALPHA	,collision = 1;	}
	EvaNewShotData{	id = 323	,rect = {320,64,352,96}	,delay_color = {32,32,255}	,render = EVA_BLEND_ALPHA	,collision = 1;	}
	EvaNewShotData{	id = 324	,rect = {352,64,384,96}	,delay_color = {255,255,32}	,render = EVA_BLEND_ALPHA	,collision = 1;	}
	EvaNewShotData{	id = 325	,rect = {384,64,416,96}	,delay_color = {255,32,255}	,render = EVA_BLEND_ALPHA	,collision = 1;	}
	EvaNewShotData{	id = 326	,rect = {416,64,448,96}	,delay_color = {32,255,255}	,render = EVA_BLEND_ALPHA	,collision = 1;	}
	EvaNewShotData{	id = 327	,rect = {448,64,480,96}	,delay_color = {255,128,32}	,render = EVA_BLEND_ALPHA	,collision = 1;	}
	EvaNewShotData{	id = 328	,rect = {480,64,512,96}	,delay_color = {255,255,255}	,render = EVA_BLEND_ALPHA	,collision = 1;	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　31　音符弾
	EvaNewShotData{
		id = 329
		,delay_color = {255,32,32}
		,render = EVA_BLEND_ALPHA
		,collision = {3,-1,-9}
		,fixed_angle = true
		,AnimationData={
			{ 8, 0, 576, 32, 608 },
			{ 8, 0, 608, 32, 640 },
			{ 8, 0, 640, 32, 672 },
			{ 8, 0, 672, 32, 704 },
		}
	}
	EvaNewShotData{
		id = 330
		,delay_color = {32,255,32}
		,render = EVA_BLEND_ALPHA
		,collision = {3,-1,-9}
		,fixed_angle = true
		,AnimationData={
			{ 8, 32, 576, 64, 608 },
			{ 8, 32, 608, 64, 640 },
			{ 8, 32, 640, 64, 672 },
			{ 8, 32, 672, 64, 704 },
		}
	}
	EvaNewShotData{
		id = 331
		,delay_color = {32,32,255}
		,render = EVA_BLEND_ALPHA
		,collision = {3,-1,-9}
		,fixed_angle = true
		,AnimationData={
			{ 8, 64, 576, 96, 608 },
			{ 8, 64, 608, 96, 640 },
			{ 8, 64, 640, 96, 672 },
			{ 8, 64, 672, 96, 704 },
		}
	}
	EvaNewShotData{
		id = 332
		,delay_color = {255,255,32}
		,render = EVA_BLEND_ALPHA
		,collision = {3,-1,-9}
		,fixed_angle = true
		,AnimationData={
			{ 8, 96, 576, 128, 608 },
			{ 8, 96, 608, 128, 640 },
			{ 8, 96, 640, 128, 672 },
			{ 8, 96, 672, 128, 704 },
		}
	}
	EvaNewShotData{
		id = 333
		,delay_color = {255,32,255}
		,render = EVA_BLEND_ALPHA
		,collision = {3,-1,-9}
		,fixed_angle = true
		,AnimationData={
			{ 8, 128, 576, 160, 608 },
			{ 8, 128, 608, 160, 640 },
			{ 8, 128, 640, 160, 672 },
			{ 8, 128, 672, 160, 704 },
		}
	}
	EvaNewShotData{
		id = 334
		,delay_color = {32,255,255}
		,render = EVA_BLEND_ALPHA
		,collision = {3,-1,-9}
		,fixed_angle = true
		,AnimationData={
			{ 8, 160, 576, 192, 608 },
			{ 8, 160, 608, 192, 640 },
			{ 8, 160, 640, 192, 672 },
			{ 8, 160, 672, 192, 704 },
		}
	}
	EvaNewShotData{
		id = 335
		,delay_color = {255,128,32}
		,render = EVA_BLEND_ALPHA
		,collision = {3,-1,-9}
		,fixed_angle = true
		,AnimationData={
			{ 8, 192, 576, 224, 608 },
			{ 8, 192, 608, 224, 640 },
			{ 8, 192, 640, 224, 672 },
			{ 8, 192, 672, 224, 704 },
		}
	}
	EvaNewShotData{
		id = 336
		,delay_color = {255,255,255}
		,render = EVA_BLEND_ALPHA
		,collision = {3,-1,-9}
		,fixed_angle = true
		,AnimationData={
			{ 8, 224, 576, 256, 608 },
			{ 8, 224, 608, 256, 640 },
			{ 8, 224, 640, 256, 672 },
			{ 8, 224, 672, 256, 704 },
		}
	}

	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　BEAM_ST　直線レーザー用
	EvaNewShotData{
		id = 337
		,delay_color = {255,32,32}
		,render = EVA_BLEND_ALPHA
		,AnimationData={
			{ 4, 0, 354, 32, 382 },
			{ 4, 0, 386, 32, 414 },
		}
	}
	EvaNewShotData{
		id = 338
		,delay_color = {32,255,32}
		,render = EVA_BLEND_ALPHA
		,AnimationData={
			{ 4, 32, 354, 64, 382 },
			{ 4, 32, 386, 64, 414 },
		}
	}
	EvaNewShotData{
		id = 339
		,delay_color = {32,32,255}
		,render = EVA_BLEND_ALPHA
		,AnimationData={
			{ 4, 64, 354, 96, 382 },
			{ 4, 64, 386, 96, 414 },
		}
	}
	EvaNewShotData{
		id = 340
		,delay_color = {255,255,32}
		,render = EVA_BLEND_ALPHA
		,AnimationData={
			{ 8, 96, 354, 128, 382 },
			{ 8, 96, 386, 128, 414 },
		}
	}
	EvaNewShotData{
		id = 341
		,delay_color = {255,32,255}
		,render = EVA_BLEND_ALPHA
		,AnimationData={
			{ 8, 128, 354, 160, 382 },
			{ 8, 128, 386, 160, 414 },
		}
	}
	EvaNewShotData{
		id = 342
		,delay_color = {32,255,255}
		,render = EVA_BLEND_ALPHA
		,AnimationData={
			{ 8, 160, 354, 192, 382 },
			{ 8, 160, 386, 192, 414 },
		}
	}
	EvaNewShotData{
		id = 343
		,delay_color = {255,128,32}
		,render = EVA_BLEND_ALPHA
		,AnimationData={
			{ 8, 192, 354, 224, 382 },
			{ 8, 192, 386, 224, 414 },
		}
	}
	EvaNewShotData{
		id = 344
		,delay_color = {255,255,255}
		,render = EVA_BLEND_ALPHA
		,AnimationData={
			{ 8, 224, 354, 256, 382 },
			{ 8, 224, 386, 256, 414 },
		}
	}

	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　HUMAN　人間弾　赤
	EvaNewShotData{
		id = 345
		,delay_color = {255,32,32}
		,render = EVA_BLEND_ALPHA
		,collision = 5
		,fixed_angle = true
		,AnimationData={
			{4, 128, 704, 160, 736 },
			{4, 160, 704, 192, 736 },
			{4, 192, 704, 224, 736 },
			{4, 224, 704, 256, 736 },
		}
	}
	--　DOG　犬弾　緑
	EvaNewShotData{
		id = 346
		,delay_color = {32,255,32}
		,render = EVA_BLEND_ALPHA
		,collision = 5
		,AnimationData={
			{4,   0, 736,  32, 768 },
			{4,  32, 736,  64, 768 },
			{4,  64, 736,  96, 768 },
			{4,  96, 736, 128, 768 },
		}
	}
	--　HUMAN　人間弾　青
	EvaNewShotData{
		id = 347
		,delay_color = {32,32,255}
		,render = EVA_BLEND_ALPHA
		,collision = 5
		,fixed_angle = true
		,AnimationData={
			{4,   0, 704,  32, 736 },
			{4,  32, 704,  64, 736 },
			{4,  64, 704,  96, 736 },
			{4,  96, 704, 128, 736 },
		}
	}
	--　FROG　蛙弾　水色
	EvaNewShotData{
		id = 350
		,delay_color = {32,255,255}
		,render = EVA_BLEND_ALPHA
		,collision = 5
		,fixed_angle = true
		,AnimationData={
			{4,   0, 768,  32, 800 },
			{4,  32, 768,  64, 800 },
			{4,  64, 768,  96, 800 },
			{4,  96, 768, 128, 800 },
		}
	}
	--　BIRD　鳥弾　橙
	EvaNewShotData{
		id = 351
		,delay_color = {255,128,32}
		,render = EVA_BLEND_ALPHA
		,collision = 5
		,AnimationData={
			{4, 128, 736, 160, 768 },
			{4, 160, 736, 192, 768 },
			{4, 192, 736, 224, 768 },
			{4, 224, 736, 256, 768 },
		}
	}

    return data