local sin, cos = sin, cos
local atan2 = atan2
local wait = EvaWait

local EvaTask = EvaTask
local EvaCreateUserShotA2 = EvaCreateUserShotA2
local EvaCreateStraightLaserA1 = EvaCreateStraightLaserA1
local EvaSetLaserLength = EvaSetLaserLength
local EvaSetLaserWidth  = EvaSetLaserWidth
local EvaSetPosition    = EvaSetPosition
local EvaSetAlpha       = EvaSetAlpha
local EvaSetColor       = EvaSetColor
local IsValid           = IsValid
local Del               = Del
local Kill              = Kill
local Angle             = Angle
local ran_Float         = function(a, b) return ran:Float(a, b) end
local ran_Sign          = function() return ran:Sign() end

EvaShotRedA = {}
EvaShotRed_Count = 0
EvaShotRedA_Chosen = 0
EvaShotRedA_Add = 0
EvaShotRedA_Reset = {
    EVA_SP1_SHOT_RED_01,
    EVA_SP1_SHOT_RED_02,
    EVA_SP1_SHOT_RED_03,
    EVA_SP1_SHOT_RED_04
}

function EvaResetShotRedArray()
    EvaShotRedA = CopyArray(EvaShotRedA_Reset)
end

function EvaGetShotRedArrayLength()
    return #EvaShotRedA
end

function EvaEraseShotRedArray(num)
    table.remove(EvaShotRedA, num)
end

function EvaEraseShotRedArray2(num)
    for iQ = 1, EvaGetShotRedArrayLength() do
        if EvaShotRedA[iQ] == num then
            table.remove(EvaShotRedA, iQ)
            break
        end
    end
end

function EvaAddShotRedArray(num)
    table.insert(EvaShotRedA, num)
end

function EvaTShotRed(objE, currentPhase, wt)
    task.New(objE, function()
        task.Wait(wt)
        if(not EvaIsCurrentPhase(currentPhase)) then return end
        local color = EVA_COLOR_RED
        local num = ran:Int(1, EvaGetShotRedArrayLength())
        EvaShotRedA_Chosen = EvaShotRedA[num]
        EvaTShotColorNum(EvaShotRedA[num], objE, currentPhase, color)
        EvaEraseShotRedArray(num)
        EvaShotRed_Count = EvaShotRed_Count + 1
    end)
end

function EvaTShotRedType1(objE, currentPhase, color)
    local way = 16
    local qnt = EvaArray(2, 3, 3, 4, 6)[currentPhase]
    local way2 = EvaArray(3, 3, 4, 5, 6)[currentPhase]
    local way2M = EvaArray(0, 0, 0, 1, 2)[currentPhase]
    local arc = EvaArray(3.0, 3.0, 3.0, 3.0, 2.4)[currentPhase]
    local spd = EvaArray(1.5, 1.6, 1.7, 1.8, 2.4)[currentPhase]
    local sRate = EvaArray(0.70, 0.75, 0.75, 0.80, 0.87)[currentPhase]
    local ang = ran:Float(0, 360)
    local r = 15

    task.New(objE, function()
        EvaCallSE(EVA_SE_FIRE1)
        for iQ = 0, qnt - 1 do
            if not IsValid(objE) then return end
            local W2 = way2-(way2M-int(iQ/(qnt/(way2M+1))))
            for iW = 0, way - 1 do
                local s = spd*(sRate^iQ)
                local a = ang + 360*(iW+0.5*iQ)/way
                for iW2 = 0, W2 - 1 do
                    local a2 = a + arc*(iW2-(W2-1)/2)
				    EvaCreateUserShotA2(EvaGetX(objE) + r*cos(a2), EvaGetY(objE) + r*sin(a2), 2*s, a2, -s/40, s, ADD_BGW_BALL_BS_RED + color, 10)
                end
            end
            task.Wait(5)
        end
    end)
end


local EvaTShot

function EvaTShot(objE, qnt, wt, r, spd, sAdd_, ang, aSpd_, color_)
    task.New(objE, function ()
        for iQ = 0, qnt - 1 do
            EvaCallSE(EVA_SE_SHOT7)
            local s = spd + sAdd_ * iQ
            local a = ang + aSpd_ * iQ
            EvaCreateUserShotA1(EvaGetX(objE) + r*cos(a), EvaGetY(objE) + r*sin(a), s, a, BGW_BALL_S_RED + color_, 10)
            wait(wt)
        end
    end)
end

function EvaTShotRedType2(objE, currentPhase, color)
    local cv = _boss.CommonValue
    local way = EvaArray(13, 15, 19, 25, 31)[currentPhase]
    local qnt = EvaArray(12, 14, 16, 16, 20)[currentPhase]
    local wt = 1
    local wt2 = 5
    local spd = 1.0
    local sAdd = 0.2
    local ang = -90 + ran_Float(-180, 180)/way
    local aSpd = (currentPhase == cv.phaseMax) and 0.6*ran:Sign() or 0

    task.New(objE, function ()
        for iW = 0, way - 1 do
            EvaTShot(objE, qnt, wt2, 15, spd, sAdd, ang+720*iW/way, aSpd, color)
            wait(wt)
        end
    end)
end

local RedType3_D = ran:Sign()

function EvaTShotRedType3(objE, currentPhase, color)
    local cv = _boss.CommonValue
    local way = EvaArray(12, 13, 15, 16, 18)[currentPhase]
	local qnt = EvaArray(3, 3, 4, 4, 5)[currentPhase]
	local wt = 10
	local spd = (currentPhase==cv.phaseMax) and 0.75 or 0.6
	local ang = (currentPhase==cv.phaseMax) and 270+18*RedType3_D or Angle(objE, lstg.player)
	local arc = 4.0
	local r = 15

    task.New(objE, function()
        for iQ = 0, qnt - 1 do
            EvaCallSE(EVA_SE_SHOT2)
            local s = spd*(1 + 0.1 * iQ)
            local way2 = way - (iQ % 2)
            for iW = 0, way2 - 1 do
                local a = ang + arc * (iW - (way2 - 1)/2)
                EvaCreateUserShotA2(EvaGetX(objE) + r*cos(a), EvaGetY(objE) + r*sin(a), 2*s, a, -s/60, s, ADD_BGW_FIRE_RED + color, 10)
            end
            wait(wt)
        end
        RedType3_D = -RedType3_D
    end)
end

local TLaser

function EvaTShotRedType4(objE, currentPhase, color)
    function TShot(x, y, spd, ang, bSpd, color_)
        task.New(objE, function ()
            for iQ = 1, 8 do
                local l = spd * iQ
                local bx = x + l * cos(ang)
                local by = y + l * sin(ang)
                local bs = bSpd * ( 1 + 0.2 * iQ)
                for iQ2 = 1, 0, -1 do
                    EvaCreateUserShotA1(bx, by, bs*(1-0.05*iQ2), ang, BGW_RICE_S_RED + color_, 5)
                end
                wait(1)
            end
        end)
    end

    function TLaser(x, y, spd, ang, time, color_)
        EvaCallSE(EVA_SE_LASER3)
        local objL = EvaCreateStraightLaserA1(x, y, ang, 0, 80, 999999, ADD_BGW_BEAM_ST_RED + color_ , 999999)
        EvaTask(function()
            for t = 1, 20 do
                EvaSetLaserLength(objL, 40 * t)
                wait()
            end
            task.Wait(time - 20)
            if not IsValid(objE) then Del(objL) return end
            EvaCallSE(EVA_SE_LASER1)
            local objL2 = EvaCreateLooseLaserA1(x, y, spd, ang, spd*30, 20, ADD_BGW_BALL_M_RED + color_, 0)
            TShot(x, y, spd, ang, 1.0, color)
            while(IsValid(objL2))do
                if not IsValid(objE) then break end
                objL.beginX = EvaGetX(objL2)
                objL.beginY = EvaGetY(objL2)
                task.Wait()
            end
            Del(objL)
        end)
    end

    if(not IsValid(objE)) then return end
    local way = EvaArray(11, 12, 13, 19, 29)[currentPhase]
	local arc = EvaArray(150, 157.5, 165, 720*(2*way)/(2*way+1), 720*(2*way)/(2*way+1))[currentPhase]
	local wt = 1
	local spd = 45
	local ang = Angle(objE, lstg.player)+180+ran:Float(-arc, arc)/way
	local r = 10
    local time = 75

    EvaTask(function ()
        if(not IsValid(objE)) then return end
        TLaser(EvaGetX(objE) + r*cos(ang), EvaGetY(objE) + r*sin(ang), spd, ang, time, color)
        wait(wt)
        for iW = 1, way - 1 do
            if(not IsValid(objE)) then return end
            local a = ang + arc * iW/(way - 1)
            local a2 = ang - arc * iW/(way - 1)
            TLaser(EvaGetX(objE) + r*cos(a), EvaGetY(objE) + r*sin(a), spd, a, time, color)
            TLaser(EvaGetX(objE) + r*cos(a2), EvaGetY(objE) + r*sin(a2), spd, a2, time, color)
            wait(wt)
        end
    end)
end


