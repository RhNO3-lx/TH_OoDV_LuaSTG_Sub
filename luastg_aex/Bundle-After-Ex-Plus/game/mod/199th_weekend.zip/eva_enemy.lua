local enm = Class(object)

function enm:init(master, x, y, hp, Vcolor)
    self.group = GROUP_NONTJT
    self.layer = LAYER_ENEMY
    self.x = x
    self.y = y
    self.maxhp = hp
    self.hp = hp
    self.damage_taken = 0
    self.master = master
    self.damage_transfer = 0.0

    self.fragile = 4.5

    self.damage_rate = 1.0
    self.hitCount = 0

    self.a = 4
    self.b = 16
    self.rect = true
    self.colli = true
    self.invincible = false
    self.Vcolor = Vcolor or EVA_COLOR_WHITE
end

function enm:frame()
    task.Do(self)
    self.hitCount = max(self.hitCount - 1, 0)
    self.hp = max(self.hp, 0)
end

function enm:colli(other)
    if other.dmg and IsValid(self.master) and not self.invincible then
        self.hitCount = 2
        lstg.var.score = lstg.var.score + 10
        self.hp = max(self.hp - other.dmg * self.damage_rate * self.fragile , 0)
        self.damage_taken = self.damage_taken + other.dmg * self.damage_rate * self.fragile
        self.master.hp = max(self.master.hp - other.dmg * self.damage_transfer, 0)
        Kill(other)
    end
end

function EvaSimpleEnemy(master, x, y, hp, Vcolor)
    local obj = New(enm, master, x, y, hp, Vcolor)
    EvaVanishWithBoss(obj, _boss)
    return obj
end

function EvaGetEnemyDamageTaken(obj)
    return obj.damage_taken or 0
end

function EvaVanishWithBoss(objE, objEnemy)
    task.New(objE, function()
        while(IsValid(objE) and IsValid(objEnemy) and not EvaIsTimeOut()) do
            task.Wait()
        end
        EvaEnemyVanish(objE, objE.Vcolor)
        Kill(objE)
    end)
end

function EvaEnemyVanish(obj, Vcolor)
    local dummy = EvaDummyObjectForTask()
    obj.Vcolor = Vcolor
    task.New(dummy, function()
        EvaCallSE(EVA_SE_VANISH1)
        EvaCherryExplosion(EvaGetX(obj), EvaGetY(obj), 12, 90, Vcolor)
        for _ = 1, 2 do
            EvaExplosionB1Type(EvaGetX(obj), EvaGetY(obj), 30, 2.5, {ran:Float(10,90), ran:Float(10,90), ran:Float(0,90)}, Vcolor)
        end
        Del(dummy)
    end)
end

local dummyBoss = Class(object)

function dummyBoss:init(master, x, y, hp, Vcolor)
    self.bound = false
    self.group = GROUP_ENEMY
    self.layer = LAYER_ENEMY
    self.x = x
    self.y = y
    self.maxhp = hp
    self.hp = hp
    self.damage_taken = 0
    self.masterBoss = master
    self.damage_transfer = 1.0

    self.fragile = 1.0

    self.damage_rate = 1.0
    self.hitCount = 0

    self.a = 16
    self.b = 16
    self.rect = false
    self.colli = true
    self.invincible = false
    self.Vcolor = Vcolor or EVA_COLOR_WHITE
end

function dummyBoss:frame()
    task.Do(self)
    self.hitCount = max(self.hitCount - 1, 0)
    self.hp = max(self.hp, 0)
end

function dummyBoss:colli(other)
    if other.dmg and IsValid(self.masterBoss) and not self.invincible then
        EvaCallSE(EVA_SE_DAMAGE1)
        self.hitCount = 2
        lstg.var.score = lstg.var.score + 10
        self.hp = max(self.hp - other.dmg * self.damage_rate * self.fragile , 0)
        self.damage_taken = self.damage_taken + other.dmg * self.damage_rate * self.fragile
        self.masterBoss.hp = max(self.masterBoss.hp - other.dmg * self.damage_transfer, 0)
        Kill(other)
    end
end

function EvaSimpleDummyBoss(master, x, y, hp, Vcolor)
    local obj = New(dummyBoss, master, x, y, hp, Vcolor)
    return obj
end