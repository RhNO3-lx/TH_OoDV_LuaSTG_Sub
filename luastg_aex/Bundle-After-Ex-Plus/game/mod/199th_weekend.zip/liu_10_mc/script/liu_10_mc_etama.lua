local M = {}

M.bullet = require("liu_10_mc.script.etama.liu_10_mc_bullet")
M.effect = require("liu_10_mc.script.etama.liu_10_mc_effect")

local function loadResource()
    --- @type string | nil
    local dir = "liu_10_mc/img/bullet/"
    local res_list = {
        {"liu_10_mc_eff01", dir .. "liu_10_mc_eff01.png"},
        {"liu_10_mc_etama", dir .. "liu_10_mc_etama.png"},
        {"liu_10_mc_etama2", dir .. "liu_10_mc_etama2.png"},
        {"liu_10_mc_etama3", dir .. "liu_10_mc_etama3.png"},
        {"liu_10_mc_etama6", dir .. "liu_10_mc_etama6.png"},
        {"liu_10_mc_etama7a", dir .. "liu_10_mc_etama7a.png"},
        {"liu_10_mc_etama7b", dir .. "liu_10_mc_etama7b.png"},
        {"liu_10_mc_etama8", dir .. "liu_10_mc_etama8.png"},
    }
    for _, res in ipairs(res_list) do
        local name, path = unpack(res)
        LoadTexture(name, path)
        SetTextureSamplerState(name, "linear+wrap")
    end
    M.bullet.loadBulletRes()
end

M.loadResource = loadResource

return M