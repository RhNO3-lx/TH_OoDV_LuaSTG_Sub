local calc = require("liu_10_mc.script.lib.liu_10_mc_math")
local draw = require("liu_10_mc.script.lib.liu_10_mc_render")
local wisys = require("liu_10_mc.script.lib.liu_10_mc_walkimageSystem")
local cdbg = require("liu_10_mc.script.lib.liu_10_mc_cardbg")

local lerpTo = calc.lerpTo

local M = {}

function M.loadResource()
    local dir = {
        "liu_10_mc/img/stgenm/",
        "liu_10_mc/img/card/",
        "liu_10_mc/img/face/",
    }
    local res_list = {
        {"liu_10_mc_stg2enm", dir[1] .. "liu_10_mc_stg2enm.png"},
        {"liu_10_mc_cdbg02a", dir[2] .. "liu_10_mc_cdbg02a.png"},
        {"liu_10_mc_cdbg02b", dir[2] .. "liu_10_mc_cdbg02b.png"},
        {"liu_10_mc_face02ct", dir[3] .. "enemy2/liu_10_mc_face02ct.png"},
    }
    for _, res in ipairs(res_list) do
        local name, path = unpack(res)
        LoadTexture(name, path)
        SetTextureSamplerState(name, "linear+wrap")
    end
end

--- sprite
local stg2enm_sprite = {
    tex = "liu_10_mc_stg2enm",
    [0] = {x = 0, y = 0, w = 64, h = 64},
    [1] = {x = 64, y = 0, w = 64, h = 64},
    [2] = {x = 128, y = 0, w = 64, h = 64},
    [3] = {x = 192, y = 0, w = 64, h = 64},
    [4] = {x = 0, y = 64, w = 64, h = 64},
    [5] = {x = 64, y = 64, w = 64, h = 64},
    [6] = {x = 128, y = 64, w = 64, h = 64},
    [7] = {x = 192, y = 64, w = 64, h = 64},
}

local cdbg02a_sprite = {
    tex = "liu_10_mc_cdbg02a",
    [0] = {x = 0, y = 0, w = 256, h = 256},
}

local cdbg02b_sprite = {
    tex = "liu_10_mc_cdbg02b",
    [0] = {x = 0, y = 0, w = 256, h = 256},
}

local face02ct_sprite = {
    tex = "liu_10_mc_face02ct",
    [0] = {x = 0, y = 0, w = 256, h = 512},
}

--- boss scripts
--- @type fun(self : liu_10_mc.WalkImageSystem)[]
local boss_scripts = {
    function(self)
        task.New(self, function()
            self:Sprite(0)
            while true do
                self:PosTime(60, 9, 0, 4)
                task.Wait(60)
                self:PosTime(60, 9, 0, -4)
                task.Wait(60)
            end
        end)
    end,
    function(self)
        task.New(self, function()
            self:FilpX()
            self:Sprite(4)
            task.Wait(4)
            self:Sprite(5)
            task.Wait(4)
            self:Sprite(6)
            task.Wait(4)
            self:Sprite(7)
        end)
    end,
    function(self)
        task.New(self, function()
            self:Sprite(4)
            task.Wait(4)
            self:Sprite(5)
            task.Wait(4)
            self:Sprite(6)
            task.Wait(4)
            self:Sprite(7)
        end)
    end,
    function(self)
        task.New(self, function()
            self:FilpX()
            self:Sprite(7)
            task.Wait(4)
            self:Sprite(6)
            task.Wait(4)
            self:Sprite(5)
            task.Wait(4)
            self:Sprite(4)
            self:Sprite(0)
            while true do
                self:PosTime(60, 9, 0, 4)
                task.Wait(60)
                self:PosTime(60, 9, 0, -4)
                task.Wait(60)
            end
        end)
    end,
    function(self)
        task.New(self, function()
            self:Sprite(7)
            task.Wait(4)
            self:Sprite(6)
            task.Wait(4)
            self:Sprite(5)
            task.Wait(4)
            self:Sprite(4)
            self:Sprite(0)
            while true do
                self:PosTime(60, 9, 0, 4)
                task.Wait(60)
                self:PosTime(60, 9, 0, -4)
                task.Wait(60)
            end
        end)
    end,
    function(self)
        task.New(self, function()
            self:Sprite(0)
            task.Wait(6)
            self:Sprite(1)
            task.Wait(6)
            self:Sprite(2)
            task.Wait(6)
            self:Sprite(3)
        end)
    end,
    function(self)
        task.New(self, function()
            self:Sprite(3)
            self:Blend("mul+add")
            self:ScaleTime(20, 1, 0, 6)
            task.Wait(30)
            self:Scale(6, 0)
            self:ScaleTime(20, 1, 1, 1)
            task.Wait(20)
            self:Blend("")
        end)
    end,
}

function M.SetBossWalkImage(self)
    self._wisys = wisys.create(self, stg2enm_sprite, boss_scripts, 1)
end

local cardbg = Class(_spellcard_background)
function cardbg.create()
    local self = New(cardbg)
    _spellcard_background.init(self)
    local tex, sprite = cdbg02b_sprite.tex, cdbg02b_sprite[0]
    cdbg.AddLayer(self, tex, sprite, 0, 0, 0, 0, 0, 0.375, "", 2.3125, cdbg.defaultFrame, {0, 0})
    tex, sprite = cdbg02a_sprite.tex, cdbg02a_sprite[0]
    cdbg.AddLayer(self, tex, sprite, 0, 0, 0, 0, 0, -0.703125, "mul+add", 2.3125, cdbg.defaultFrame, {0, 0})
    return self
end
function cardbg:render()
    cdbg.renderFunc(self)
end

function M.SetCardBg(self)
    if IsValid(self.bg) then RawDel(self.bg) end
    self.bg = cardbg.create()
end

local face_st02ct = Class(object)
function face_st02ct.create()
    --- @class liu_10_mc.stgenm.face_st02ct : lstg.GameObject
    local self = New(face_st02ct)
    self.tex = face02ct_sprite.tex
    self.sprite = face02ct_sprite[0]
    self.layer = LAYER_ENEMY - 5
    self.group = GROUP_GHOST
    self.bound = false
    self.anchor = {0, 1}
    self.alpha = 255
    self.color = {0, 0, 0}
    self.x, self.y = 608, -80
    task.New(self, function()
        for i = 1, 3 do
            lerpTo(self.color, i, 255, 30, 0)
        end
        lerpTo(self, "x", 224, 30, 0)
        lerpTo(self, "y", 16, 30, 0)
        task.Wait(30)
        lerpTo(self, "x", 192, 90, 0)
        lerpTo(self, "y", 32, 90, 0)
        task.Wait(90)
        for i = 1, 3 do
            lerpTo(self.color, i, 255, 30, 0)
        end
        lerpTo(self, "x", -192, 30, 0)
        lerpTo(self, "y", 128, 30, 0)
        task.Wait(30)
        Del(self)
    end)
    return self
end
function face_st02ct:frame()
    task.Do(self)
end
function face_st02ct:render()
    local tex, spr = self.tex, self.sprite
    local x, y = -224 + self.x, 224 - self.y
    local color = Color(self.alpha, unpack(self.color))
    local anchor = self.anchor
    draw.Rect2D(tex, spr, "", anchor, 1, x, y, 0, color)
end

function M.CreateFaceCt()
    face_st02ct.create()
end

return M