local calc = require("liu_10_mc.script.lib.liu_10_mc_math")
local draw = require("liu_10_mc.script.lib.liu_10_mc_render")

local lerp = calc.lerp
local ran2 = calc.rnd

local M = Class(background)
function M:init()
    background.init(self)
    ---------------------------------------------
    local dir = "liu_10_mc/img/background/"
    local res_list = {
        {"liu_10_mc_stage02a", dir .. "liu_10_mc_stage02a.png", true},
        {"liu_10_mc_stage02b", dir .. "liu_10_mc_stage02b.png", true},
    }
    for _, res in ipairs(res_list) do
        local name, path, mipmap = unpack(res)
        ---@diagnostic disable-next-line: param-type-mismatch
        LoadTexture(name, path, mipmap)
        ---@diagnostic disable-next-line: param-type-mismatch
        SetTextureSamplerState(name, "linear+wrap")
    end
    ---------------------------------------------
    Set3D("up", 0.0, 1.0, 0.0)
    Set3D("fovy", 0.62831855)
    Set3D("fog", 200.0, 250.0, Color(0xFF000000))
    Set3D("eye", 0.0, 0.0, -700.0)
    self.facing = {0.0, -400.0, 330.0}
    Set3D("z", 0.1, 9160000.0)
    ---------------------------------------------
    self.tmp_pos = {unpack(lstg.view3d.eye)}
    self.pos_vec = {0, 0, 0}
    self.time = -1
    self.effect = {}
end
function M:frame()
    task.Do(self)
    M.timeLine(self)
    M.updateView3dAt(self)
    M.updatePosVector(self)
    M.rockingCamera(self)
    M.mapleEnemy(self, 3)
end
function M:render()
    SetViewMode("3d")
    background.WarpEffectCapture()
    background.ClearToFogColor()
    ---------------------------------------------
    for y = -5120, 512, 256 do
        M.draw_entry00(self, 0, y, 0)
        M.draw_entry01(self, 0, y, 0)
    end
    ---------------------------------------------
    M.draw_mapleEnemy(self)
    ---------------------------------------------
    background.WarpEffectApply()
    SetViewMode("world")
end

---frame
function M:timeLine()
    self.time = self.time + 1
    local time = self.time
    if self.time >= 0 and self.time < 512 then
        local t = time - 0
        if not self.loop then
            local i = lerp(1, 0, min(t / 120, 1), 0)
            local c1, c2 = Color(0xFF000000), Color(0xFF002000)
            lstg.view3d.fog[1] = lerp(200.0, 200.0, min(t / 120, 1), 0)
            lstg.view3d.fog[2] = lerp(250.0, 950.0, min(t / 120, 1), 0)
            lstg.view3d.fog[3] = c1 * i + c2 * (1 - i)
        end
        lstg.view3d.eye[2] = lerp(0.0, -1024, min(t / 512, 1), 0)
    elseif self.time >= 512 then
        self.time = 0
        self.loop = true
    end
end

function M:updateView3dAt()
    local eye, facing = lstg.view3d.eye, self.facing
    Set3D("at", eye[1] + facing[1], eye[2] + facing[2], eye[3] + facing[3])
end

function M:updatePosVector()
    for i = 1, 3 do
        self.pos_vec[i] = lstg.view3d.eye[i] - self.tmp_pos[i]
    end
    self.tmp_pos = {unpack(lstg.view3d.eye)}
end

function M:rockingCamera()
    local t = self.timer
    local a = 15 / 90 * 0.5
    Set3D("up", a * sin(t / 4), 1.0, 0.0)
end

function M:mapleEnemy(wait)
    if self.timer % wait == 0 then
        local tex = "liu_10_mc_eff01"
        local num = ran2:Int(0, 65535) % 4
        local sprite = {x = 96, y = 0, w = 8, h = 8}
        sprite.x = sprite.x + num * 8
        local blend = "mul+add"
        local da = ran2:Float(-180, 180) / 32
        local scale = 1.5
        local c = ran2:Float(0, 1) * 255
        c = int(c)
        local co = {255, c, 0}
        local vector = calc.vector3(unpack(self.facing))
        vector = calc.normalizeVector3(vector)
        local x = vector.x * 400
        local y = vector.y * 400
        local z = vector.z * 400
        x = x + lstg.view3d.eye[1]
        y = y + lstg.view3d.eye[2]
        z = z + lstg.view3d.eye[3]
        local i = ran2:Float(-1, 1) * 200
        x = x + i
        i = ran2:Float(-1, 1) * 200
        y = y + i - 200
        local alpha = 0
        local from_pos = {x, y, z}
        i = ran2:Float(-1, 1) * 50
        x = x + i
        i = ran2:Float(-1, 1) * 60
        y = y + i + 160
        local to_pos = {x, y, z}
        local effect = {
            tex = tex, sprite = sprite, blend = blend,
            rot = 0, da = da, scale = scale, color = co,
            alpha = alpha,
            pos = {unpack(from_pos)}, from_pos = from_pos, to_pos = to_pos,
            dx = 0, dy = 0, dz = 0, time = -1,
        }
        table.insert(self.effect, effect)
    end
    for _, effect in ipairs(self.effect) do
        effect.time = effect.time + 1
        local time = effect.time
        if time >= 0 and time < 100 then
            local t = time - 0
            effect.alpha = lerp(0, 64, min(t / 30, 1), 0)
        elseif time >= 100 then
            local t = time - 100
            effect.alpha = lerp(64, 0, min(t / 100, 1), 0)
        end
        effect.rot = effect.rot + effect.da
        for i = 1, 3 do
            effect.pos[i] = lerp(effect.from_pos[i], effect.to_pos[i], min(time / 200, 1), 0)
        end
        if abs(self.pos_vec[1]) >= 64 then
            effect.dx = effect.dx + self.pos_vec[1]
        end
        if abs(self.pos_vec[2]) >= 64 then
            effect.dy = effect.dy + self.pos_vec[2]
        end
        if abs(self.pos_vec[3]) >= 64 then
            effect.dz = effect.dz + self.pos_vec[3]
        end
    end
    while #self.effect > 0 do
        if self.effect[1].time >= 200 then
            table.remove(self.effect, 1)
        else break end
    end
end
---render

--- sprite
local stage02a_sprites = {
    [0] = {x = 0, y = 0, w = 32, h = 256},
    [1] = {x = 224, y = 0, w = 32, h = 256},
    [2] = {x = 32, y = 0, w = 32, h = 256},
    [3] = {x = 192, y = 0, w = 32, h = 256},
    [4] = {x = 64, y = 0, w = 32, h = 256},
    [5] = {x = 160, y = 0, w = 32, h = 256},
    [6] = {x = 96, y = 0, w = 32, h = 256},
    [7] = {x = 128, y = 0, w = 32, h = 256},
    [8] = {x = 128, y = 0, w = 32, h = 256},
    [9] = {x = 96, y = 0, w = 32, h = 256},
    [10] = {x = 160, y = 0, w = 32, h = 256},
    [11] = {x = 64, y = 0, w = 32, h = 256},
    [12] = {x = 192, y = 0, w = 32, h = 256},
    [13] = {x = 32, y = 0, w = 32, h = 256},
    [14] = {x = 224, y = 0, w = 32, h = 256},
    [15] = {x = 0, y = 0, w = 32, h = 256},
}

local stage02b_sprites = {
    [0] = {x = 0, y = 0, w = 32, h = 256},
    [1] = {x = 32, y = 0, w = 32, h = 256},
    [2] = {x = 64, y = 0, w = 32, h = 256},
    [3] = {x = 96, y = 0, w = 32, h = 256},
    [4] = {x = 128, y = 0, w = 32, h = 256},
    [5] = {x = 160, y = 0, w = 32, h = 256},
    [6] = {x = 192, y = 0, w = 32, h = 256},
    [7] = {x = 224, y = 0, w = 32, h = 256},
}

---

local quad00_params = {
    angle = {
        {0.0, -0.98901993, 0.0}, {0.0, 0.98901993, 0.0}, {0.0, -0.87266463, 0.0},
        {0.0, 0.87266463, 0.0}, {0.0, -0.75630933, 0.0}, {0.0, 0.75630933, 0.0},
        {0.0, -0.63995403, 0.0}, {0.0, 0.63995403, 0.0}, {0.0, -0.5235988, 0.0},
        {0.0, 0.5235988, 0.0}, {0.0, -0.4072435, 0.0}, {0.0, 0.4072435, 0.0},
        {0.0, -0.29088822, 0.0}, {0.0, 0.29088822, 0.0}, {0.0, -0.17453293, 0.0},
        {0.0, 0.17453293, 0.0},
    },
    pos = {
        {-262.78854, 0.0, 5.120286}, {262.78854, 0.0, 5.120286}, {-237.37227, 0.0, 39.260265},
        {237.37227, 0.0, 39.260265}, {-208.16444, 0.0, 70.21875}, {208.16444, 0.0, 70.21875},
        {-175.56004, 0.0, 97.57709}, {175.56004, 0.0, 97.57709}, {-140.0, 0.0, 120.9653},
        {140.0, 0.0, 120.9653}, {-101.965195, 0.0, 140.0671}, {101.965195, 0.0, 140.0671},
        {-61.969982, 0.0, 154.62416}, {61.969982, 0.0, 154.62416}, {-20.555233, 0.0, 164.43964},
        {20.555233, 0.0, 164.43964},
    }
}

function M:draw_quad00(idx, x, y, z, w, h)
    local tex = "liu_10_mc_stage02a"
    local sprite = stage02a_sprites[idx]
    local spr = {x = sprite.x, y = sprite.y, w = sprite.w, h = sprite.h}
    local xa, ya, za = unpack(quad00_params.angle[min(idx + 1, #quad00_params.angle)])
    xa, ya, za = -math.deg(xa), -math.deg(ya), -math.deg(za)
    local sx, sy, sz = unpack(quad00_params.pos[min(idx + 1, #quad00_params.angle)])
    sx, sy, sz = sx + x, sy + y, sz + z
    spr.x = spr.x + (0.01 * self.timer) * 256
    spr.y = spr.y + (-0.02 * self.timer) * 256
    local blend = ""
    local anchor = {0, 0}
    local scale = {w / sprite.w, h / sprite.h}
    local color = Color(0xFFFFFFFF)
    draw.Rect3D(tex, spr, blend, anchor, scale, sx, sy, sz, xa, ya, za, color)
end

local quad01_params = {
    angle = {
        {0.0, -0.98901993, 0.0}, {0.0, 4.1306124, 0.0}, {0.0, -0.87266463, 0.0},
        {0.0, 4.0142574, 0.0}, {0.0, -0.75630933, 0.0}, {0.0, 3.897902, 0.0},
        {0.0, -0.63995403, 0.0}, {0.0, 3.7815468, 0.0}, {0.0, -0.5235988, 0.0},
        {0.0, 3.6651914, 0.0}, {0.0, -0.4072435, 0.0}, {0.0, 3.5488362, 0.0},
        {0.0, -0.29088822, 0.0}, {0.0, 3.4324808, 0.0}, {0.0, -0.17453292, 0.0},
        {0.0, 3.3161256, 0.0},
    },
    pos = {
        {-262.78854, 0.0, 5.120286}, {262.78854, 0.0, 5.120286}, {-237.37227, 0.0, 39.260265},
        {237.37227, 0.0, 39.260265}, {-208.16444, 0.0, 70.21875}, {208.16444, 0.0, 70.21875},
        {-175.56004, 0.0, 97.57709}, {175.56004, 0.0, 97.57709}, {-140.0, 0.0, 120.9653},
        {140.0, 0.0, 120.9653}, {-101.965195, 0.0, 140.0671}, {101.965195, 0.0, 140.0671},
        {-61.969982, 0.0, 154.62416}, {61.969982, 0.0, 154.62416}, {-20.555233, 0.0, 164.43964},
        {20.555233, 0.0, 164.43964},
    }
}

function M:draw_quad01(idx, x, y, z, w, h)
    local tex = "liu_10_mc_stage02b"
    local sprite = stage02b_sprites[int(idx / 2)]
    local spr = {x = sprite.x, y = sprite.y, w = sprite.w, h = sprite.h}
    local xa, ya, za = unpack(quad01_params.angle[min(idx + 1, #quad01_params.angle)])
    xa, ya, za = -math.deg(xa), -math.deg(ya), -math.deg(za)
    local sx, sy, sz = unpack(quad01_params.pos[min(idx + 1, #quad01_params.angle)])
    sx, sy, sz = sx + x, sy + y, sz + z
    local blend = ""
    local anchor = {0, 0}
    local scale = {w / sprite.w, h / sprite.h}
    local color = Color(0xFFFFFFFF)
    draw.Rect3D(tex, spr, blend, anchor, scale, sx, sy, sz, xa, ya, za, color)
end

function M:draw_entry00(x, y, z)
    for i = 0, 15 do
        M.draw_quad00(self, i, x, y, z - 260, 43, 256)
    end
end
function M:draw_entry01(x, y, z)
    for i = 0, 15 do
        M.draw_quad01(self, i, x, y, z - 320, 43, 256)
    end
end

function M:draw_mapleEnemy()
    for _, effect in ipairs(self.effect) do
        local tex, sprite = effect.tex, effect.sprite
        local blend = effect.blend
        local anchor = {0, 0}
        local scale = effect.scale
        local alpha, co = effect.alpha, effect.color
        local color = Color(alpha, unpack(co))
        local x, y, z = unpack(effect.pos)
        x, y, z = x + effect.dx, y + effect.dy, z + effect.dz
        local rot = effect.rot
        draw.Billboard(tex, sprite, blend, anchor, scale, x, y, z, 0, 0, rot, color)
    end
end

lstg.RegisterGameObjectClass(M)

return M