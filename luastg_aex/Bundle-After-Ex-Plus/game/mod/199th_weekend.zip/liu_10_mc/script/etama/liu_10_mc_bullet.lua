local calc = require("liu_10_mc.script.lib.liu_10_mc_math")
local draw = require("liu_10_mc.script.lib.liu_10_mc_render")

local lerp = calc.lerp
local lerpTo = calc.lerpTo

local ran2 = calc.rnd

local M = {}

local et_params = {}

local COLOR_16, COLOR_32, COLOR_64, COLOR_MONEY, COLOR_NAN = 0, 1, 2, 3, 4

--- @param id integer | string
--- @param tex string
--- @param sprite table
--- @param cols integer
--- @param rows integer
--- @param span number[]
--- @param omiga number
--- @param colli number
--- @param move_rot boolean
--- @param is_ani boolean
--- @param color_type integer
local function AddStyle(id, tex, sprite, cols, rows, span, omiga, colli, move_rot, is_ani, color_type)
    local sprites = {}
    local nmax = cols * rows
    for i = 0, (nmax - 1) do
        sprites[i] = {
            x = sprite[1] + (i % cols) * span[1],
            y = sprite[2] + math.floor(i / cols) * span[2],
            w = sprite[3], h = sprite[4]
        }
    end
    et_params[id] = {
        tex = tex,
        sprites = sprites,
        omiga = omiga,
        colli = colli,
        move_rot = move_rot,
        is_ani = is_ani,
        color_type = color_type or COLOR_16,
    }
end

--- @param id integer | string
--- @param from_id integer | string
--- @param omiga number?
--- @param colli number?
--- @param move_rot boolean?
local function CopyStyle(id, from_id, omiga, colli, move_rot)
    local style = et_params[from_id]
    local sprites = {}
    for i, v in pairs(style.sprites) do
        sprites[i] = {}
        for j, w in pairs(v) do
            sprites[i][j] = w
        end
    end
    et_params[id] = {
        tex = style.tex,
        sprites = sprites,
        omiga = omiga or style.omiga,
        colli = colli or style.colli,
        move_rot = move_rot or style.move_rot,
        is_ani = style.is_ani,
        color_type = style.color_type,
    }
end

AddStyle(0, "liu_10_mc_etama", {0, 240, 8, 8}, 8, 2, {8, 8}, 0, 4, false, false, COLOR_16)
AddStyle(1, "liu_10_mc_etama", {0, 48, 16, 16}, 16, 1, {16, 16}, 0, 6, false, false, COLOR_16)
AddStyle(2, "liu_10_mc_etama", {0, 32, 16, 16}, 16, 1, {16, 16}, 0, 6, false, false, COLOR_16)
AddStyle(3, "liu_10_mc_etama", {0, 65, 16, 14}, 16, 1, {16, 16}, 0, 4, true, false, COLOR_16)
AddStyle(4, "liu_10_mc_etama", {0, 81, 16, 14}, 16, 1, {16, 16}, 0, 4, true, false, COLOR_16)
AddStyle(5, "liu_10_mc_etama", {0, 97, 16, 14}, 16, 1, {16, 16}, 0, 4, true, false, COLOR_16)
AddStyle(6, "liu_10_mc_etama", {1, 112, 14, 16}, 16, 1, {16, 16}, 0, 4, true, false, COLOR_16)
AddStyle(7, "liu_10_mc_etama", {1, 16, 14, 16}, 16, 1, {16, 16}, 0, 4, true, false, COLOR_16)
AddStyle(8, "liu_10_mc_etama", {1, 129, 14, 14}, 16, 1, {16, 16}, 0, 4, true, false, COLOR_16)
AddStyle(9, "liu_10_mc_etama", {1, 177, 14, 14}, 16, 1, {16, 16}, 0, 0, false, false, COLOR_16)
AddStyle(10, "liu_10_mc_etama", {1, 144, 14, 16}, 16, 1, {16, 16}, 0, 4, true, false, COLOR_16)
AddStyle(11, "liu_10_mc_etama", {1, 160, 14, 16}, 16, 1, {16, 16}, -6, 6, false, false, COLOR_16)
AddStyle(12, "liu_10_mc_etama6", {0, 32, 32, 32}, 8, 1, {32, 32}, 0, 10, false, false, COLOR_32)
AddStyle(13, "liu_10_mc_etama6", {1, 129, 30, 30}, 8, 1, {32, 32}, 0, 8, true, false, COLOR_32)
AddStyle(14, "liu_10_mc_etama6", {1, 97, 30, 30}, 8, 1, {32, 32}, 0, 8, true, false, COLOR_32)
AddStyle(15, "liu_10_mc_etama6", {1, 65, 30, 30}, 8, 1, {32, 32}, 0, 8, true, false, COLOR_32)
AddStyle(16, "liu_10_mc_etama6", {1, 1, 30, 30}, 8, 1, {32, 32}, -3, 8, false, false, COLOR_32)
AddStyle(17, "liu_10_mc_etama6", {0, 192, 64, 64}, 4, 1, {64, 64}, -45, 14, false, false, COLOR_64)
AddStyle(18, "liu_10_mc_etama2", {1, 177, 30, 30}, 4, 1, {32, 32}, 0, 6, true, true, COLOR_NAN)
AddStyle(19, "liu_10_mc_etama6", {0, 32, 32, 32}, 8, 1, {32, 32}, 0, 10, false, false, COLOR_32)
AddStyle(20, "liu_10_mc_etama6", {1, 129, 30, 30}, 8, 1, {32, 32}, 0, 8, true, false, COLOR_32)
AddStyle(21, "liu_10_mc_etama6", {1, 97, 30, 30}, 8, 1, {32, 32}, 0, 8, true, false, COLOR_32)
AddStyle(22, "liu_10_mc_etama6", {1, 65, 30, 30}, 8, 1, {32, 32}, 0, 8, true, false, COLOR_32)
AddStyle(23, "liu_10_mc_etama", {208, 192, 16, 16}, 3, 1, {16, 16}, 0, 6, false, false, COLOR_MONEY)
AddStyle(24, "liu_10_mc_etama", {0, 192, 8, 8}, 8, 2, {8, 8}, -11.25, 4, false, false, COLOR_16)
AddStyle(25, "liu_10_mc_etama2", {1, 145, 30, 30}, 4, 1, {32, 32}, 0, 6, true, true, COLOR_NAN)
CopyStyle(26, 3, -6, 4)
CopyStyle(27, 0)
AddStyle(28, "liu_10_mc_etama8", {0, 0, 32, 32}, 8, 1, {32, 32}, 0, 10, true, false, COLOR_32)
AddStyle(29, "liu_10_mc_etama8", {0, 32, 64, 64}, 4, 1, {64, 64}, 0, 14, false, false, COLOR_64)

local fadeImage_sprite = {
    tex = "liu_10_mc_etama",
    [0] = {x = 1, y = 209, w = 30, h = 30},
    [1] = {x = 33, y = 209, w = 30, h = 30},
    [2] = {x = 65, y = 209, w = 30, h = 30},
    [3] = {x = 97, y = 209, w = 30, h = 30},
    [4] = {x = 129, y = 209, w = 30, h = 30},
    [5] = {x = 161, y = 209, w = 30, h = 30},
    [6] = {x = 193, y = 209, w = 30, h = 30},
    [7] = {x = 225, y = 209, w = 30, h = 30},
}

local etbreak_sprite = {
    tex = "liu_10_mc_etama",
    [0] = {x = 0, y = 176, w = 16, h = 16},
    [1] = {x = 16, y = 176, w = 16, h = 16},
    [2] = {x = 32, y = 176, w = 16, h = 16},
    [3] = {x = 48, y = 176, w = 16, h = 16},
    [4] = {x = 64, y = 176, w = 16, h = 16},
    [5] = {x = 80, y = 176, w = 16, h = 16},
    [6] = {x = 96, y = 176, w = 16, h = 16},
    [7] = {x = 112, y = 176, w = 16, h = 16},
    [8] = {x = 128, y = 176, w = 16, h = 16},
    [9] = {x = 144, y = 176, w = 16, h = 16},
    [10] = {x = 160, y = 176, w = 16, h = 16},
    [11] = {x = 176, y = 176, w = 16, h = 16},
    [12] = {x = 192, y = 176, w = 16, h = 16},
    [13] = {x = 208, y = 176, w = 16, h = 16},
    [14] = {x = 224, y = 176, w = 16, h = 16},
    [15] = {x = 240, y = 176, w = 16, h = 16},
}

local function loadBulletRes()
    for i = 0, #et_params do
        local param = et_params[i]
        local name = ("liu_10_mc_et%d"):format(i)
        local tex = param.tex
        local sprite = param.sprites
        for j = 0, #sprite do
            local spr = sprite[j]
            local img = name .. "_" .. j
            LoadImage(img, tex, spr.x, spr.y, spr.w, spr.h)
        end
    end
    local tex = fadeImage_sprite.tex
    for i = 0, #fadeImage_sprite do
        local name = "liu_10_mc_fade" .. i
        local spr = fadeImage_sprite[i]
        LoadImage(name, tex, spr.x, spr.y, spr.w, spr.h)
    end
end
M.loadBulletRes = loadBulletRes

--- et effect
local etbreak = Class(object)
function etbreak.create(x, y, co)
    --- @class liu_10_mc.bullet.etbreak : lstg.GameObject
    local self = New(etbreak)
    self.group = GROUP_GHOST
    self.layer = LAYER_ENEMY_BULLET_EF
    self.tex = etbreak_sprite.tex
    self.sprite = etbreak_sprite[co]
    self.x, self.y = x, y
    self.pos = {x = x, y = y}
    self.offset = {
        x = ran2:Float(-1, 1) * 12,
        y = ran2:Float(-1, 1) * 12,
    }
    self.rot = ran2:Float(-180, 180)
    self.alpha = 128
    self.scale = 1
    return self
end
function etbreak:frame()
    task.Do(self)
    self.x = lerp(self.pos.x, self.pos.x + self.offset.x, self.timer / 28, 0)
    self.y = lerp(self.pos.y, self.pos.y + self.offset.y, self.timer / 28, 0)
    if self.timer >= 0 and self.timer < 14 then
        local t = self.timer
        self.scale = lerp(1, 1.9, t / 14, 1)
        if self.timer == 8 then self.alpha = 20 end
    elseif self.timer >= 14 and self.timer < 28 then
        local t = self.timer - 14
        self.scale = lerp(1.9, 0.8, t / 14, 1)
    elseif self.timer >= 28 then
        Del(self)
    end
end
function etbreak:render()
    if self.alpha <= 0 then return end
    local tex, sprite = self.tex, self.sprite
    local blend = "mul+add"
    local x, y = self.x, self.y
    local rot, scale = self.rot, self.scale
    local color = Color(self.alpha, 255, 255, 255)
    draw.Rect2D(tex, sprite, blend, {0, 0}, scale, x, y, rot, color)
end

local etKillEffect = Class(object)
function etKillEffect.create(tex, sprite, x, y, rot, time, s1, s2, c1, c2, blend, layer, mode, al_mode)
    --- @class liu_10_mc.bullet.etKillEffect : lstg.GameObject
    local self = New(etKillEffect)
    self.group = GROUP_GHOST
    self.layer = layer or LAYER_ENEMY_BULLET
    self.x, self.y = x, y
    self.tex, self.sprite = tex, sprite
    self.rot = rot or ran2:Float(-180, 180)
    self.scale, self.color = s1, c1
    self.maxtime = time
    self.from = {scale = s1, color = c1}
    self.target = {scale = s2, color = c2}
    self.blend = blend or ""
    self.mode = mode or 0
    self.al_mode = al_mode or 0
    return self
end
function etKillEffect:frame()
    task.Do(self)
    if self.timer >= 0 and self.timer < self.maxtime then
        local t = self.timer
        local a0, r0, g0, b0 = self.from.color:ARGB()
        local a1, r1, g1, b1 = self.target.color:ARGB()
        self.scale = lerp(self.from.scale, self.target.scale, t / self.maxtime, self.mode)
        self.color.a = lerp(a0, a1, t / self.maxtime, self.al_mode)
        self.color.r = lerp(r0, r1, t / self.maxtime, 0)
        self.color.g = lerp(g0, g1, t / self.maxtime, 0)
        self.color.b = lerp(b0, b1, t / self.maxtime, 0)
    elseif self.timer >= self.maxtime then
        Del(self)
    end
end
function etKillEffect:render()
    if self.color.a <= 0 then return end
    local tex, sprite = self.tex, self.sprite
    local blend = self.blend
    local x, y = self.x, self.y
    local rot, scale = self.rot, self.scale
    local color = self.color
    draw.Rect2D(tex, sprite, blend, {0, 0}, scale, x, y, rot, color)
end

--- et bullet func
function M.setBulletStyle(obj, style, co)
    style = style % (#et_params + 1)
    local et_param = et_params[style]
    co = co % (#et_param.sprites + 1)

    obj.style = style
    obj.co = co

    obj.tex = et_param.tex
    obj.sprite = et_param.sprites[co]

    obj.omiga = et_param.omiga

    obj.rect = true
    if style == 17 or style == 29 then
        obj.rect = false
    end

    local colli = et_param.colli * 0.5
    if not  obj.rect then
        colli = et_param.colli
    end
    obj.a, obj.b = colli, colli

    obj.angle_offset = 0
    obj.move_rot = et_param.move_rot

    obj.is_ani = et_param.is_ani

    obj.layer = LAYER_ENEMY_BULLET - obj.style * 0.0001 - obj.co * 0.00001
end

local fade_params_funcs = {
    [COLOR_16] = function(style, co)
        local s1
        if style == 0 or style == 24 or style == 27 then
            s1 = {3, 2, 4}
        else
            s1 = {3, 3, 4}
        end
        local s2 = 0.5
        local ids = {0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 5, 6, 6, 6, 7}
        local img = "liu_10_mc_fade" .. ids[co + 1]
        return s1, s2, img
    end,
    [COLOR_32] = function(style, co)
        local s1  = {5, 5, 6}
        local s2 = 1
        local img = "liu_10_mc_fade" .. co
        return s1, s2, img
    end,
    [COLOR_64] = function(style, co)
        local s1 = {3, 2, 4}
        local s2 = 1
        local img = "liu_10_mc_et" .. style .. "_" .. co
        return s1, s2, img
    end,
    [COLOR_MONEY] = function(style, co)
        local s1 = {3, 2, 4}
        local s2 = 0.5
        ids = {6, 7, 2}

        local img = "liu_10_mc_fade" .. ids[co + 1]
        return s1, s2, img
    end,
    [COLOR_NAN] = function(style, co)
        s1 = {5, 5, 6}
        s2 = 1
        local img = "liu_10_mc_et" .. style .. "_" .. co
        return s1, s2, img
    end,
}

function M.setBulletFade(obj, mode, stay)
    mode = mode or 1
    local style, co = obj.style or 0, obj.co or 0
    local et_param = et_params[style]
    local color_type = et_param.color_type

    local time = {15, 8, 25}
    local s1, s2, img = fade_params_funcs[color_type](style, co)

    obj.stay = stay or false
    obj.fade = {
        frame = function(self)
            if not self.stay then
                if not(self._forbid_ref) then
                    self._forbid_ref = true
                    self.logclass.frame(self)
                    self._forbid_ref = nil
                end
            else
                self.x = self.x - self.vx
                self.y = self.y - self.vy
                self.rot = self.rot - self.omiga
            end
            if self.move_rot then
                if self.chace_rot ~= self.rot then
                    self.angle = self.rot
                    self.rot = 0
                    self.chace_rot = self.rot
                end
            end
            self.rot = 0
            self.render_rot = 0 + (self.ani * self.omiga)
            if self.move_rot then
                self.render_rot = (self.angle or 0) - 90
            end
            if self.timer == time[mode] then
                self.class = self.logclass
                if self.stay then
                    self.timer = -1
                end
            end
            self.render_scale = lerp(s1[mode], s2, min(self.timer / time[mode], 1), 4)
            self.render_alpha = lerp(0, 255, min(self.timer / time[mode], 1), 4)
        end,
        render = function(self)
            local rot = self.render_rot or 0
            local s = self.render_scale
            local al = self.render_alpha
            local r, g, b = self._r or 255, self._g or 255, self._b or 255
            local color = Color(al, r, g, b)
            local blend = obj._blend or ""
            SetImageState(img, blend, color)
            Render(img, self.x, self.y, rot, self.hscale * (s or 1), self.vscale * (s or 1))
        end
    }
end

function M.changeBulletStyle(obj, style, co, fade)
    M.setBulletStyle(obj, style, co)
    if fade then
        M.setBulletFade(obj, fade)
        obj.logclass = obj.class
        obj.stay = false
        obj.timer = -1
        obj.class = obj.imgclass
    end
end

--- et bullet
local tmp_class = Class(bullet)
function tmp_class:frame()
    task.Do(self)
    local style = self.style or 0
    local et_param = et_params[style]
    if self.is_ani then
        local t = int(self.timer / 3) % 4
        self.sprite = et_param.sprites[t]
    end
    if self.move_rot then
        if self.chace_rot ~= self.rot then
            self.angle = self.rot
            self.rot = 0
            self.chace_rot = self.rot
        end
    end
    self.rot = 0
    self.render_rot = 0 + (self.ani * self.omiga)
    if self.move_rot then
        self.render_rot = (self.angle or 0) - 90
    end
    local a, r, g, b = self._a or 255, self._r or 255, self._g or 255, self._b or 255
    self.color = Color(a, r, g, b)
end
function tmp_class:render()
    if not self.color then return end
    local rot = self.render_rot or 0
    --draw.Rect2D(self.tex, self.sprite, self._blend or "", {0, 0}, scale, self.x, self.y, rot, color)

    local name = ("liu_10_mc_et%d_%d"):format(self.style or 0, self.co or 0)
    SetImageState(name, self._blend or "", self.color)
    Render(name, self.x, self.y, rot, self.hscale, self.vscale)
end
function tmp_class:del()
    self.imgclass.del(self)
end
function tmp_class:kill()
    self.imgclass.kill(self)
end

M.bullet_class = Class(img_class)
M.bullet_class.size = 1.0
function M.bullet_class:init()
    self.logclass = tmp_class
end
function M.bullet_class:frame()
    if not self.fade then return end
    if self.fade.frame then self.fade.frame(self) end
end
function M.bullet_class:render()
    if not self.fade then return end
    if self.fade.render then self.fade.render(self) end
end

local et_kill_params_funcs = {
    [COLOR_16] = function(self, style, co)
        local s1, s2, al1, al2, time, mode
        if style == 0 or style == 27 then
            s1, s2 = 0.4, 1.9
            al1, al2 = 255, 0
            time, mode = 8, 4
        elseif style == 24 then
            s1, s2 = 0.8, 0
            al1, al2 = 255, 255
            time, mode = 16, 1
        else
            s1, s2 = 1, 0
            al1, al2 = 255, 255
            time, mode = 16, 1
        end
        local tex = etbreak_sprite.tex
        local sprite = etbreak_sprite[co]
        local rot = ran2:Float(-180, 180)
        return s1, s2, al1, al2, time, mode, tex, sprite, rot, ids, 0
    end,
    [COLOR_32] = function(self, style, co)
        local s1, s2 = 1, 1.5
        local al1, al2 = 255, 0
        local time, mode = 14, 4
        local ids = {0, 2, 4, 6, 8, 10, 13, 15}
        local et_param = et_params[style]
        local tex = et_param.tex
        local sprite = et_param.sprites[co]
        local rot = self.angle or 0
        if self.move_rot then rot = (self.angle or 0) - 90 end
        return s1, s2, al1, al2, time, mode, tex, sprite, rot, ids, 0
    end,
    [COLOR_64] = function(self, style, co)
        local s1, s2 = 1, 0
        local al1, al2 = 255, 255
        local time, mode = 12, 4
        local al_mode = 4
        local et_param = et_params[style]
        local tex = et_param.tex
        local sprite = et_param.sprites[co]
        local rot = self.angle or 0
        if self.move_rot then rot = (self.angle or 0) - 90 end
        return s1, s2, al1, al2, time, mode, tex, sprite, rot, nil, al_mode
    end,
    [COLOR_MONEY] = function(self, style, co)
        local s1, s2 = 1, 0
        local al1, al2 = 255, 255
        local time, mode = 16,1
        local ids = {13, 15, 2}
        local et_param = et_params[style]
        local tex = et_param.tex
        local sprite = et_param.sprites[co]
        local rot = ran2:Float(-180, 180)
        return s1, s2, al1, al2, time, mode, tex, sprite, rot, ids, 0
    end,
    [COLOR_NAN] = function(self, style, co)
        local s1, s2 = 1.5, 2.9
        local al1, al2 = 255, 0
        local time, mode = 14, 4
        local ids
        if style == 18 then
            ids = {6}
        elseif style == 25 then
            ids = {2}
        end
        local tex = fadeImage_sprite.tex
        local sprite = fadeImage_sprite[ids[min(co + 1, #ids)]]
        local rot = ran2:Float(-180, 180)
        return s1, s2, al1, al2, time, mode, tex, sprite, rot, ids, 0
    end,
}

function M.bullet_class:del()
    local style = self.style or 0
    local co = self.co or 0
    local world = lstg.world
    if BoxCheck(self, world.boundl, world.boundr, world.boundb, world.boundt) then
        local et_param = et_params[style]
        local color_type = et_param.color_type
        local blend = "mul+add"
        if style == 11 then blend = "mul+alpha" end
        local s1, s2, al1, al2, time, mode, tex, sprite, rot, ids, al_mode = et_kill_params_funcs[color_type](self, style, co)
        local c1 = Color(al1, 255, 255, 255)
        local c2 = Color(al2, 255, 255, 255)
        if ids then
            etbreak.create(self.x, self.y, ids[min(co + 1, #ids)])
        end
        local eff = etKillEffect.create(tex, sprite, self.x, self.y, rot, time, s1, s2, c1, c2, blend, self.layer, mode, al_mode)
        SetV(eff, self._speed or 0, self._angle or 0, false)
    end
end
function M.bullet_class:kill()
    local world = lstg.world
    if BoxCheck(self, world.boundl, world.boundr, world.boundb, world.boundt) then
        New(item_faith_minor, self.x, self.y)
        M.bullet_class.del(self)
    end
end

--- laser
--- 暂时不用

return M