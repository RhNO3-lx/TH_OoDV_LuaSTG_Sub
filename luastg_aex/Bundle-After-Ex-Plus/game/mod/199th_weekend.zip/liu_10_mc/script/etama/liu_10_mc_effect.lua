local calc = require("liu_10_mc.script.lib.liu_10_mc_math")
local draw = require("liu_10_mc.script.lib.liu_10_mc_render")

local lerp = calc.lerp
local lerpTo = calc.lerpTo

local ran2 = calc.rnd

local function moveBezier(t, x1, y1, z1, x2, y2, z2, x3, y3, z3)
    local p0 = {0, 0, 0}
    local p1 = {x1 / t * (t / 3), y1 / t * (t / 3), z1 / t * (t / 3)}
    local p2 = {x2 - x3 / t * (t / 3), y2 - y3 / t * (t / 3), z2 - z3 / t * (t / 3)}
    local p3 = {x2, y2, z2}
    local px, py, pz = {}, {}, {}
    for i = 1, t do
        local _x, _y, _z
        local pow = math.pow
        _x = pow(1 - i / t, 2) * p0[1] + i / t * (1 - i / t) * p1[1] + i / t * (1 - i / t) / t * p2[1] + pow(i / t, 2) * p3[1]
        _y = pow(1 - i / t, 2) * p0[2] + i / t * (1 - i / t) * p1[2] + i / t * (1 - i / t) / t * p2[2] + pow(i / t, 2) * p3[2]
        _z = pow(1 - i / t, 2) * p0[3] + i / t * (1 - i / t) * p1[3] + i / t * (1 - i / t) / t * p2[3] + pow(i / t, 2) * p3[3]
        table.insert(px, _x)
		table.insert(py, _y)
		table.insert(pz, _z)
    end
    local pos = {px, py, pz}
	return pos
end

local M = {}

--- sprite

local eff_deadcircle_sprite = {
    tex = "liu_10_mc_etama2",
    [0] = {x = 128, y = 16, w = 64, h = 64},
    [1] = {x = 192, y = 16, w = 64, h = 64},
    [2] = {x = 0, y = 80, w = 64, h = 64},
    [3] = {x = 64, y = 80, w = 64, h = 64},
}

local eff_maple_sprite = {
    tex = "liu_10_mc_etama2",
    [0] = {x = 0, y = 224, w = 32, h = 32},
    [1] = {x = 33, y = 225, w = 30, h = 30},
}

local eff_magicsquare_sprite = {
    tex = "liu_10_mc_etama2",
    [0] = {x = 128, y = 80, w = 128, h = 128},
}

local eff_aura_sprite = {
    tex = "liu_10_mc_eff01",
    [0] = {x = 0, y = 0, w = 48, h = 48},
    [1] = {x = 48, y = 0, w = 48, h = 48},
}

local eff_line_sprite = {
    tex = "liu_10_mc_etama3",
    [0] = {x = 65, y = 0, w = 14, h = 128},
    [1] = {x = 81, y = 0, w = 14, h = 128},
    [2] = {x = 49, y = 0, w = 14, h = 128},
    [3] = {x = 33, y = 0, w = 14, h = 128},
    [4] = {x = 97, y = 0, w = 15, h = 448},
}

--- enemy_kill

local enemy_kill_deadcircle00 = Class(object)
function enemy_kill_deadcircle00.create(x, y, idx)
    --- @class liu_10_mc.enemy_kill.deadcircle00 : lstg.GameObject
    local self = New(enemy_kill_deadcircle00)
    self.tex = eff_deadcircle_sprite.tex
    self.sprite = eff_deadcircle_sprite[idx]
    self.group = GROUP_GHOST
    self.layer = LAYER_ENEMY_BULLET_EF + 50
    self.bound = false
    self.blend = ""
    self.x, self.y = x, y
    self.scale = 0.2
    self.alpha = 0
    return self
end
function enemy_kill_deadcircle00:frame()
    task.Do(self)
    self.scale = lerp(0.2, 2.5, self.timer / 30, 4)
    self.alpha = lerp(255, 0, self.timer / 30, 4)
    if self.timer >= 30 then Del(self) end
end
function enemy_kill_deadcircle00:render()
    if self.alpha <= 0 then return end
    local tex, sprite = self.tex, self.sprite
    local x, y = self.x, self.y
    local blend = self.blend
    local color = Color(self.alpha, 255, 255, 255)
    local scale = self.scale
    draw.Rect2D(tex, sprite, blend, {0, 0}, scale, x, y, 0, color)
end

local enemy_kill_deadcircle01 = Class(object)
function enemy_kill_deadcircle01.create(x, y, idx)
    --- @class liu_10_mc.enemy_kill.deadcircle01 : lstg.GameObject
    local self = New(enemy_kill_deadcircle01)
    self.tex = eff_deadcircle_sprite.tex
    self.sprite = eff_deadcircle_sprite[idx]
    self.group = GROUP_GHOST
    self.layer = LAYER_ENEMY_BULLET_EF + 50
    self.bound = false
    self.blend = ""
    self.x, self.y = x, y
    self.hs, self.vs = 0.5, 0.5
    self.alpha = 0
    self.rot = ran2:Float(-180, 180)
    return self
end
function enemy_kill_deadcircle01:frame()
    task.Do(self)
    self.hs = lerp(0.5, 3.5, self.timer / 30, 4)
    self.vs = lerp(0.5, 0.2, self.timer / 30, 4)
    self.alpha = lerp(255, 0, self.timer / 30, 4)
    if self.timer >= 30 then Del(self) end
end
function enemy_kill_deadcircle01:render()
    if self.alpha <= 0 then return end
    local tex, sprite = self.tex, self.sprite
    local x, y = self.x, self.y
    local blend = self.blend
    local color = Color(self.alpha, 255, 255, 255)
    local scale = {self.hs, self.vs}
    local rot = self.rot
    draw.Rect2D(tex, sprite, blend, {0, 0}, scale, x, y, rot, color)
end

local enemy_kill_maple = Class(object)
function enemy_kill_maple.create(x, y)
    --- @class liu_10_mc.enemy_kill.maple : lstg.GameObject
    local self = New(enemy_kill_maple)
    self.tex = eff_maple_sprite.tex
    self.sprite = eff_maple_sprite[0]
    self.group = GROUP_GHOST
    self.layer = LAYER_ENEMY_BULLET_EF + 50
    self.bound = false
    self.blend = "mul+add"
    self.x, self.y = x, y
    self.alpha = 64
    self.scale = ran2:Float(0, 1) * 1.5 + 0.5
    local ra = ran2:Float(-180, 180)
    local radius = ran2:Float(0, 1) * 256
    local rx, ry = radius * cos(ra), radius * sin(ra)
    self.maxtime = ran2:Int(0, 15) + 20
    self.from = {x = x, y = y, scale = self.scale}
    self.target = {x = x + rx, y = y + ry, scale = 0}
    return self
end
function enemy_kill_maple:frame()
    task.Do(self)
    self.x = lerp(self.from.x, self.target.x, self.timer / self.maxtime, 4)
    self.y = lerp(self.from.y, self.target.y, self.timer / self.maxtime, 4)
    self.scale = lerp(self.from.scale, self.target.scale, self.timer / self.maxtime, 4)
    if self.timer >= self.maxtime then Del(self) end
end
function enemy_kill_maple:render()
    if self.alpha <= 0 then return end
    local tex, sprite = self.tex, self.sprite
    local x, y = self.x, self.y
    local blend = self.blend
    local color = Color(self.alpha, 255, 255, 255)
    local scale = self.scale
    draw.Rect2D(tex, sprite, blend, {0, 0}, scale, x, y, 0, color)
end

function M.enemy_dead_ef(x, y, idx)
    PlaySound("enep00", 0.3, x / 256)
    enemy_kill_deadcircle00.create(x, y, idx)
    enemy_kill_deadcircle01.create(x, y, idx)
    for _ = 1, 7 do enemy_kill_maple.create(x, y) end
end

--- magic_square
local eff_magicsquare = Class(object)
function eff_magicsquare.create(target)
    --- @class liu_10_mc.magic_square : lstg.GameObject
    local self = New(eff_magicsquare)
    self.tex = eff_magicsquare_sprite.tex
    self.sprite = eff_magicsquare_sprite[0]
    self.group = GROUP_GHOST
    self.layer = LAYER_ENEMY - 5
    self.bound = false
    self.blend = "mul+add"
    self.rot = -180
    self.alpha = 128
    self.scale = 0
    self.omiga = 0
    self.target = target
    task.New(self, function()
        lerpTo(self, "rot", 180, 60, 4)
        lerpTo(self, "scale", 2, 60, 4)
        task.Wait(60)
        self.omiga = 5.625
        while true do
            lerpTo(self, "scale", 1.6, 60, 9)
            lerpTo(self, "alpha", 128, 60, 9)
            task.Wait(60)
            lerpTo(self, "scale", 2, 60, 9)
            lerpTo(self, "alpha", 96, 60, 9)
            task.Wait(60)
        end
    end)
    return self
end
function eff_magicsquare:frame()
    task.Do(self)
    if IsValid(self.target) then
        self.x, self.y = self.target.x, self.target.y
        self.hide = self.target.hide
    else
        Del(self)
    end
end
function eff_magicsquare:render()
    local tex, sprite = self.tex, self.sprite
    local x, y = self.x, self.y
    local rot = self.rot
    local blend, color = self.blend, Color(self.alpha, 255, 255, 255)
    local anchor, scale = {0, 0}, {self.scale, self.scale}
    draw.Rect2D(tex, sprite, blend, anchor, scale, x, y, rot, color)
end

function M.setBossMagicSquare(target)
    target.eff_magicsquare = eff_magicsquare.create(target)
end

--- eff_change
local eff_charge_maple = Class(object)
function eff_charge_maple.create(x, y)
    --- @class liu_10_mc.effect.eff_charge.eff_charge_maple : lstg.GameObject
    local self = New(eff_charge_maple)
    self.tex = eff_maple_sprite.tex
    self.sprite = eff_maple_sprite[1]
    self.group = GROUP_GHOST
    self.layer = LAYER_ENEMY_BULLET_EF + 50
    self.bound = false
    self.blend = "mul+add"
    self.rot = 0
    self.omiga = ran2:Float(-180, 180) / 32
    self.scale = (ran2:Float(0, 1) * 3) + 1
    self.alpha = 0
    local ra = ran2:Float(-180, 180)
    local rx, ry = 256 * cos(ra), 256 * sin(ra)
    self.x, self.y = x + rx, y + ry
    task.New(self, function()
        lerpTo(self, "x", x, 60, 4)
        lerpTo(self, "y", y, 60, 4)
        lerpTo(self, "alpha", 128, 30, 4)
        task.Wait(30)
        lerpTo(self, "alpha", 0, 30, 1)
        lerpTo(self, "scale", 0, 30, 1)
        task.Wait(30)
        Del(self)
    end)
    return self
end
function eff_charge_maple:frame()
    task.Do(self)
end
function eff_charge_maple:render()
    local tex, sprite = self.tex, self.sprite
    local x, y = self.x, self.y
    local rot = self.rot
    local blend, color = self.blend, Color(self.alpha, 255, 255, 255)
    local anchor, scale = {0, 0}, {self.scale, self.scale}
    draw.Rect2D(tex, sprite, blend, anchor, scale, x, y, rot, color)
end

local eff_charge_obj = Class(object)
function eff_charge_obj.create(target)
    local self = New(eff_charge_obj)
    self.group = GROUP_GHOST
    local x, y = target.x, target.y
    task.New(self, function()
        for t = 1, 30 do
            eff_charge_maple.create(x, y)
            task.Wait(2)
        end
        task.Wait(60)
        Del(self)
    end)
    return self
end
function eff_charge_obj:frame()
    task.Do(self)
end

function M.eff_charge(target)
    return eff_charge_obj.create(target)
end

--- boss dead

local BossDead_maple = Class(object)
function BossDead_maple.create(x, y)
    --- @class liu_10_mc.effect.BossDead.BossDead_maple : lstg.GameObject
    local self = New(BossDead_maple)
    self.tex = eff_maple_sprite.tex
    self.sprite = eff_maple_sprite[1]
    self.group = GROUP_GHOST
    self.layer = LAYER_ENEMY_BULLET_EF + 50
    self.bound = false
    self.blend = "mul+add"
    self.rot = 0
    self.omiga = ran2:Float(-180, 180) / 32
    self.scale = (ran2:Float(0, 1) * 3) + 1
    local ra = ran2:Float(-180, 180)
    local rx, ry = 256 * cos(ra), 256 * sin(ra)
    self.x, self.y = x, y
    self.tmp_x, self.tmp_y = x, y
    ra = ran2:Float(-180, 180)
    local rx2, ry2 = 512 * cos(ra), 512 * sin(ra)
    self.pos = moveBezier(90, 0, 0, 0, rx, ry, 0, rx2, ry2, 0)
    self.alpha = 0
    task.New(self, function()
        lerpTo(self, "alpha", 128, 30, 4)
        task.Wait(60)
        lerpTo(self, "alpha", 0, 30, 1)
        lerpTo(self, "scale", 0, 30, 1)
        task.Wait(30)
        Del(self)
    end)
    return self
end
function BossDead_maple:frame()
    task.Do(self)
    if self.pos then
        self.x = self.tmp_x + (self.pos[1][min(max(self.timer + 1, 1), 90)] or 0)
        self.y = self.tmp_y + (self.pos[2][min(max(self.timer + 1, 1), 90)] or 0)
    end
end
function BossDead_maple:render()
    local tex, sprite = self.tex, self.sprite
    local x, y = self.x, self.y
    local rot = self.rot
    local blend, color = self.blend, Color(self.alpha, 255, 255, 255)
    local anchor, scale = {0, 0}, {self.scale, self.scale}
    draw.Rect2D(tex, sprite, blend, anchor, scale, x, y, rot, color)
end

local BossDead_deadcircle = Class(object)
function BossDead_deadcircle.create(x, y)
    --- @class liu_10_mc.effect.BossDead.BossDead_deadcircle : lstg.GameObject
    local self = New(BossDead_deadcircle)
    self.tex = eff_deadcircle_sprite.tex
    self.sprite = eff_deadcircle_sprite[0]
    self.group = GROUP_GHOST
    self.layer = LAYER_ENEMY_BULLET_EF + 50
    self.bound = false
    self.blend = "mul+add"
    self.rot = 0
    self.scale = 0.5
    self.alpha = 255
    self.x, self.y = x, y
    task.New(self, function()
        lerpTo(self, "scale", 5.5, 30, 4)
        lerpTo(self, "alpha", 0, 30, 4)
        task.Wait(30)
        Del(self)
    end)
    return self
end
function BossDead_deadcircle:frame()
    task.Do(self)
end
function BossDead_deadcircle:render()
    local tex, sprite = self.tex, self.sprite
    local x, y = self.x, self.y
    local rot = self.rot
    local blend, color = self.blend, Color(self.alpha, 255, 255, 255)
    local anchor, scale = {0, 0}, {self.scale, self.scale}
    draw.Rect2D(tex, sprite, blend, anchor, scale, x, y, rot, color)
end

local function Boss_explode(b)
    local card = b.current_card
    ---@diagnostic disable-next-line: undefined-field
    local angle = ran:Float(-15, 15)
    ---@diagnostic disable-next-line: undefined-field
    local sign,v = ran:Sign(),1.5
    b.is_exploding = true
    b.killed = true
    b.no_killeff = true
    PlaySound("enep01",0.5)
    b._colli = false
    b.hp = 0
    b.lr = sign * 28
    New(bullet_cleaner, b.x, b.y, 3000, 120, 60, true, true, 0)
    BossDead_deadcircle.create(b.x, b.y)
    if b.protectPlayer then
        ---@diagnostic disable-next-line: inject-field
        player.protect = 120
    end
    task.New(b,function()
         if not b.__dieinstantly then
            for i = 1, 60 do
                b.vx = sign * v * cos(angle)
                b.vy = v * sin(angle)
                b.hp = 0
                b.timer = b.timer - 1
                if ((i - 1) % 2) == 0 then
                    BossDead_maple.create(b.x, b.y)
                end
                task.Wait(1)
            end
        end
        PlaySound("enep01", 0.5, b.x / 256)
        BossDead_deadcircle.create(b.x, b.y)
        for i = 1, 60 do
            BossDead_maple.create(b.x, b.y)
        end
        if b._bosssys then
            local self = b._bosssys
            self:popSpellResult()
            self:popResult(true)
            self:refresh(1)
        end
        if card and card.after then
            task.New(b, function()
                card.after(b)
                Del(b)
            end)
            if b._bosssys then
                local self = b._bosssys
                self:popSpellResult()
			    self:doTask()
            end
		else
			Del(b)
		end
    end)
end

function M.boss_explode(self)
    function self._bosssys:explode()
        Boss_explode(self.boss)
    end
end

--- aura
local eff_aura_color = {
    [0] = {{128, 32, 128}, {128, 0, 128}},
    [1] = {{128, 32, 32}, {128, 0, 0}},
    [2] = {{32, 32, 160}, {0, 0, 160}},
    [3] = {{32, 128, 128}, {0, 128, 128}},
    [4] = {{32, 128, 32}, {0, 128, 0}},
    [5] = {{128, 128, 32}, {128, 128, 0}},
    [6] = {{160, 128, 32}, {160, 128, 0}},
    [7] = {{128, 128, 144}, {128, 128, 160}}
}


local eff_aura_obj00 = Class(object)
function eff_aura_obj00.create(target, co)
    --- @class liu_10_mc.effect.eff_aura.eff_aura_obj00 : lstg.GameObject
    local self = New(eff_aura_obj00)
    self.target = target
    self.tex = eff_aura_sprite.tex
    self.sprite = eff_aura_sprite[0]
    self.layer = LAYER_ENEMY - 5
    self.group = GROUP_GHOST
    self.bound = false
    self.blend = "mul+add"
    self.anchor = {0, 2}
    local dx = ran2:Float(-1, 1) * 4
    local sx, sy = dx, 0
    self.sx, self.sy = sx, sy
    self.alpha = 255
    self.color = eff_aura_color[co][1]
    local s = (ran2:Float(0, 1) * 0.7) + 1
    self.hs, self.vs = s, 1
    task.New(self, function()
        lerpTo(self, "hs", s, 30, 4)
        lerpTo(self, "vs", 1.9, 30, 4)
        lerpTo(self, "alpha", 0, 30, 1)
        task.Wait(30)
        Del(self)
    end)
    return self
end
function eff_aura_obj00:frame()
    task.Do(self)
    if IsValid(self.target) then
        self.x, self.y = self.target.x + self.sx, self.target.y + self.sy
        self.hide = self.target.hide
    else
        Del(self)
    end
end

local eff_aura_obj01 = Class(object)
function eff_aura_obj01.create(target, co)
    --- @class liu_10_mc.effect.eff_aura.eff_aura_obj01 : lstg.GameObject
    local self = New(eff_aura_obj01)
    self.target = target
    self.tex = eff_aura_sprite.tex
    self.sprite = eff_aura_sprite[1]
    self.layer = LAYER_BG + 3
    self.group = GROUP_GHOST
    self.bound = false
    self.blend = "mul+add"
    self.anchor = {0, 0}
    self.rot = ran2:Float(-180, 180)
    self.alpha = 0
    self.color = eff_aura_color[co][2]
    local s = (ran2:Float(0, 1) * 0.7) + 1.6
    self.hs, self.vs = s, s
    task.New(self, function()
        lerpTo(self, "hs", 0.7, 30, 4)
        lerpTo(self, "vs", 0.7, 30, 4)
        lerpTo(self, "alpha", 255, 30, 4)
        task.Wait(30)
        Del(self)
    end)
    return self
end
function eff_aura_obj01:frame()
    task.Do(self)
    if IsValid(self.target) then
        self.x, self.y = self.target.x, self.target.y
        self.hide = self.target.hide
    else
        Del(self)
    end
end
function eff_aura_obj01:render()
    local tex, sprite = self.tex, self.sprite
    local x, y = self.x, self.y
    local rot = self.rot
    local blend, color = self.blend, Color(self.alpha, unpack(self.color))
    local anchor, scale = self.anchor, {self.hs, self.vs}
    draw.Rect2D(tex, sprite, blend, anchor, scale, x, y, rot, color)
end

local eff_aura_obj02 = Class(object)
function eff_aura_obj02.create(target)
    --- @class liu_10_mc.effect.eff_aura.eff_aura_obj02 : lstg.GameObject
    local self = New(eff_aura_obj02)
    self.target = target
    self.tex = eff_aura_sprite.tex
    self.sprite = eff_aura_sprite[1]
    self.layer = LAYER_ENEMY - 5
    self.group = GROUP_GHOST
    self.bound = false
    self.blend = "mul+add"
    self.anchor = {0, 0}
    self.rot = ran2:Float(-180, 180)
    self.alpha = 0
    self.color = {255, 255, 255}
    local s = (ran2:Float(0, 1) * 0.7) + 2
    self.hs, self.vs = s, s
    task.New(self, function()
        lerpTo(self, "hs", 1.2, 30, 4)
        lerpTo(self, "vs", 1.2, 30, 4)
        lerpTo(self, "alpha", 64, 30, 4)
        task.Wait(30)
        Del(self)
    end)
end
function eff_aura_obj02:frame()
    task.Do(self)
    if IsValid(self.target) then
        self.x, self.y = self.target.x, self.target.y
        self.hide = self.target.hide
    else
        Del(self)
    end
end
function eff_aura_obj02:render()
    local tex, sprite = self.tex, self.sprite
    local x, y = self.x, self.y
    local rot = self.rot
    local blend, color = self.blend, Color(self.alpha, unpack(self.color))
    local anchor, scale = self.anchor, {self.hs, self.vs}
    draw.Rect2D(tex, sprite, blend, anchor, scale, x, y, rot, color)
end

local create_eff_aura = Class(object)
function create_eff_aura.create(target, co)
    --- @class liu_10_mc.effect.eff_aura.create_eff_aura : lstg.GameObject
    local self = New(create_eff_aura)
    self.target = target
    self.x, self.y = target.x, target.y
    self.group = GROUP_GHOST
    self.bound = false
    task.New(self, function()
        while true do
            eff_aura_obj00.create(target, co)
            task.Wait(3)
            eff_aura_obj01.create(target, co)
            task.Wait(1)
            eff_aura_obj02.create(target)
            task.Wait(2)
        end
    end)
    return self
end
function create_eff_aura:frame()
    task.Do(self)
    if IsValid(self.target) then
        self.x, self.y = self.target.x, self.target.y
        self.hide = self.target.hide
    else
        Del(self)
    end
end

function M.SetBossEffAura(target, co)
    target.eff_aura = create_eff_aura.create(target, co)
end

--- spell ring
local spell_ring00 = plus.Class()
function spell_ring00.create(obj, maxt)
    local self = spell_ring00()
    self.obj = obj
    self.tex = eff_line_sprite.tex
    self.sprite = eff_line_sprite[1]
    self.nmax = 32
    self.rep = 3
    self.maxtime = maxt
    self.alpha = 0
    self.rot = 0
    self.omiga = 18
    self.width, self.radius = 16, 16
    self.timer = -1
    return self
end
function spell_ring00:frame()
    if not self.obj then return end
    self.timer = self.timer + 1
    if self.timer >= 0 and self.timer < 40 then
        local t = self.timer
        self.alpha = lerp(0, 128, min(t / 8, 1), 0)
        self.radius = lerp(16, 320, min(t / 40, 1), 4)
    elseif self.timer >= 40 and self.timer < 80 then
        local t = self.timer - 40
        self.radius = lerp(320, 172, min(t / 40, 1), 1)
        if self.omiga ~= -6 then self.omiga = -6 end
    elseif self.timer >= 80 and self.timer < (self.maxtime) then
        local t = self.timer - 80
        local maxt = self.maxtime
        self.width = lerp(16, 14, min(t / maxt, 1), 0)
        self.radius = lerp(172, 16, min(t / maxt, 1), 0)
        if self.omiga ~= -3 then self.omiga = -3 end
    elseif self.timer >= (self.maxtime) and self.timer < (self.maxtime + 20) then
        local t = self.timer - (self.maxtime)
        self.alpha = lerp(128, 0, min(t / 20, 1), 0)
    elseif self.timer >= (self.maxtime) then
        self.delete = true
    end
    self.rot = self.rot + self.omiga
end
function spell_ring00:render()
    if not self.obj or not IsValid(self.obj) then return end
    local obj = self.obj
    local tex, sprite = self.tex, self.sprite
    local x, y = obj.x, obj.y
    local rot = self.rot
    local alpha = self.alpha
    local nmax, rep = self.nmax, self.rep
    local width, radius = self.width, self.radius
    local color = Color(alpha, 255, 255, 255)
    draw.texCircle(tex, sprite, "mul+add", nmax, radius, width, rep, x, y, rot, color)
end

local spell_ring01 = plus.Class()
function spell_ring01.create(obj, maxt)
    local self = spell_ring01()
    self.obj = obj
    self.tex = eff_line_sprite.tex
    self.sprite = eff_line_sprite[2]
    self.nmax = 32
    self.rep = 3
    self.maxtime = maxt
    self.alpha = 0
    self.rot = 0
    self.omiga = -18
    self.width, self.radius = 16, 16
    self.timer = -1
    return self
end
function spell_ring01:frame()
    if not self.obj then return end
    self.timer = self.timer + 1
    if self.timer >= 0 and self.timer < 80 then
        local t = self.timer
        self.alpha = lerp(0, 128, min(t / 8, 1), 0)
        self.radius = lerp(16, 160, min(t / 80, 1), 4)
    elseif self.timer >= 80 and self.timer < (self.maxtime) then
        local t = self.timer - 80
        local maxt = self.maxtime
        self.width = lerp(16, 14, min(t / maxt, 1), 0)
        self.radius = lerp(160, 16, min(t / maxt, 1), 0)
        if self.omiga ~= -3.6 then self.omiga = -3.6 end
    elseif self.timer >= (self.maxtime) and self.timer < (self.maxtime + 20) then
        local t = self.timer - (self.maxtime)
        self.alpha = lerp(128, 0, min(t / 20, 1), 0)
    elseif self.timer >= (self.maxtime + 20) then
        self.delete = true
    end
    self.rot = self.rot + self.omiga
end
function spell_ring01:render()
    if not self.obj or not IsValid(self.obj) then return end
    local obj = self.obj
    local tex, sprite = self.tex, self.sprite
    local x, y = obj.x, obj.y
    local rot = self.rot
    local alpha = self.alpha
    local nmax, rep = self.nmax, self.rep
    local width, radius = self.width, self.radius
    local color = Color(alpha, 255, 255, 255)
    draw.texCircle(tex, sprite, "mul+add", nmax, radius, width, rep, x, y, rot, color)
end

local create_spell_ring = Class(object)
function create_spell_ring.create(obj, maxt)
    --- @class liu_10_mc.effect.eff_aura.create_spell_ring : lstg.GameObject
    local self = New(create_spell_ring)
    self.obj = obj
    self.ring = {
        spell_ring00.create(self, maxt),
        spell_ring01.create(self, maxt)
    }
    self.x, self.y = obj.x, obj.y
    self.layer = LAYER_BG + 5
    self.group = GROUP_GHOST
    self.bound = false
    return self
end
function create_spell_ring:frame()
    if not self.obj or not IsValid(self.obj) then return end
    local del_num = 0
    for _, ring in ipairs(self.ring) do
        if not ring.delete then
            ring:frame()
        else
            del_num = del_num + 1
        end
    end
    if del_num == #self.ring then Del(self) end
    if IsValid(self.obj) then
        local obj = self.obj
        if obj.hp <= 0 then Del(self) end
        do
            local minspeed = 0.5
            local ratespeed = 0.08
            local speed = Dist(self, obj)
            local angle = Angle(self, obj)
            speed = min(speed, max(speed * ratespeed, minspeed))
            self.x = self.x + speed * cos(angle)
            self.y = self.y + speed * sin(angle)
        end
    else
        Del(self)
    end
end
function create_spell_ring:render()
    if not self.obj then return end
    for _, ring in ipairs(self.ring) do
        if not ring.delete then
            ring:render()
        end
    end
end

function M.CreateBossSpellRing(obj, maxt)
    return create_spell_ring.create(obj, maxt)
end

return M