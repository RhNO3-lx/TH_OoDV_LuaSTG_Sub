local calc = require("liu_10_mc.script.lib.liu_10_mc_math")
local draw = require("liu_10_mc.script.lib.liu_10_mc_render")

local lerp = calc.lerp
local lerpTo = calc.lerpTo

local ran2 = calc.rnd

local M = {}

function M.loadResource()
    local dir = "liu_10_mc/img/front/"
    LoadTexture("liu_10_mc_st02logo:linear", dir .. "liu_10_mc_st02logo.png")
    SetTextureSamplerState("liu_10_mc_st02logo:linear", "linear+wrap")
    LoadTexture("liu_10_mc_st02logo:point", dir .. "liu_10_mc_st02logo.png")
    SetTextureSamplerState("liu_10_mc_st02logo:point", "point+wrap")
end

local st02logo_sprite = {
    tex = "liu_10_mc_st02logo",
    [0] = {x = 0, y = 0, w = 384, h = 32},
    [1] = {x = 0, y = 32, w = 384, h = 16},
    [2] = {x = 0, y = 48, w = 384, h = 32},
    [3] = {x = 0, y = 80, w = 384, h = 16},
    [4] = {x = 0, y = 96, w = 384, h = 16},
}

--- bgm text
local bgmtext = Class(object)
function bgmtext.create(idx)
    --- @class liu_10_mc.bgmtext : lstg.GameObject
    local self = New(bgmtext)
    self.tex = st02logo_sprite.tex .. ":point"
    self.sprite = st02logo_sprite[3 + idx]
    self.layer = LAYER_TOP + 5
    self.group = GROUP_GHOST
    self.bound = false
    self.anchor = {1, 2}
    self.alpha = 255
    self.x, self.y = lstg.world.scrr, 464
    task.New(self, function()
        task.Wait(60)
        lerpTo(self, "x", lstg.world.scrl, 60, 1)
        lerpTo(self, "y", 464, 60, 1)
        task.Wait(260)
        lerpTo(self, "alpha", 0, 20, 0)
        lerpTo(self, "x", lstg.world.scrl, 20, 1)
        lerpTo(self, "y", 480, 20, 1)
        task.Wait(20)
        Del(self)
    end)
    return self
end
function bgmtext:frame()
    task.Do(self)
end
function bgmtext:render()
    SetViewMode("ui")
    local tex, sprite = self.tex, self.sprite
    local x, y = self.x, 480 - self.y
    local color = Color(self.alpha, 255, 255, 255)
    local anchor = self.anchor
    draw.Rect2D(tex, sprite, "", anchor, 1, x, y, 0, color)
    SetViewMode("world")
end

function M.createBgmText(idx)
    return bgmtext.create(idx)
end

--- stage logo
local st02logo00 = plus.Class()
function st02logo00.create()
    --- @class liu_10_mc.st02logo00
    local self = st02logo00()
    self.tex = st02logo_sprite.tex .. ":point"
    self.sprite = st02logo_sprite[0]
    self.alpha = 0
    self.x, self.y = 224, 192
    task.New(self, function()
        task.Wait(60)
        lerpTo(self, "alpha", 255, 50, 0)
        task.Wait(260)
        lerpTo(self, "alpha", 0, 60, 0)
        task.Wait(60)
        self.delete = true
    end)
    return self
end
function st02logo00:frame()
    task.Do(self)
end
function st02logo00:render()
    local tex, sprite = self.tex, self.sprite
    local x, y = -224 + self.x, 224 - self.y
    local color = Color(self.alpha, 255, 255, 255)
    draw.Rect2D(tex, sprite, "", {0, 0}, 1, x, y, 0, color)
end

local st02logo01 = plus.Class()
function st02logo01.create()
    --- @class liu_10_mc.st02logo01
    local self = st02logo01()
    self.tex = st02logo_sprite.tex .. ":linear"
    self.sprite = st02logo_sprite[2]
    self.alpha = 0
    self.x, self.y = 224, 200
    self.hs, self.vs = 2, 0
    task.New(self, function()
        lerpTo(self, "alpha", 255, 50, 0)
        lerpTo(self, "hs", 1, 60, 0)
        lerpTo(self, "vs", 1, 60, 0)
        task.Wait(280)
        lerpTo(self, "hs", 1, 60, 0)
        lerpTo(self, "vs", 0, 60, 0)
        task.Wait(60)
        self.delete = true
    end)
    return self
end
function st02logo01:frame()
    task.Do(self)
end
function st02logo01:render()
    local tex, sprite = self.tex, self.sprite
    local x, y = -224 + self.x, 224 - self.y
    local color = Color(self.alpha, 255, 255, 255)
    local hs, vs = self.hs, self.vs
    local scale = {hs, vs}
    draw.Rect2D(tex, sprite, "", {0, 0}, scale, x, y, 0, color)
end

local st02logo02 = plus.Class()
function st02logo02.create()
    --- @class liu_10_mc.st02logo02
    local self = st02logo02()
    self.tex = st02logo_sprite.tex .. ":point"
    self.sprite = st02logo_sprite[1]
    self.x, self.y = 224, 216
    self.alpha = 255
    task.New(self, function()
        task.Wait(90)
        lerpTo(self, "alpha", 255, 10, 0)
        task.Wait(230)
        lerpTo(self, "alpha", 0, 60, 0)
        task.Wait(60)
        self.delete = true
    end)
    return self
end
function st02logo02:frame()
    task.Do(self)
end
function st02logo02:render()
    local tex, sprite = self.tex, self.sprite
    local x, y = -224 + self.x, 224 - self.y
    local color = Color(self.alpha, 255, 255, 255)
    draw.Rect2D(tex, sprite, "", {0, 0}, 1, x, y, 0, color)
end

local st02logo = Class(object)
function st02logo.create()
    --- @class liu_10_mc.st02logo : lstg.GameObject
    local self = New(st02logo)
    self.layer = LAYER_TOP + 5
    self.group = GROUP_GHOST
    self.child = {
        st02logo01.create(),
        st02logo00.create(),
        st02logo02.create(),
    }
end
function st02logo:frame()
    local del_num = 0
    for _, v in ipairs(self.child) do
        if not v.delete then
            v:frame()
        else
            del_num = del_num + 1
        end
    end
    if del_num == #self.child then Del(self) end
end
function st02logo:render()
    for _, v in ipairs(self.child) do
        if not v.delete then
            v:render()
        end
    end
end

function M.createSt02Logo()
    return st02logo.create()
end

return M