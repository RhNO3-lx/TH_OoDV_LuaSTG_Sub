local draw = require("liu_10_mc.script.lib.liu_10_mc_render")

local texname = {
    "rt:screen_world_tex01",
    "rt:screen_world_tex02",
}

local function createResource()
    for i, v in ipairs(texname) do
        if not lstg.CheckRes(1, v) then
            if i == 1 then
                CreateRenderTarget(v)
            elseif i == 2 then
                CreateRenderTarget(v, 640, 480)
            end
        end
        SetTextureSamplerState(v, "point+wrap")
    end
end

local _objPush = Class(object)
local _objPop = Class(object)

function _objPush.create(LayerA)
    ---@class objPush : lstg.GameObject
    local self = New(_objPush)
    self.layer = LayerA
    self.group = GROUP_GHOST
    return self
end
function _objPush:render()
    PushRenderTarget(texname[1])
    RenderClear(Color(0, 0, 0, 0))
end
function _objPop.create(LayerA, layerB)
    ---@class objPop : lstg.GameObject
    local self = New(_objPop)
    self.layer = layerB
    self.group = GROUP_GHOST
    _objPush.create(LayerA)
    return self
end

local function _DrawTexture()
    local canvas_w, canvas_h = 640, 480
    local s = screen.scale
    local dx, dy = screen.dx, screen.dy
    local sprite = {x = dx, y = dy, w = canvas_w * s, h = canvas_h * s}
    local tex = texname[1]
    local color = Color(255, 255, 255, 255)
    draw.viewModeWindow()
    draw.Rect2D(tex, sprite, "mul+alpha", {1, 2}, 0.5, 0, 0, 0, color)
    SetViewMode("world")
end

function _objPop:render()
    PopRenderTarget()
    PushRenderTarget(texname[2])
    RenderClear(Color(0, 0, 0, 0))
    _DrawTexture()
    PopRenderTarget()
    local canvas_w, canvas_h = 640, 480
    local s = screen.scale
    local dx, dy = screen.dx, screen.dy
    local sprite = {x = dx, y = dy, w = canvas_w, h = canvas_h}
    local tex = texname[2]
    local color = Color(255, 255, 255, 255)
    draw.viewModeWindow()
    draw.Rect2D(tex, sprite, "mul+alpha", {1, 2}, 2, 0 + dx, 0 + dy, 0, color)
    SetViewMode("world")
end

local function liu_10_mc_ScreenScale()
    createResource()
    LayerA = LayerA or LAYER_BG - 102
    LayerB = LayerB or LAYER_TOP + 0.9
    return _objPop.create(LayerA, LayerB)
end

return liu_10_mc_ScreenScale