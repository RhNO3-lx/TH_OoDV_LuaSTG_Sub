local calc = require("liu_10_mc.script.lib.liu_10_mc_math")
local draw = require("liu_10_mc.script.lib.liu_10_mc_render")
local wisys = require("liu_10_mc.script.lib.liu_10_mc_walkimageSystem")

local ran2 = calc.rnd

local M = {}

local function loadResource()
    local dir = "liu_10_mc/img/enemy/"
    LoadTexture("liu_10_mc_enemy", dir .. "liu_10_mc_enemy.png")
    LoadTexture("liu_10_mc_enemy2", dir .. "liu_10_mc_enemy2.png")
end
M.loadResource = loadResource

--- sprite

local enemy_walk_sprite = {}

enemy_walk_sprite["Fairy"] = {
    tex = "liu_10_mc_enemy",
    [0] = {x = 0, y = 256, w = 32, h = 32},
    [1] = {x = 32, y = 256, w = 32, h = 32},
    [2] = {x = 64, y = 256, w = 32, h = 32},
    [3] = {x = 96, y = 256, w = 32, h = 32},
    [4] = {x = 128, y = 256, w = 32, h = 32},
    [5] = {x = 160, y = 256, w = 32, h = 32},
    [6] = {x = 192, y = 256, w = 32, h = 32},
    [7] = {x = 224, y = 256, w = 32, h = 32},
    [8] = {x = 256, y = 256, w = 32, h = 32},
    [9] = {x = 288, y = 256, w = 32, h = 32},
    [10] = {x = 320, y = 256, w = 32, h = 32},
    [11] = {x = 352, y = 256, w = 32, h = 32},
    [12] = {x = 0, y = 288, w = 32, h = 32},
    [13] = {x = 32, y = 288, w = 32, h = 32},
    [14] = {x = 64, y = 288, w = 32, h = 32},
    [15] = {x = 96, y = 288, w = 32, h = 32},
    [16] = {x = 128, y = 288, w = 32, h = 32},
    [17] = {x = 160, y = 288, w = 32, h = 32},
    [18] = {x = 192, y = 288, w = 32, h = 32},
    [19] = {x = 224, y = 288, w = 32, h = 32},
    [20] = {x = 256, y = 288, w = 32, h = 32},
    [21] = {x = 288, y = 288, w = 32, h = 32},
    [22] = {x = 320, y = 288, w = 32, h = 32},
    [23] = {x = 352, y = 288, w = 32, h = 32},
    [24] = {x = 0, y = 320, w = 32, h = 32},
    [25] = {x = 32, y = 320, w = 32, h = 32},
    [26] = {x = 64, y = 320, w = 32, h = 32},
    [27] = {x = 96, y = 320, w = 32, h = 32},
    [28] = {x = 128, y = 320, w = 32, h = 32},
    [29] = {x = 160, y = 320, w = 32, h = 32},
    [30] = {x = 192, y = 320, w = 32, h = 32},
    [31] = {x = 224, y = 320, w = 32, h = 32},
    [32] = {x = 256, y = 320, w = 32, h = 32},
    [33] = {x = 288, y = 320, w = 32, h = 32},
    [34] = {x = 320, y = 320, w = 32, h = 32},
    [35] = {x = 352, y = 320, w = 32, h = 32},
    [36] = {x = 0, y = 352, w = 32, h = 32},
    [37] = {x = 32, y = 352, w = 32, h = 32},
    [38] = {x = 64, y = 352, w = 32, h = 32},
    [39] = {x = 96, y = 352, w = 32, h = 32},
    [40] = {x = 128, y = 352, w = 32, h = 32},
    [41] = {x = 160, y = 352, w = 32, h = 32},
    [42] = {x = 192, y = 352, w = 32, h = 32},
    [43] = {x = 224, y = 352, w = 32, h = 32},
    [44] = {x = 256, y = 352, w = 32, h = 32},
    [45] = {x = 288, y = 352, w = 32, h = 32},
    [46] = {x = 320, y = 352, w = 32, h = 32},
    [47] = {x = 352, y = 352, w = 32, h = 32},
    [48] = {x = 0, y = 32, w = 32, h = 32},
    [49] = {x = 32, y = 32, w = 32, h = 32},
    [50] = {x = 64, y = 32, w = 32, h = 32},
    [51] = {x = 96, y = 32, w = 32, h = 32},
    [52] = {x = 128, y = 32, w = 32, h = 32},
    [53] = {x = 160, y = 32, w = 32, h = 32},
    [54] = {x = 192, y = 32, w = 32, h = 32},
    [55] = {x = 224, y = 32, w = 32, h = 32},
    [56] = {x = 256, y = 32, w = 32, h = 32},
    [57] = {x = 288, y = 32, w = 32, h = 32},
    [58] = {x = 320, y = 32, w = 32, h = 32},
    [59] = {x = 352, y = 32, w = 32, h = 32},
}

enemy_walk_sprite["Dead Fairy"] = {
    tex = "liu_10_mc_enemy",
    [0] = {x = 0, y = 0, w = 32, h = 32},
    [1] = {x = 32, y = 0, w = 32, h = 32},
    [2] = {x = 64, y = 0, w = 32, h = 32},
    [3] = {x = 96, y = 0, w = 32, h = 32},
    [4] = {x = 128, y = 0, w = 32, h = 32},
}

enemy_walk_sprite["Great Fairy"] = {
    tex = "liu_10_mc_enemy",
    [0] = {x = 0, y = 384, w = 64, h = 64},
    [1] = {x = 64, y = 384, w = 64, h = 64},
    [2] = {x = 128, y = 384, w = 64, h = 64},
    [3] = {x = 192, y = 384, w = 64, h = 64},
    [4] = {x = 256, y = 384, w = 64, h = 64},
    [5] = {x = 320, y = 384, w = 64, h = 64},
    [6] = {x = 384, y = 384, w = 64, h = 64},
    [7] = {x = 448, y = 384, w = 64, h = 64},
    [8] = {x = 384, y = 256, w = 64, h = 64},
    [9] = {x = 448, y = 256, w = 64, h = 64},
    [10] = {x = 384, y = 320, w = 64, h = 64},
    [11] = {x = 448, y = 320, w = 64, h = 64},
}

enemy_walk_sprite["Kedama"] = {
    tex = "liu_10_mc_enemy",
    [0] = {x = 64, y = 128, w = 32, h = 32},
    [1] = {x = 96, y = 128, w = 32, h = 32},
    [2] = {x = 64, y = 160, w = 32, h = 32},
    [3] = {x = 96, y = 160, w = 32, h = 32},
}

enemy_walk_sprite["Wheel Ghost"] = {
    tex = "liu_10_mc_enemy",
    [0] = {x = 128, y = 192, w = 32, h = 32},
    [1] = {x = 160, y = 192, w = 32, h = 32},
    [2] = {x = 192, y = 192, w = 32, h = 32},
    [3] = {x = 224, y = 192, w = 32, h = 32},
    [4] = {x = 128, y = 224, w = 32, h = 32},
    [5] = {x = 160, y = 224, w = 32, h = 32},
    [6] = {x = 192, y = 224, w = 32, h = 32},
    [7] = {x = 224, y = 224, w = 32, h = 32},
}

enemy_walk_sprite["Enemy Ring"] = {
    tex = "liu_10_mc_enemy",
    [0] = {x = 0, y = 224, w = 32, h = 32},
    [1] = {x = 32, y = 224, w = 32, h = 32},
    [2] = {x = 64, y = 224, w = 32, h = 32},
    [3] = {x = 96, y = 224, w = 32, h = 32},
}

enemy_walk_sprite["Stone"] = {
    tex = "liu_10_mc_enemy",
    [0] = {x = 128, y = 128, w = 64, h = 64},
    [1] = {x = 192, y = 128, w = 48, h = 48},
    [2] = {x = 240, y = 128, w = 48, h = 48},
    [3] = {x = 288, y = 128, w = 32, h = 32},
    [4] = {x = 320, y = 128, w = 32, h = 32},
    [5] = {x = 352, y = 128, w = 32, h = 32},
}

enemy_walk_sprite["Onibi"] = {
    tex = "liu_10_mc_enemy2",
    [0] = {x = 0, y = 0, w = 32, h = 32},
    [1] = {x = 32, y = 0, w = 32, h = 32},
    [2] = {x = 64, y = 0, w = 32, h = 32},
    [3] = {x = 96, y = 0, w = 32, h = 32},
    [4] = {x = 128, y = 0, w = 32, h = 32},
    [5] = {x = 160, y = 0, w = 32, h = 32},
    [6] = {x = 192, y = 0, w = 32, h = 32},
    [7] = {x = 224, y = 0, w = 32, h = 32},
    [8] = {x = 0, y = 32, w = 32, h = 32},
    [9] = {x = 32, y = 32, w = 32, h = 32},
    [10] = {x = 64, y = 32, w = 32, h = 32},
    [11] = {x = 96, y = 32, w = 32, h = 32},
    [12] = {x = 128, y = 32, w = 32, h = 32},
    [13] = {x = 160, y = 32, w = 32, h = 32},
    [14] = {x = 192, y = 32, w = 32, h = 32},
    [15] = {x = 224, y = 32, w = 32, h = 32},
    [16] = {x = 0, y = 64, w = 32, h = 32},
    [17] = {x = 32, y = 64, w = 32, h = 32},
    [18] = {x = 64, y = 64, w = 32, h = 32},
    [19] = {x = 96, y = 64, w = 32, h = 32},
    [20] = {x = 128, y = 64, w = 32, h = 32},
    [21] = {x = 160, y = 64, w = 32, h = 32},
    [22] = {x = 192, y = 64, w = 32, h = 32},
    [23] = {x = 224, y = 64, w = 32, h = 32},
    [24] = {x = 0, y = 96, w = 32, h = 32},
    [25] = {x = 32, y = 96, w = 32, h = 32},
    [26] = {x = 64, y = 96, w = 32, h = 32},
    [27] = {x = 96, y = 96, w = 32, h = 32},
    [28] = {x = 128, y = 96, w = 32, h = 32},
    [29] = {x = 160, y = 96, w = 32, h = 32},
    [30] = {x = 192, y = 96, w = 32, h = 32},
    [31] = {x = 224, y = 96, w = 32, h = 32},
}

local function addFairyWalk(id)
    --- @type fun(self: liu_10_mc.WalkImageSystem)[]
    local scripts = {
        function(self)
            task.New(self, function()
                self.layer = 7
                while true do
                    self:Sprite(id + 0)
                    task.Wait(5)
                    self:Sprite(id + 1)
                    task.Wait(5)
                    self:Sprite(id + 2)
                    task.Wait(5)
                    self:Sprite(id + 3)
                end
            end)
        end,
        function(self)
            task.New(self, function()
                self.layer = 7
                self:FilpX()
                self:Sprite(id + 4)
                task.Wait(4)
                self:Sprite(id + 5)
                task.Wait(4)
                self:Sprite(id + 6)
                task.Wait(4)
                self:Sprite(id + 7)
                task.Wait(4)
                while true do
                    self:Sprite(id + 8)
                    task.Wait(5)
                    self:Sprite(id + 9)
                    task.Wait(5)
                    self:Sprite(id + 10)
                    task.Wait(5)
                    self:Sprite(id + 11)
                    task.Wait(5)
                end
            end)
        end,
        function(self)
            task.New(self, function()
                self.layer = 7
                self:Sprite(id + 4)
                task.Wait(4)
                self:Sprite(id + 5)
                task.Wait(4)
                self:Sprite(id + 6)
                task.Wait(4)
                self:Sprite(id + 7)
                task.Wait(4)
                while true do
                    self:Sprite(id + 8)
                    task.Wait(5)
                    self:Sprite(id + 9)
                    task.Wait(5)
                    self:Sprite(id + 10)
                    task.Wait(5)
                    self:Sprite(id + 11)
                    task.Wait(5)
                end
            end)
        end,
        function(self)
            task.New(self, function()
                self.layer = 7
                self:FilpX()
                self:Sprite(id + 7)
                task.Wait(4)
                self:Sprite(id + 6)
                task.Wait(4)
                self:Sprite(id + 5)
                task.Wait(4)
                self:Sprite(id + 4)
                task.Wait(4)
                while true do
                    self:Sprite(id + 0)
                    task.Wait(5)
                    self:Sprite(id + 1)
                    task.Wait(5)
                    self:Sprite(id + 2)
                    task.Wait(5)
                    self:Sprite(id + 3)
                    task.Wait(5)
                end
            end)
        end,
        function(self)
            task.New(self, function()
                self.layer = 7
                self:Sprite(id + 7)
                task.Wait(4)
                self:Sprite(id + 6)
                task.Wait(4)
                self:Sprite(id + 5)
                task.Wait(4)
                self:Sprite(id + 4)
                task.Wait(4)
                while true do
                    self:Sprite(id + 0)
                    task.Wait(5)
                    self:Sprite(id + 1)
                    task.Wait(5)
                    self:Sprite(id + 2)
                    task.Wait(5)
                    self:Sprite(id + 3)
                    task.Wait(5)
                end
            end)
        end,
    }
    return enemy_walk_sprite["Fairy"], scripts
end

local function addDeadFairyWalk(id)
    --- @type fun(self: liu_10_mc.WalkImageSystem)[]
    local scripts = {
        function(self)
            task.New(self, function()
                self.layer = 8
                self:Sprite(id + 0)
                self:Alpha(128)
            end)
        end,
    }
    return enemy_walk_sprite["Dead Fairy"], scripts
end

local function addGreatFairyWalk(id)
    --- @type fun(self: liu_10_mc.WalkImageSystem)[]
    local scripts = {
        function(self)
            task.New(self, function()
                self.layer = 7
                while true do
                    self:Sprite(id + 0)
                    task.Wait(5)
                    self:Sprite(id + 1)
                    task.Wait(5)
                    self:Sprite(id + 2)
                    task.Wait(5)
                    self:Sprite(id + 3)
                end
            end)
        end,
        function(self)
            task.New(self, function()
                self.layer = 7
                self:FilpX()
                self:Sprite(id + 4)
                task.Wait(4)
                self:Sprite(id + 5)
                task.Wait(4)
                self:Sprite(id + 6)
                task.Wait(4)
                self:Sprite(id + 7)
                task.Wait(4)
                while true do
                    self:Sprite(id + 8)
                    task.Wait(5)
                    self:Sprite(id + 9)
                    task.Wait(5)
                    self:Sprite(id + 10)
                    task.Wait(5)
                    self:Sprite(id + 11)
                    task.Wait(5)
                end
            end)
        end,
        function(self)
            task.New(self, function()
                self.layer = 7
                self:Sprite(id + 4)
                task.Wait(4)
                self:Sprite(id + 5)
                task.Wait(4)
                self:Sprite(id + 6)
                task.Wait(4)
                self:Sprite(id + 7)
                task.Wait(4)
                while true do
                    self:Sprite(id + 8)
                    task.Wait(5)
                    self:Sprite(id + 9)
                    task.Wait(5)
                    self:Sprite(id + 10)
                    task.Wait(5)
                    self:Sprite(id + 11)
                    task.Wait(5)
                end
            end)
        end,
        function(self)
            task.New(self, function()
                self.layer = 7
                self:FilpX()
                self:Sprite(id + 7)
                task.Wait(4)
                self:Sprite(id + 6)
                task.Wait(4)
                self:Sprite(id + 5)
                task.Wait(4)
                self:Sprite(id + 4)
                task.Wait(4)
                while true do
                    self:Sprite(id + 0)
                    task.Wait(5)
                    self:Sprite(id + 1)
                    task.Wait(5)
                    self:Sprite(id + 2)
                    task.Wait(5)
                    self:Sprite(id + 3)
                    task.Wait(5)
                end
            end)
        end,
        function(self)
            task.New(self, function()
                self.layer = 7
                self:Sprite(id + 7)
                task.Wait(4)
                self:Sprite(id + 6)
                task.Wait(4)
                self:Sprite(id + 5)
                task.Wait(4)
                self:Sprite(id + 4)
                task.Wait(4)
                while true do
                    self:Sprite(id + 0)
                    task.Wait(5)
                    self:Sprite(id + 1)
                    task.Wait(5)
                    self:Sprite(id + 2)
                    task.Wait(5)
                    self:Sprite(id + 3)
                    task.Wait(5)
                end
            end)
        end,
    }
    return enemy_walk_sprite["Great Fairy"], scripts
end

local function addKedamaWalk(id)
    --- @type fun(self: liu_10_mc.WalkImageSystem)[]
    local scripts = {
        function(self)
            task.New(self, function()
                self.layer = 6
                self:Sprite(id + 0)
                self:AngleVel(18)
            end)
        end,
    }
    return enemy_walk_sprite["Kedama"], scripts
end

local function addKedamaWalk_fadein(id)
    --- @type fun(self: liu_10_mc.WalkImageSystem)[]
    local scripts = {
        function(self)
            task.New(self, function()
                self:AngleVel(18)
                self.layer = 6
                self:Sprite(id + 0)
                self:Alpha(0)
                self:Scale(0.0, 0.0)
                task.Wait(46)
                self:AlphaTime(30, 0, 255)
                self:ScaleTime(30, 0, 1.0, 1.0)
            end)
        end,
    }
    return enemy_walk_sprite["Kedama"], scripts
end

local function addWheelGhostWalk(id)
    --- @type fun(self: liu_10_mc.WalkImageSystem)[][]
    local chlid_script = {
        {
            function(self)
                task.New(self, function()
                    self.layer = 8
                    self:Sprite(id + 4)
                    self:AngleVel(-11.25)
                end)
            end,
        },
        {
            function(self)
                task.New(self, function()
                    self.layer = 8
                    self:Sprite(id + 4)
                    self:AngleVel(5.625)
                    self:Blend("mul+add")
                    self:Scale(1.5, 1.5)
                end)
            end,
        }
    }
    local sprites = enemy_walk_sprite["Wheel Ghost"]
    --- @type fun(self: liu_10_mc.WalkImageSystem)[]
    local scripts = {
        function(self)
            task.New(self, function()
                self.layer = 7
                self:Sprite(id + 0)
                self:addChild(wisys.create(self.obj, sprites, chlid_script[1], 1))
                self:addChild(wisys.create(self.obj, sprites, chlid_script[2], 1))
            end)
        end,
    }
    return sprites, scripts
end

local function addWheelGhostWalk_fadein(id)
    --- @type fun(self: liu_10_mc.WalkImageSystem)[][]
    local chlid_script = {
        {
            function(self)
                task.New(self, function()
                    self.layer = 8
                    self:Sprite(id + 4)
                    self:AngleVel(-11.25)
                    self:Color(0, 0, 32)
                    self:ColorTime(60, 0, 192, 192, 255)
                    self:Scale(0.2, 0.2)
                    self:ScaleTime(60, 0, 1, 1)
                end)
            end,
        },
        {
            function(self)
                task.New(self, function()
                    self.layer = 8
                    self:Sprite(id + 4)
                    self:AngleVel(5.625)
                    self:Color(0, 0, 32)
                    self:ColorTime(60, 0, 192, 192, 255)
                    self:Scale(0.3, 0.3)
                    self:ScaleTime(60, 0, 1.5, 1.5)
                end)
            end,
        }
    }
    local sprites = enemy_walk_sprite["Wheel Ghost"]
    --- @type fun(self: liu_10_mc.WalkImageSystem)[]
    local scripts = {
        function(self)
            task.New(self, function()
                self.layer = 7
                self:Sprite(id + 0)
                self:Color(0, 0, 32)
                self:ColorTime(60, 0, 192, 192, 255)
                self:Scale(0.2, 0.2)
                self:ScaleTime(60, 0, 1, 1)
                self:addChild(wisys.create(self.obj, sprites, chlid_script[1], 1))
                self:addChild(wisys.create(self.obj, sprites, chlid_script[2], 1))
            end)
        end,
    }
    return sprites, scripts
end

local function addEnemyRing(obj, id, mode)
    --- @type fun(self: liu_10_mc.WalkImageSystem)[]
    local scripts = {
        function(self)
            task.New(self, function()
                self:Blend("mul+add")
                self:Sprite(id + 0)
                self:Alpha(128)
                self:AngleVel(-18)
                self:Scale(0, 0)
                while true do
                    self:ScaleTime(20, 9, 1.4, 1.4)
                    task.Wait(20)
                    self:ScaleTime(20, 9, 1, 1)
                    task.Wait(20)
                end
            end)
        end,
        function(self)
            task.New(self, function()
                self:AngleVel(-18)
                self:Blend("mul+add")
                self:Sprite(id + 0)
                self:Alpha(0)
                self:AlphaTime(76, 0, 192)
                self:Scale(4, 4)
                self:ScaleTime(76, 0, 1, 1)
                task.Wait(76)
                while true do
                    self:ScaleTime(20, 9, 1.4, 1.4)
                    task.Wait(20)
                    self:ScaleTime(20, 9, 1, 1)
                    task.Wait(20)
                end
            end)
        end,
    }
    return wisys.create(obj, enemy_walk_sprite["Enemy Ring"], {scripts[mode or 1]}, 0)
end

local function addStoneWalk(id)
    --- @type fun(self: liu_10_mc.WalkImageSystem)[]
    local scripts = {
        function(self)
            task.New(self, function()
                self.layer = 7
                self:Sprite(id + 0)
                while true do
                    local da = ran2:Float(-180, 180) / 64
                    self:RotateTime(2, 0, da)
                    da = ran2:Float(-180, 180) / 64
                    task.Wait(2)
                    self:RotateTime(2, 0, da)
                    task.Wait(2)
                end
            end)
        end,
    }
    return enemy_walk_sprite["Stone"], scripts
end

local function addOnibiWalk(id)
    --- @type fun(self: liu_10_mc.WalkImageSystem)[]
    local particle_script = {
        function(self)
            task.New(self, function()
                self.layer = 9
                self:Blend("mul+add")
                self:Sprite(id + ran2:Float(0, 7))
                local x0 = ran2:Float(-1, 1) * 8
                local y0 = (ran2:Float(0, 1) * 8) + 4
                self:Pos(x0, y0)
                x0 = ran2:Float(-1, 1) * 8
                y0 = (ran2:Float(0, 1) * 16) + 16
                self:PosTime(10, 0, x0, y0)
                self:Scale(0.5, 0.5)
                self:ScaleTime(10, 1, 0, 0)
                task.Wait(10)
                ---@diagnostic disable-next-line: undefined-field
                table.remove(self.parent.chlid, 1)
            end)
        end,
    }
    local sprites = enemy_walk_sprite["Onibi"]
    --- @type fun(self: liu_10_mc.WalkImageSystem)[]
    local scripts = {
        function(self)
            task.New(self, function()
                self.layer = 8
                self:Scale(0, 0)
                self:ScaleTime(6, 4, 2, 2)
                self:Sprite(id + 0)
                task.Wait(3)
                self:Sprite(id + 1)
                task.Wait(3)
                self:Sprite(id + 2)
                self:ScaleTime(6, 1, 1, 1)
                task.Wait(3)
                self:Sprite(id + 3)
                task.Wait(3)
                self:Sprite(id + 4)
                while true do
                    self:Sprite(id + 0)
                    self:addChild(wisys.create(self.obj, sprites, particle_script, 1))
                    task.Wait(1)
                    self:addChild(wisys.create(self.obj, sprites, particle_script, 1))
                    task.Wait(1)
                    self:addChild(wisys.create(self.obj, sprites, particle_script, 1))
                    task.Wait(1)
                    self:Sprite(id + 1)
                    self:addChild(wisys.create(self.obj, sprites, particle_script, 1))
                    task.Wait(1)
                    self:addChild(wisys.create(self.obj, sprites, particle_script, 1))
                    task.Wait(1)
                    self:addChild(wisys.create(self.obj, sprites, particle_script, 1))
                    task.Wait(1)
                    self:Sprite(id + 2)
                    self:addChild(wisys.create(self.obj, sprites, particle_script, 1))
                    task.Wait(1)
                    self:addChild(wisys.create(self.obj, sprites, particle_script, 1))
                    task.Wait(1)
                    self:addChild(wisys.create(self.obj, sprites, particle_script, 1))
                    task.Wait(1)
                    self:Sprite(id + 3)
                    self:addChild(wisys.create(self.obj, sprites, particle_script, 1))
                    task.Wait(1)
                    self:addChild(wisys.create(self.obj, sprites, particle_script, 1))
                    task.Wait(1)
                    self:addChild(wisys.create(self.obj, sprites, particle_script, 1))
                    task.Wait(1)
                    self:Sprite(id + 4)
                    self:addChild(wisys.create(self.obj, sprites, particle_script, 1))
                    task.Wait(1)
                    self:addChild(wisys.create(self.obj, sprites, particle_script, 1))
                    task.Wait(1)
                    self:addChild(wisys.create(self.obj, sprites, particle_script, 1))
                    task.Wait(1)
                    self:Sprite(id + 5)
                    self:addChild(wisys.create(self.obj, sprites, particle_script, 1))
                    task.Wait(1)
                    self:addChild(wisys.create(self.obj, sprites, particle_script, 1))
                    task.Wait(1)
                    self:addChild(wisys.create(self.obj, sprites, particle_script, 1))
                    task.Wait(1)
                    self:Sprite(id + 6)
                    self:addChild(wisys.create(self.obj, sprites, particle_script, 1))
                    task.Wait(1)
                    self:addChild(wisys.create(self.obj, sprites, particle_script, 1))
                    task.Wait(1)
                    self:addChild(wisys.create(self.obj, sprites, particle_script, 1))
                    task.Wait(1)
                    self:Sprite(id + 7)
                    self:addChild(wisys.create(self.obj, sprites, particle_script, 1))
                    task.Wait(1)
                    self:addChild(wisys.create(self.obj, sprites, particle_script, 1))
                    task.Wait(1)
                    self:addChild(wisys.create(self.obj, sprites, particle_script, 1))
                    task.Wait(1)
                end
            end)
        end,
    }
    return sprites, scripts
end

local walk_params = {
    {addFairyWalk(0)},
    {addFairyWalk(12)},
    {addFairyWalk(24)},
    {addFairyWalk(36)},
    {addDeadFairyWalk(0)},
    {addDeadFairyWalk(1)},
    {addDeadFairyWalk(2)},
    {addDeadFairyWalk(3)},
    {addFairyWalk(48)},
    {addGreatFairyWalk(0)},
    {addKedamaWalk(0)},
    {addKedamaWalk(1)},
    {addKedamaWalk(2)},
    {addKedamaWalk(3)},
    {addKedamaWalk_fadein(0)},
    {addKedamaWalk_fadein(1)},
    {addKedamaWalk_fadein(2)},
    {addKedamaWalk_fadein(3)},
    {addWheelGhostWalk(0)},
    {addWheelGhostWalk(1)},
    {addWheelGhostWalk(2)},
    {addWheelGhostWalk(3)},
    {addWheelGhostWalk_fadein(0)},
    {addWheelGhostWalk_fadein(1)},
    {addWheelGhostWalk_fadein(2)},
    {addWheelGhostWalk_fadein(3)},
    {addStoneWalk(0)},
    {addStoneWalk(1)},
    {addStoneWalk(2)},
    {addStoneWalk(3)},
    {addStoneWalk(4)},
    {addStoneWalk(5)},
    {addOnibiWalk(0)},
    {addOnibiWalk(8)},
    {addOnibiWalk(16)},
    {addOnibiWalk(24)},
}

function M.setEnemyWalk(obj, id, ring)
    local params = walk_params[id]
    local sprites, scripts = unpack(params)
    obj._wisys = wisys.create(obj, sprites, scripts, 1)
    if ring then
        obj._wisys_ring = addEnemyRing(obj, unpack(ring))
    end
end

return M