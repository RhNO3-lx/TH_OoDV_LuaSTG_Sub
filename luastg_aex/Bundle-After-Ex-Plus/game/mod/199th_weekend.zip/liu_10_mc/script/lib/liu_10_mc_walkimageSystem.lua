local calc = require("liu_10_mc.script.lib.liu_10_mc_math")
local draw = require("liu_10_mc.script.lib.liu_10_mc_render")

local lerpTo = calc.lerpTo

local function UpdateList(self)
    self.list = {self}
    for _, chlid in ipairs(self.chlid) do
        table.insert(self.list, chlid)
    end
    table.sort(self.list, function(a, b)
        --- @diagnostic disable-next-line: undefined-field
        return a.layer < b.layer or (a.layer == b.layer and ((a.index and b.index and a.index < b.index) or a == self))
    end)
end

--- @class liu_10_mc.WalkImageSystem
local wisys = plus.Class()
function wisys.create(obj, sprites, scripts, dmgmaxt, pos)
    --- @class liu_10_mc.WalkImageSystem
    local self = wisys()
    self.obj = obj
    self.sprites = sprites
    self.scripts = scripts
    self.sprite = {x = 0, y = 0, w = 0, h = 0}
    self.anchor = {0, 0}
    self.x, self.y = 0, 0
    self.sx, self.sy = 1, 1
    self.rot, self.omiga = 0, 0
    self.offsetX, self.offsetY = 0, 0
    self.dx, self.dy = 0, 0
    self.hs, self.vs = 1, 1
    self.state = 1
    self.blend = "mul+alpha"
    self.color = {a = 255, r = 255, g = 255, b = 255}
    self.no_change = false
    self.chlid = {}
    self.layer = 8
    self.this_pos = pos
    self.colorize = false
    if IsValid(self.obj) then
        self.obj.dmgmaxt = dmgmaxt
        self.obj.A, self.obj.B = 16, 16
    end
    if self.scripts[1] then
        task.Clear(self)
        self.scripts[1](self)
    end
    UpdateList(self)
    return self
end

function wisys:resetState()
    self.anchor = {0, 0}
    self.x, self.y = 0, 0
    self.sx, self.sy = 1, 1
    self.rot, self.omiga = 0, 0
    self.offsetX, self.offsetY = 0, 0
    self.dx, self.dy = 0, 0
    self.hs, self.vs = 1, 1
    self.blend = "mul+alpha"
    self.color = {a = 255, r = 255, g = 255, b = 255}
    self.chlid = {}
    self.colorize = false
    self.list = {self}
end

--- @param id number | string
--- @param no_change boolean?
function wisys:setState(id, no_change)
    self.state = id
    self.no_change = no_change
    if self.scripts[id] then
        self:resetState()
        task.Clear(self)
        self.scripts[id](self)
    else
        error("Invalid state id")
    end
end

function wisys:frame()
    local obj = self.obj
    if not IsValid(obj) then return end
    local scripts = self.scripts
    if #scripts >= 5 then
        local dx = sign(obj.dx)
        local flag = self.no_change
        if dx == -1 and self.state ~= 2 and not flag then
            self:setState(2)
        elseif dx == 1 and self.state ~= 3 and not flag then
            self:setState(3)
        elseif dx == 0 and not flag then
            if self.state == 2 then
                self:setState(4)
            elseif self.state == 3 then
                self:setState(5)
            end
        end
    end
    task.Do(self)
    for _, chlid in ipairs(self.chlid) do
        chlid:frame()
        if self.colorize then
            chlid.blend = self.blend
            local color = self.color
            chlid.color = {a = color.a, r = color.r, g = color.g, b = color.b}
        end
    end
    self.rot = self.rot + self.omiga
    if type(obj.A) == "number" and type(obj.B) == "number" and obj.colli then
        obj.a, obj.b = obj.A, obj.B
        if obj.a == 0 and obj.b == 0 then
            obj.colli = false
        else
            obj.colli = true
        end
    end
end

function wisys:render(dmgt, dmgmaxt)
    local obj = self.obj
    if not IsValid(obj) then return end
    local function this_render()
        local co = lstg.Color(255, 255, 255, 255)
        local c = 0
        if dmgt and dmgmaxt then
            c = dmgt / dmgmaxt
        end
        local color = self.color
        if tostring(c) == "nan" then c = 0 end
        co = lstg.Color(color.a, color.r - color.r * 0.75 * c, color.g - color.g * 0.75 * c, color.b)
        local sprites = self.sprites
        local tex = sprites.tex
        local sprite = self.sprite
        local x = self.x + self.offsetX + self.dx
        local y = self.y + self.offsetY + self.dy
        if self.this_pos then
            local pos = self.this_pos
            x = pos[1] + x
            y = pos[2] + y
        --- @diagnostic disable-next-line: undefined-field
        elseif self.parent then
            --- @type liu_10_mc.WalkImageSystem
            --- @diagnostic disable-next-line: undefined-field
            local parent = self.parent
            x = x + (parent.x + parent.offsetX + parent.dx)
            y = y + (parent.y + parent.offsetY + parent.dy)
        end
        local hs, vs = self.hs, self.vs
        local dx, dy = (sprite.dx or 0), (sprite.dy or 0)
        local rot = self.rot + obj.rot
        local anchor = self.anchor
        local blend = self.blend
        local scale = {hs * self.sx, vs * self.sy}
        
        if tex and tex ~= "" then
            draw.Rect2D(tex, sprite, blend, anchor, scale, obj.x + x + dx, obj.y + y + dy, rot, co)
        end
    end

    local lists = self.list
    if #lists == 1 then
        this_render()
    else
        for _, list in ipairs(lists) do
            if list == self then
                this_render()
            else
                list:render(dmgt, dmgmaxt)
            end
        end
    end
end

--- @param sprites table
function wisys:setSprites(sprites)
    self.sprites = sprites
end

--- @param id number | string
function wisys:Sprite(id)
    self.sprite = self.sprites[id]
end

function wisys:FilpX()
    self.hs = -self.hs
end

function wisys:FilpY()
    self.vs = -self.vs
end

--- @param x number
--- @param y number
function wisys:Pos(x, y)
    self.x, self.y = x, y
end

--- @param rot number
function wisys:Rotate(rot)
    self.rot = rot
end

--- @param time number
--- @param mode number
--- @param x number
--- @param y number
function wisys:PosTime(time, mode, x, y)
    lerpTo(self, "x", x, time, mode)
    lerpTo(self, "y", y, time, mode)
end

--- @param time number
--- @param mode number
--- @param rot number
function wisys:RotateTime(time, mode, rot)
    lerpTo(self, "rot", rot, time, mode)
end

--- @param vel number
function wisys:AngleVel(vel)
    self.omiga = vel
end

--- @param h 0|1|2
--- @param v 0|1|2
function wisys:Anchor(h, v)
    self.anchor = {h, v}
end

--- @param x number
--- @param y number
function wisys:AnchorOffset(x, y)
    self.offsetX, self.offsetY = x, y
end

--- @param x number
--- @param y number
function wisys:Scale(x, y)
    self.sx, self.sy = x, y
end

--- @param time number
--- @param mode number
--- @param x number
--- @param y number
function wisys:ScaleTime(time, mode, x, y)
    lerpTo(self, "sx", x, time, mode)
    lerpTo(self, "sy", y, time, mode)
end

--- @param x number
--- @param y number
function wisys:PosOffset(x, y)
    self.dx, self.dy = x, y
end

--- @param blend lstg.BlendMode
function wisys:Blend(blend)
    self.blend = blend
end

--- @param alpha number
function wisys:Alpha(alpha)
    self.color.a = alpha
end

--- @param r number
--- @param g number
--- @param b number
function wisys:Color(r, g, b)
    self.color.r, self.color.g, self.color.b = r, g, b
end

--- @param time number
--- @param mode number
--- @param alpha number
function wisys:AlphaTime(time, mode, alpha)
    lerpTo(self.color, "a", alpha, time, mode)
end

--- @param time number
--- @param mode number
--- @param r number
--- @param g number
--- @param b number
function wisys:ColorTime(time, mode, r, g, b)
    lerpTo(self.color, "r", r, time, mode)
    lerpTo(self.color, "g", g, time, mode)
    lerpTo(self.color, "b", b, time, mode)
end

---@param boolean boolean?
function wisys:colorizeChildren(boolean)
    self.colorize = boolean
end

function wisys:addChild(child)
    table.insert(self.chlid, child)
    self.chlid[#self.chlid].parent = self
    self.chlid[#self.chlid].index = #self.chlid
    UpdateList(self)
end

function wisys:SetHitBox(w, h)
    if IsValid(self.obj) then
        local obj = self.obj
        obj.A, obj.B = w / 2, h / 2
    end
end

return wisys