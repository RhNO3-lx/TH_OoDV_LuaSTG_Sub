local M = {}

local modes = {}

--- @param f function
--- @return function
local function addMode(f)
    if not modes[0] then
        table.insert(modes, 0, f)
    else
        table.insert(modes, f)
    end
    return f
end

--- @param f function
--- @return function
local function flip(f)
    return function(x)
        return 1 - f(1 - x)
    end
end

--- @param f function
--- @param g function
--- @return function
local function split(f, g)
    return function(x)
        return x < 0.5 and 0.5 * f(2 * x)
                        or 0.5 * (1 + g(2 * x - 1))
    end
end

--- @overload fun(x: number): number
M.linear = addMode(function(x)
    return x
end)
--- @overload fun(x: number): number
M.easeIn2 = addMode(function(x)
    return x * x
end)
--- @overload fun(x: number): number
M.easeIn3 = addMode(function(x)
    return math.pow(x, 3)
end)
--- @overload fun(x: number): number
M.easeIn4 = addMode(function(x)
    return math.pow(x, 4)
end)

--- @overload fun(x: number): number
M.easeOut2 = addMode(flip(M.easeIn2))
--- @overload fun(x: number): number
M.easeOut3 = addMode(flip(M.easeIn3))
--- @overload fun(x: number): number
M.easeOut4 = addMode(flip(M.easeIn4))

addMode(function()
    error("mode 7 can't be represented as an easing function")
end)

--- @overload fun(x: number, p1: number, p2: number): number
M.bezier = addMode(function(x, p1, p2)
    if not p1 then p1 = 0 end
    if not p2 then p2 = 0 end
    return p1 * x * math.pow(1 - x, 2) + p2 * math.pow(x, 2) * (x - 1) + math.pow(x, 2) * (3 - 2 * x)
end)

--- @overload fun(x: number): number
M.easeInOut2 = addMode(split(M.easeIn2, M.easeOut2))
--- @overload fun(x: number): number
M.easeInOut3 = addMode(split(M.easeIn3, M.easeOut3))
--- @overload fun(x: number): number
M.easeInOut4 = addMode(split(M.easeIn4, M.easeOut4))
--- @overload fun(x: number): number
M.easeOutIn2 = addMode(split(M.easeOut2, M.easeIn2))
--- @overload fun(x: number): number
M.easeOutIn3 = addMode(split(M.easeOut3, M.easeIn3))
--- @overload fun(x: number): number
M.easeOutIn4 = addMode(split(M.easeOut4, M.easeIn4))

--- @overload fun(x: number): number
M.delayed = addMode(function(x)
    return x == 1 and 1 or 0
end)
--- @overload fun(x: number): number
M.instant = addMode(flip(M.delayed))

addMode(function()
    error("mode 17 can't be represented as an easing function")
end)

--- @overload fun(x: number): number
M.easeOutSin = addMode(function(x)
    return math.sin(x * math.pi / 2)
end)
--- @overload fun(x: number): number
M.easeInSin = addMode(flip(M.easeOutSin))
--- @overload fun(x: number): number
M.easeOutInSin = addMode(split(M.easeOutSin, M.easeInSin))
--- @overload fun(x: number): number
M.easeInOutSin = addMode(split(M.easeInSin, M.easeOutSin))

--- @overload fun(x: number): number
M.easeInBackA = addMode(function(x)
    return ((math.pow(x - 0.25, 2) / 0.5625) - 0.111111) / 0.888889
end)
--- @overload fun(x: number): number
M.easeInBackB = addMode(function(x)
    return ((math.pow(x - 0.3, 2) / 0.49) - 0.183673) / 0.816326
end)
--- @overload fun(x: number): number
M.easeInBackC = addMode(function(x)
    return ((math.pow(x - 0.35, 2) / 0.4225) - 0.289941) / 0.710059
end)
--- @overload fun(x: number): number
M.easeInBackD = addMode(function(x)
    return ((math.pow(x - 0.38, 2) / 0.3844) - 0.37565) / 0.62435
end)
--- @overload fun(x: number): number
M.easeInBackE = addMode(function(x)
    return ((math.pow(x - 0.4, 2) / 0.36) - 0.444444) / 0.555556
end)
--- @overload fun(x: number): number
M.easeOutBackA = addMode(flip(M.easeInBackA))
--- @overload fun(x: number): number
M.easeOutBackB = addMode(flip(M.easeInBackB))
--- @overload fun(x: number): number
M.easeOutBackC = addMode(flip(M.easeInBackC))
--- @overload fun(x: number): number
M.easeOutBackD = addMode(flip(M.easeInBackD))
--- @overload fun(x: number): number
M.easeOutBackE = addMode(flip(M.easeInBackE))

--- @param from number
--- @param to number
--- @param i number
--- @param mode number
--- @return number
function M.interpolation(from, to, i, mode)
    if mode == 7 then
        return from + to * i
    elseif mode == 17 then
        return from + to * math.pow(i, 2)
    else
        return from + (to - from) * modes[mode](i)
    end
end

return M