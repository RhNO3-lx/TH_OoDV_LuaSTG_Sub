local calc = require("liu_10_mc.script.lib.liu_10_mc_math")

local M = {}

local hList = {[0] = {-0.5, 0.5}, {0, 1}, {-1, 0}}
local vList = {[0] = {0.5, -0.5}, {0, -1}, {1, 0}}

--- @param h 0 | 1 | 2
--- @param v 0 | 1 | 2
function M.Anchor(h, v)
    return hList[h], vList[v]
end

--- @param l number
--- @param r number
--- @param b number
--- @param t number
local function SetViewRect(l, r, b, t)
    SetViewport(l, r, b, t)
    SetScissorRect(l, r, b, t)
end

function M.viewModeWindow()
    local s = screen.scale
    local w, h = screen.width * s, screen.height * s
    local dx, dy = screen.dx, screen.dy
    SetOrtho(0, w, 0, h)
    SetViewRect(0 + dx, w + dx, 0 + dy, h + dy)
    SetFog()
    SetImageScale(1)
end

--- @param fov number
function M.viewModeBillborad(fov)
    local world = lstg.world
    local aspect = (world.r - world.l) / (world.t - world.b)
    local distance = (0.5) / math.tan(fov)
    local s, dx, dy = screen.scale, screen.dx, screen.dy
    fov = math.rad(fov)
    SetViewRect(world.scrl * s + dx, world.scrr * s + dx, world.scrb * s + dy, world.scrt * s + dy)
    SetPerspective(
        0, 0, -distance,
        0, 0, 0,
        0, 1, 0,
        fov, aspect,
        0.001, 5
    )
    SetFog()
    SetImageScale(1)
end

function M.viewModeWindow3D(fov)
    local aspect = (screen.width / screen.height)
    local distance = (0.5) / math.tan(fov)
    local s = screen.scale
    fov = math.rad(fov)
    SetViewRect(0, screen.width * s, 0, screen.height * s)
    SetPerspective(
        0, 0, -distance,
        0, 0, 0,
        0, 1, 0,
        fov, aspect,
        0.001, 5
    )
    SetFog()
    SetImageScale(1)
end

--- @param x number
--- @param y number
function M.WorldToBillboard(x, y)
    return x / (lstg.world.t - lstg.world.b), y / (lstg.world.t - lstg.world.b)
end

--- @param x number
--- @param y number
function M.WindowToBillboard(x, y)
    local height = screen.height * screen.scale
    return x / height, y / height
end

local tmp_dest = {}
local tmp_src = {}

local function GetDestAndSrc(sprite, anchor, scale)
    local h, v = M.Anchor(anchor[1], anchor[2])
    local hs, vs = 1, 1
    if type(scale) == "table" then
        hs, vs = scale[1], scale[2]
    elseif type(scale) == "number" then
        hs, vs = scale, scale
    end
    tmp_dest = {sprite.w * h[1] * hs, sprite.w * h[2] * hs, sprite.h * v[1] * vs, sprite.h * v[2] * vs}
    tmp_src = {sprite.x + 0, sprite.x + sprite.w, sprite.y + 0, sprite.y + sprite.h}
    return tmp_dest, tmp_src
end

local colList = {}


--- @param color1 lstg.Color
--- @param color2 lstg.Color
--- @param mode number
local function GetColorFromMode(color1, color2, mode)
    colList = {
        [0] = {color1, color1, color1, color1},
        [1] = {color2, color2, color2, color2},
        [2] = {color1, color2, color2, color1},
        [3] = {color1, color1, color2, color2},
    }
    return colList[mode]
end

--- @param sprite table
--- @param anchor number[]
--- @param scale number | number[]
local function GetBillboard(sprite, anchor, scale, a, b, c, mode)
    a, b, c = a or 0, b or 0, c or 0
    mode = mode or 0

    local eye = calc.vector3(unpack(lstg.view3d.eye))
    local at = calc.vector3(unpack(lstg.view3d.at))
    local up = calc.vector3(unpack(lstg.view3d.up))

    --- 计算视线方向
    local dir = calc.minusVector3(at, eye)
    dir = calc.normalizeVector3(dir)

    --- 计算右向量（视线方向与上向量的叉积）
    local right = calc.crossVector3(dir, up)
    right = calc.normalizeVector3(right)

    --- 重新计算上向量（右向量与视线方向的叉积）
    up = calc.crossVector3(right, dir)
    up = calc.normalizeVector3(up)

    -- 应用3D旋转到右向量和上向量
    local rotated_right_x, rotated_right_y, rotated_right_z = calc.Rotate3D(right.x, right.y, right.z, a, b, c, mode)
    local rotated_up_x, rotated_up_y, rotated_up_z = calc.Rotate3D(up.x, up.y, up.z, a, b, c, mode)

    -- 更新旋转后的向量
    right = calc.vector3(rotated_right_x, rotated_right_y, rotated_right_z)
    up = calc.vector3(rotated_up_x, rotated_up_y, rotated_up_z)

    -- 重新归一化旋转后的向量
    right = calc.normalizeVector3(right)
    up = calc.normalizeVector3(up)

    local anc = {M.Anchor(anchor[1], anchor[2])}
    local H, V = anc[1], anc[2]
    local hs, vs = 1, 1
    if type(scale) == "table" then
        hs, vs = scale[1], scale[2]
    elseif type(scale) == "number" then
        hs, vs = scale, scale
    end
    local w = {sprite.w * H[1] * hs, sprite.w * H[2] * hs}
    local h = {sprite.h * V[1] * vs, sprite.h * V[2] * vs}

    --- 应用坐标分量
    local p1 = calc.vector3(
        (right.x * w[1]) + (up.x * h[1]),
        (right.y * w[1]) + (up.y * h[1]),
        (right.z * w[1]) + (up.z * h[1])
    )
    local p2 = calc.vector3(
        (right.x * w[2]) + (up.x * h[1]),
        (right.y * w[2]) + (up.y * h[1]),
        (right.z * w[2]) + (up.z * h[1])
    )
    local p3 = calc.vector3(
        (right.x * w[2]) + (up.x * h[2]),
        (right.y * w[2]) + (up.y * h[2]),
        (right.z * w[2]) + (up.z * h[2])
    )
    local p4 = calc.vector3(
        (right.x * w[1]) + (up.x * h[2]),
        (right.y * w[1]) + (up.y * h[2]),
        (right.z * w[1]) + (up.z * h[2])
    )

    return {
        {p1.x, p1.y, p1.z},
        {p2.x, p2.y, p2.z},
        {p3.x, p3.y, p3.z},
        {p4.x, p4.y, p4.z}
    }
end

local function nmaxDraw(name, sprite, blend, nmax, rep, x, y, r0, r1, a, da, color1, color2)
    local h = sprite.h * rep
    for i = 1, nmax do
        local h0 = (h / nmax) * (i - 1)
        local h1 = (h / nmax) * i
        local x0, y0 = r0 * cos(a - 0), r0 * sin(a - 0)
        local x1, y1 = r0 * cos(a - da), r0 * sin(a - da)
        local x2, y2 = r1 * cos(a - da), r1 * sin(a - da)
        local x3, y3 = r1 * cos(a - 0), r1 * sin(a - 0)
        RenderTexture(name, blend,
            {x + x0, y + y0, 0.5, sprite.x + 0, sprite.y + h0, color1},
            {x + x1, y + y1, 0.5, sprite.x + 0, sprite.y + h1, color1},
            {x + x2, y + y2, 0.5, sprite.x + sprite.w, sprite.y + h1, color2},
            {x + x3, y + y3, 0.5, sprite.x + sprite.w, sprite.y + h0, color2})
        a = a - da
    end
end

--- @param name string
--- @param sprite table
--- @param blend lstg.BlendMode
--- @param anchor number[]
--- @param scale number | number[]
--- @param x number
--- @param y number
--- @param angle number?
--- @param color1 lstg.Color?
--- @param color2 lstg.Color?
--- @param mode number?
function M.Rect2D(name, sprite, blend, anchor, scale, x, y, angle, color1, color2, mode)
    angle = angle or 0
    color1 = color1 or Color(255, 255, 255, 255)
    color2 = color2 or Color(255, 255, 255, 255)
    mode = mode or 0

    local dest, source = GetDestAndSrc(sprite, anchor, scale)
    local col = GetColorFromMode(color1, color2, mode)

    local x0, y0 = calc.Rotate2D(dest[1], dest[3], angle)
    local x1, y1 = calc.Rotate2D(dest[2], dest[3], angle)
    local x2, y2 = calc.Rotate2D(dest[2], dest[4], angle)
    local x3, y3 = calc.Rotate2D(dest[1], dest[4], angle)

    RenderTexture(name, blend,
        {x + x0, y + y0, 0.5, source[1], source[3], col[1]},
        {x + x1, y + y1, 0.5, source[2], source[3], col[2]},
        {x + x2, y + y2, 0.5, source[2], source[4], col[3]},
        {x + x3, y + y3, 0.5, source[1], source[4], col[4]})
end

--- @param name string
--- @param sprite table
--- @param blend lstg.BlendMode
--- @param anchor number[]
--- @param scale number | number[]
--- @param x number
--- @param y number
--- @param z number
--- @param angleX number?
--- @param angleY number?
--- @param angleZ number?
--- @param color1 lstg.Color?
--- @param color2 lstg.Color?
--- @param mode number?
--- @param rotation number?
--- @param billboard "world" | "window"?
function M.Rect3D(name, sprite, blend, anchor, scale, x, y, z, angleX, angleY, angleZ, color1, color2, mode, rotation, billboard)
    angleX = angleX or 0
    angleY = angleY or 0
    angleZ = angleZ or 0
    color1 = color1 or Color(255, 255, 255, 255)
    color2 = color2 or Color(255, 255, 255, 255)
    mode = mode or 0
    rotation = rotation or 0

    local dest, source = GetDestAndSrc(sprite, anchor, scale)
    local col = GetColorFromMode(color1, color2, mode)

    if billboard == "world" then
        dest[1], dest[3] = M.WorldToBillboard(dest[1], dest[3])
        dest[2], dest[4] = M.WorldToBillboard(dest[2], dest[4])
    elseif billboard == "window" then
        dest[1], dest[3] = M.WindowToBillboard(dest[1], dest[3])
        dest[2], dest[4] = M.WindowToBillboard(dest[2], dest[4])
    end

    local x0, y0, z0 = calc.Rotate3D(dest[1], dest[3], 0, angleX, angleY, angleZ, rotation)
    local x1, y1, z1 = calc.Rotate3D(dest[2], dest[3], 0, angleX, angleY, angleZ, rotation)
    local x2, y2, z2 = calc.Rotate3D(dest[2], dest[4], 0, angleX, angleY, angleZ, rotation)
    local x3, y3, z3 = calc.Rotate3D(dest[1], dest[4], 0, angleX, angleY, angleZ, rotation)

    RenderTexture(name, blend,
        {x + x0, y + y0, z + z0, source[1], source[3], col[1]},
        {x + x1, y + y1, z + z1, source[2], source[3], col[2]},
        {x + x2, y + y2, z + z2, source[2], source[4], col[3]},
        {x + x3, y + y3, z + z3, source[1], source[4], col[4]})
end

--- @param name string
--- @param sprite table
--- @param blend lstg.BlendMode
--- @param anchor number[]
--- @param scale number | number[]
--- @param angleX number?
--- @param angleY number?
--- @param angleZ number?
--- @param color1 lstg.Color?
--- @param color2 lstg.Color?
--- @param mode number?
--- @param rotation number?
function M.Billboard(name, sprite, blend, anchor, scale, x, y, z, angleX, angleY, angleZ, color1, color2, mode, rotation)
     angleX = angleX or 0
     angleY = angleY or 0
     angleZ = angleZ or 0
     color1 = color1 or Color(255, 255, 255, 255)
     color2 = color2 or Color(255, 255, 255, 255)
     mode = mode or 0
     rotation = rotation or 0

     local dest = GetBillboard(sprite, anchor, scale, angleX, angleY, angleZ, rotation)
     local source = {sprite.x + 0, sprite.x + sprite.w, sprite.y + 0, sprite.y + sprite.h}
     local col = GetColorFromMode(color1, color2, mode)

     local x0, y0, z0 = dest[1][1], dest[1][2], dest[1][3]
     local x1, y1, z1 = dest[2][1], dest[2][2], dest[2][3]
     local x2, y2, z2 = dest[3][1], dest[3][2], dest[3][3]
     local x3, y3, z3 = dest[4][1], dest[4][2], dest[4][3]

     RenderTexture(name, blend,
         {x + x0, y + y0, z + z0, source[1], source[3], col[1]},
         {x + x1, y + y1, z + z1, source[2], source[3], col[1]},
         {x + x2, y + y2, z + z2, source[2], source[4], col[2]},
         {x + x3, y + y3, z + z3, source[1], source[4], col[2]})
end

--- @param name string
--- @param sprite table
--- @param blend lstg.BlendMode
--- @param nmax number
--- @param radius number
--- @param width number
--- @param rep number
--- @param x number
--- @param y number
--- @param angle number?
--- @param color1 lstg.Color?
--- @param color2 lstg.Color?
function M.texCircle(name, sprite, blend, nmax, radius, width, rep, x, y, angle, color1, color2)
    angle = angle or 0
    color1 = color1 or Color(255, 255, 255, 255)
    color2 = color2 or color1

    local r0, r1 = radius - abs(width * 0.5), radius + abs(width * 0.5)
    local a, da = angle, 360 / nmax

    nmaxDraw(name, sprite, blend, nmax, rep, x, y, r0, r1, a, da, color1, color2)
end

--- @param blend lstg.BlendMode
--- @param anchor number[]
--- @param scale number | number[]
--- @param x number
--- @param y number
--- @param w number
--- @param h number
--- @param angle number?
--- @param color lstg.Color?
function M.drawRect(blend, anchor, scale, x, y, w, h, angle, color)
    angle = angle or 0
    color = color or Color(255, 255, 255, 255)

    local anc = {M.Anchor(anchor[1], anchor[2])}
    local H, V = anc[1], anc[2]
    local hs, vs = 1, 1
    if type(scale) == "table" then
        hs, vs = scale[1], scale[2]
    elseif type(scale) == "number" then
        hs, vs = scale, scale
    end
    local x0, y0 = calc.Rotate2D(w * H[1] * hs, h * V[1] * vs, angle)
    local x1, y1 = calc.Rotate2D(w * H[2] * hs, h * V[1] * vs, angle)
    local x2, y2 = calc.Rotate2D(w * H[2] * hs, h * V[2] * vs, angle)
    local x3, y3 = calc.Rotate2D(w * H[1] * hs, h * V[2] * vs, angle)
    SetImageState("white", blend, color)
    Render4V("white",
        x + x0, y + y0, 0.5,
        x + x1, y + y1, 0.5,
        x + x2, y + y2, 0.5,
        x + x3, y + y3, 0.5)
    SetImageState("white", "", Color(0xFFFFFFFF))
end

return M