local draw = require("liu_10_mc.script.lib.liu_10_mc_render")
---------------------------------------------
local M = {}

--- @param obj any
--- @param tex string
--- @param sprite table
--- @param x number
--- @param y number
--- @param sx number
--- @param sy number
--- @param rot number
--- @param omiga number
--- @param blend lstg.BlendMode
--- @param scale number|table
--- @param frame function
--- @param anchor number[]
--- @param c1 lstg.Color?
--- @param c2 lstg.Color?
function M.AddLayer(obj, tex, sprite, x, y, sx, sy, rot, omiga, blend, scale, frame, anchor, c1, c2, mode)
    c1 = c1 or Color(255, 255, 255, 255)
    c2 = c2 or Color(255, 255, 255, 255)
    mode = mode or 0
    if type(scale) == "number" then
        scale = {scale, scale}
    end
    _spellcard_background.AddLayer(obj, "img_void", false, x, y, rot, 0, 0, omiga, blend, scale[1], scale[2],
        function(self)
            self.task = {}
            self.color1 = {c1:ARGB()}
            self.color2 = {c2:ARGB()}
            self.time = 0
        end, frame,
        function(self)
            local t = self.timer
            local texSize = {GetTextureSize(tex)}
            local su, sv = sx * texSize[1] * t, sy * texSize[2] * t
            local co1, co2 = self.color1, self.color2
            local co = {
                Color(co1[1] * self._cur_alpha, co1[2], co1[3], co1[4]),
                Color(co2[1] * self._cur_alpha, co2[2], co2[3], co2[4]),
            }
            local angle = self.rot
            local spr = {x = sprite.x, y = sprite.y, w = sprite.w, h = sprite.h}
            spr.x, spr.y = spr.x + su, spr.y + sv
            draw.Rect2D(tex, spr, blend, anchor, scale, x, y, angle, co[1], co[2], mode)
        end)
end

--- @param obj any
--- @param tex string
--- @param sprite table
--- @param x number
--- @param y number
--- @param sx number
--- @param sy number
--- @param rot number
--- @param omiga number
--- @param blend lstg.BlendMode
--- @param r number
--- @param rw number
--- @param n number
--- @param m number
--- @param frame function
--- @param c1 lstg.Color?
--- @param c2 lstg.Color?
function M.AddLayerCircle(obj, tex, sprite, x, y, sx, sy, rot, omiga, blend, r, rw, n, m, frame, c1, c2)
    c1 = c1 or Color(255, 255, 255, 255)
    c2 = c2 or c1
    _spellcard_background.AddLayer(obj, "img_void", false, x, y, rot, 0, 0, omiga, blend, 1, 1,
        function(self)
            self.task = {}
            self.color1 = {c1:ARGB()}
            self.color2 = {c2:ARGB()}
            self.time = 0
        end, frame,
        function(self)
            local t = self.timer
            local texSize = {GetTextureSize(tex)}
            local su, sv = sx * texSize[1] * t, sy * texSize[2] * t
            local co1, co2 = self.color1, self.color2
            local co = {
                Color(co1[1] * self._cur_alpha, co1[2], co1[3], co1[4]),
                Color(co2[1] * self._cur_alpha, co2[2], co2[3], co2[4]),
            }
            local angle = self.rot
            local spr = {x = sprite.x, y = sprite.y, w = sprite.w, h = sprite.h}
            spr.x, spr.y = spr.x + su, spr.y + sv
            draw.texCircle(tex, spr, blend, n, r, rw, m, x, y, angle, co[1], co[2])
        end)
end

function M.defaultFrame(self)
    task.Do(self)
    ---@diagnostic disable-next-line: undefined-field
    if _boss.is_sc and _boss.timer == 0 then
        self.timer = 0
        self.rot = 0
    end
end

function M.renderFunc(self)
    SetViewMode("world")
    local showboss = lstg.tmpvar.bg and lstg.tmpvar.bg.hide == true
    if showboss then
        background.WarpEffectCapture()
    end
    local c = self.fogColor or lstg.view3d.fog[3]
    local a, r, g, b = c:ARGB()
    SetImageState("white", "", Color(a * self.alpha, r, g, b))
    RenderRect("white", lstg.world.l, lstg.world.r, lstg.world.b, lstg.world.t)
    SetImageState("white", "", Color(0xFFFFFFFF))
    if self.layers and type(self.layers) == "table" then
        for i = 1, #(self.layers) do
            local l = self.layers[i]
            l.render(l)
        end
    end
    if showboss then
        background.WarpEffectApply()
    end
end

return M