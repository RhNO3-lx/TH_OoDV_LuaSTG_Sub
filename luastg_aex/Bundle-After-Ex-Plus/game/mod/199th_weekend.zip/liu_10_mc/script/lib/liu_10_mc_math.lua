local easeing = require("liu_10_mc.script.lib.liu_10_mc_interpolation")

local M = {}

M.lerp = easeing.interpolation

function M.lerpTo(tar, var, value, time, mode)
    task.New(task.GetSelf(), function()
        local cache = tar[var]
        for t = 1, time do
            tar[var] = M.lerp(cache, value, t / time, mode)
            task.Wait(1)
        end
        tar[var] = value
    end)
end

M.bezier = easeing.bezier

---@class matrix
function M.CreateMatrix(mn, ...)
    local mat = {}
    local index = 1
    local j = 1
    for i = 1, mn[2] do
        mat[i] = {}
    end
    for _, v in ipairs({...}) do
        mat[j][index] = v
        if index >= mn[1] then
            index = 1
            j = j + 1
        else
            index = index + 1
        end
    end
    return mat
end

function M.MatrixMix(A, B)
    local A_m, B_m = #A[1], #B[1]
    local B_n = #B
    local mix = {}
    local add = 0
    for j = 1, B_n do
        mix[j] = {}
        for i = 1, B_m do
            for ai = 1, A_m do
                add = add + (B[ai][i] * A[j][ai]) * 1
            end
            mix[j][i] = add
            add = 0
        end
    end
    return mix
end

function M.MatrixMultiply(B, num)
    local B_m = #B[1]
    local B_n = #B
    local mix = {}
    for j = 1, B_n do
        mix[j] = {}
        for i = 1, B_m do
            mix[j][i] = B[j][i] * num
        end
    end
    return mix
end

---@class vector3
function M.vector3(x, y, z)
    return {x = x, y = y, z = z}
end

function M.addVector3(v1, v2)
    local v = {x = v1.x + v2.x, y = v1.y + v2.y, z = v1.z + v2.z}
    return v
end

function M.minusVector3(v1, v2)
    local v = {x = v1.x - v2.x, y = v1.y - v2.y, z = v1.z - v2.z}
    return v
end

function M.dotVector3(v1, v2)
    return v1.x * v2.x + v1.y * v2.y + v1.z * v2.z
end

function M.crossVector3(v1, v2)
    local v = {x = v1.y * v2.z - v2.y * v1.z, y = v2.x * v1.z - v1.x * v2.z, z = v1.x * v2.y - v2.x * v1.y}
    return v
end

function M.Get_1_Vector3(v)
    return {x = 1 / v.x, y = 1 / v.y, z = 1 / v.z}
end

function M.normalizeVector3(v)
    local d = math.sqrt(math.pow(v.x, 2) + math.pow(v.y, 2) + math.pow(v.z, 2))
    return {x = v.x / d, y = v.y / d, z = v.z / d}
end

function M.Vector3ToMatrix(v)
    local mat = {
        {v.x}, {v.y}, {v.z}, {1}
    }
    return mat
end

function M.Vector3ToMatrixPoint(v)
    local mat = {
        {v.x}, {v.y}, {v.z}, {0}
    }
    return mat
end

function M.MatLookAt(pos, target, upDir)
    local cN = M.normalizeVector3(M.minusVector3(target, pos))
    local cU = M.normalizeVector3(M.crossVector3(upDir, cN))
    local cV = M.crossVector3(cN, cU)

    local eU = M.dotVector3(pos, cU)
    local eV = M.dotVector3(pos, cV)
    local eN = M.dotVector3(pos, cN)

    local mat = {
        {cU.x, cU.y, cU.z, -eU},
        {cV.x, cV.y, cV.z, -eV},
        {cN.x, cN.y, cN.z, -eN},
        {0, 0, 0, 1}
    }
    return mat
end

function M.MatProjection(fov, aspect, zn, zf)
    fov = math.deg(fov * 0.5)
    local e11 = M.cot(fov) / aspect
    local e22 = M.cot(fov)
    local e33 = (zf + zn) / (zf - zn)
    local e34 = -(2 * (zf * zn) / (zf - zn))
    local e43 = 1.0
    local proj = {
        {e11, 0, 0, 0},
        {0, e22, 0, 0},
        {0, 0, e33, e34},
        {0, 0, e43, 0}
    }
    return proj
end

function M.MatViewport(x, y, width, height, maxZ, minZ)
    return {
        {width / 2, 0, 0, x},
        {0, height / 2, 0, y},
        {0, 0, maxZ - minZ, 0},
        {width / 2, height / 2, minZ, 1}
    }
end

function M.From3DToWorld(pos, lookat, upDir, proj, viewport, p, flag)
    p = M.Vector3ToMatrix(p)
    p = M.MatrixMix(lookat, p)
    p = M.MatrixMix(proj, p)
    local w, z = p[4][1], p[3][1]
    p = M.MatrixMultiply(p, 1 / w)
    p = M.MatrixMix(viewport, p)

    if flag then
        return p[1][1], p[2][1], z
    else
        return p[1][1], p[2][1], w
    end
end

function M.Rotate2D(x, y, a)
    return x * cos(a) - y * sin(a), x * sin(a) + y * cos(a)
end

local function RotateX(x, y, z, a)
    local cosTheta = cos(a)
    local sinTheta = sin(a)
    
    local xPrime = x
    local yPrime = y * cosTheta - z * sinTheta
    local zPrime = y * sinTheta + z * cosTheta
    
    return xPrime, yPrime, zPrime
end

local function RotateY(x, y, z, a)
    local cosTheta = cos(a)
    local sinTheta = sin(a)
    
    local xPrime = x * cosTheta - z * sinTheta
    local yPrime = y
    local zPrime = x * sinTheta + z * cosTheta
    
    return xPrime, yPrime, zPrime
end

local function RotateZ(x, y, z, a)
    local cosTheta = cos(a)
    local sinTheta = sin(a)
    
    local xPrime = x * cosTheta + y * sinTheta
    local yPrime = -x * sinTheta + y * cosTheta
    local zPrime = z
    
    return xPrime, yPrime, zPrime
end

function M.Rotate3D(x, y, z, a, b, c, mode)
    mode = mode or 0
    if mode == 0 then
        x, y, z = RotateX(x, y, z, a)
        x, y, z = RotateY(x, y, z, b)
        x, y, z = RotateZ(x, y, z, c)
    elseif mode == 1 then
        x, y, z = RotateX(x, y, z, a)
        x, y, z = RotateZ(x, y, z, b)
        x, y, z = RotateY(x, y, z, c)
    elseif mode == 2 then
        x, y, z = RotateY(x, y, z, a)
        x, y, z = RotateX(x, y, z, b)
        x, y, z = RotateZ(x, y, z, c)
    elseif mode == 3 then
        x, y, z = RotateY(x, y, z, a)
        x, y, z = RotateZ(x, y, z, b)
        x, y, z = RotateX(x, y, z, c)
    elseif mode == 4 then
        x, y, z = RotateZ(x, y, z, a)
        x, y, z = RotateX(x, y, z, b)
        x, y, z = RotateY(x, y, z, c)
    elseif mode == 5 then
        x, y, z = RotateZ(x, y, z, a)
        x, y, z = RotateY(x, y, z, b)
        x, y, z = RotateX(x, y, z, c)
    end
    return x, y, z
end

M.rnd = lstg.Rand()

return M