---@diagnostic disable: inject-field
--||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
local sin, cos = sin, cos
local min, max = min, max
local Color = Color
local SetViewMode = SetViewMode
local EvaDrawRectA2 = EvaDrawRectA2
local task_Do = task.Do

local texture = "eva_shot"
DoFile("eva_shotConstAlpha.lua")
DoFile("eva_shotConstAdd.lua")

--||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
local shotDataAlpha = DoFile("eva_shotDataAlpha.lua")
local shotDataAdd = DoFile("eva_shotDataAdd.lua")

local shotData = shotDataAlpha
for k, v in pairs(shotDataAdd) do
    table.insert(shotData, v)
end

local shotDataById = {}
for i = 1, #shotData do
    local info = shotData[i]
    shotDataById[info.id] = info
end
--||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||

local dnhFade = Class(object)

function dnhFade:init(master, duration)
    self.texture = texture
    self.master = master
    self.duration = duration
    self.group = GROUP_ENEMY_BULLET
    self.layer = LAYER_ENEMY_BULLET
    self.bound = false
    self.colli = false
    self.count = 0
    self.alpha = 255
    self.R = 255
    self.G = 255
    self.B = 255
    self.angleX = 0
    self.angleY = 0
    self.angleZ = master.angleZ
    self.scaleX = 1
    self.scaleY = 1
    self.scaleZ = 0
    self.dest = master.dest
    self.source = master.source
    self.blend = EVA_BLEND_ADD_ARGB
    self.fixed_angle = master.fixed_angle
    self.angle = master.angle
    self.size = 2
end

function dnhFade:frame()
    if(IsValid(self.master) and self.count < self.duration)then
        self.count = self.count + 1
        local rate = min(self.count/self.duration, 1)
        self.x = self.master.x
        self.y = self.master.y
        self.z = self.master.z
        self.scaleX = self.size + (1 - self.size) * rate
        self.scaleY = self.size + (1 - self.size) * rate
        self.angle = self.master.angle
        self.alpha = 255 * rate
    else
        Del(self)
    end
end

function dnhFade:render()
    local color = Color(self.alpha, self.R, self.G, self.B)
    local x = self.x
    local y = self.y
    local z = self.z
    local angleX = self.angleX
    local angleY = self.angleY
    local angleZ = self.fixed_angle and 0 or -(self.angle+90) + self.angleZ
    local dest = {
        self.dest[1] * self.scaleX, self.dest[2]* self.scaleY,
        self.dest[3] * self.scaleX, self.dest[4] * self.scaleY}
    local source = self.source
    SetViewMode("world")
    EvaDrawRectA2(self.texture, dest, source, self.blend, color, x, y, z, angleX, angleY, angleZ)
end

function EvaCreateShotFade(shot, duration)
    return New(dnhFade, shot, duration)
end

local bulletBreak = Class(object)

function bulletBreak:init(master, duration)
    self.x = master.x
    self.y = master.y
    self.z = 0
    self.texture = texture
    self.master = master
    self.duration = duration
    self.group = GROUP_ENEMY_BULLET
    self.layer = LAYER_ENEMY_BULLET_EF
    self.bound = false
    self.colli = false
    self.count = 0
    self.alpha = 255
    self.R = 255
    self.G = 255
    self.B = 255
    self.angleX = 0
    self.angleY = 0
    self.angleZ = master.angleZ
    self.scaleX = master.scaleX
    self.scaleY = master.scaleY
    self.scaleX_m = master.scaleX
    self.scaleY_m = master.scaleY
    self.scaleZ = 0
    self.dest = master.dest
    self.source = master.source
    self.blend = master.blend
    self.fixed_angle = master.fixed_angle
    self.angle = master.angle
end

function bulletBreak:frame()
    if(self.count <= self.duration)then
        local rate = min(self.count/self.duration, 1)
        self.scaleX = self.scaleX_m + 0 * rate
        self.scaleY = self.scaleY_m + 0 * rate
        self.alpha = 255 * (1 - rate)
        self.count = self.count + 1
    else
        Del(self)
    end
end

function bulletBreak:render()
    local color = Color(self.alpha, self.R, self.G, self.B)
    local x = self.x
    local y = self.y
    local z = self.z
    local angleX = self.angleX
    local angleY = self.angleY
    local angleZ = self.fixed_angle and 0 or -(self.angle+90) + self.angleZ
    local dest = {
        self.dest[1] * self.scaleX, self.dest[2]* self.scaleY,
        self.dest[3] * self.scaleX, self.dest[4] * self.scaleY}
    local source = self.source
    SetViewMode("world")
    EvaDrawRectA2(self.texture, dest, source, self.blend, color, x, y, z, angleX, angleY, angleZ)
end

function EvaBulletBreakEffect(x, y, spd, ang, rAng, colorNum)
	local color = EvaGetColorArray(colorNum)
	local obj = EvaSimpleSprite2D("eva_bbEfc", LAYER_ENEMY_BULLET_EF, x, y)
	EvaSetBlendType(obj, EVA_BLEND_ADD_ARGB)
	EvaSetPosition(obj, x, y, 0)
	EvaSetAngleXYZ(obj, 0, 0, rAng)
	EvaSetSourceRect(obj, 0, 0, 32, 32)
	EvaSetDestRect(obj, -16, -16, 16, 16)
	EvaSetAlpha(obj, 255)
	EvaSetColor(obj, color[1], color[2], color[3])
    task.New(obj, function()
        for i = 0, 7 do
            EvaSetSourceRect(obj, 128*i, 0, 128+128*i, 128)
            local sx = (8-i)/8*spd*cos(ang)
            local sy = (8-i)/8*spd*sin(ang)
            EvaSetPosition(obj, obj.x+sx, obj.y+sy, 0)
            task.Wait()
            sx = (7.5-i)/8*spd*cos(ang)
            sy = (7.5-i)/8*spd*sin(ang)
            EvaSetPosition(obj, obj.x+sx, obj.y+sy, 0)
            task.Wait()
        end
        Del(obj)
    end)
end

local BEAngle = 0
local BEARate = 72

function EvaCreateShotBreakEff(shot)
    EvaBulletBreakEffect(shot.x, shot.y, shot.speed, shot.angle, shot.angleZ, (shot.graphic-1)%8)
    BEAngle = (BEAngle + BEARate)%360
    BEARate = (BEARate+ 11)%132
end

local dnhShot = Class(object)

function dnhShot:init(graphic, x, y, angle, speed, delay)
    self.texture = texture
    self.graphic = graphic
    self.group = GROUP_ENEMY_BULLET
    self.layer = LAYER_ENEMY_BULLET
    self.bound = true
    self.hide = false
    self.x = x
    self.y = y
    self.z = 0
    self.rot = 0
    self.angle = angle
    self.COSV = cos(angle)
    self.SINV = sin(angle)
    self.speed = speed
    self.accel = 0
    self.min_speed = 0
    self.max_speed = 999
    self.alpha = 255
    self.R = 255
    self.G = 255
    self.B = 255
    self.angleX = 0
    self.angleY = 0
    self.angleZ = 0
    self.scaleX = 1
    self.scaleY = 1
    self.scaleZ = 0
    self.dest = {0, 0, 0, 0}
    self.source = {0, 0, 0, 0}
    self._render_dest = {0, 0, 0, 0}
    self._render_source = {0, 0, 0, 0}
    self.blend = EVA_BLEND_ALPHA
    self.angular_velocity = 0
    self.fixed_angle = false
    --|||判定相关|||
    self.colli = false
    self.a = 1
    self.b = 1
    self.rect = true

    ---动画
    self.AnimationData = nil
    self.animated = false
    self.animCount = 0
    self.animFrame = 1
    self.animFrameMax = 1
    self.animDuration = 4

    --图像偏移
    self.offsetX = 0
    self.offsetY = 0
    if(graphic >= ADD_BGW_FIRE_RED and graphic <= ADD_BGW_FIRE_WHITE) then
        self.offsetX = 0
        self.offsetY = 4
    end

    EvaUpdateShotByData(self, graphic)
    --|||弹雾相关|||
    self.stay = true
    self.delay_timer = delay or 11

    self.hide_user = false
    self.colli_user = true

    EvaCreateShotFade(self, self.delay_timer)

    --消弹特效
    self.isBreakEffect = true
end

local function EvaHandleShotAnimation(self)
    if (not self.animated) then return end
    local anim = self.AnimationData
    local frame = self.animFrame
    self.animCount = self.animCount + 1
    local duration = anim[frame][1]
    if self.animCount % duration == 0 then
        frame = frame + 1
        if frame > self.animFrameMax then
            frame = 1
        end
        self.animFrame = frame
    end
end

local function EvaHandleShotMovement(self)
    self.x = self.x + self.speed * self.COSV
    self.y = self.y + self.speed * self.SINV
    self.angleZ = self.angleZ + self.angular_velocity
    self.speed = self.speed + self.accel
    self.speed = max(self.min_speed, min(self.speed, self.max_speed))
end

function dnhShot:frame()
    task_Do(self)
    
    if(self.delay_timer >= 0)then
        self.hide = true
        if(self.delay_timer == 0)then
            self.hide = self.hide_user
            self.colli = self.colli_user
        end
        self.delay_timer = self.delay_timer - 1
    end

    EvaHandleShotMovement(self)

    EvaHandleShotAnimation(self)
end

function dnhShot:render()
    if(self.hide)then return end
    local color = Color(self.alpha, self.R, self.G, self.B)
    local x = self.x
    local y = self.y
    local z = self.z
    local angleX = self.angleX
    local angleY = self.angleY
    local angleZ = self.fixed_angle and 0 or -(self.angle+90) + self.angleZ
    local base = self.dest
    local dest = self._render_dest
    dest[1] = base[1] * self.scaleX + self.offsetX
    dest[2] = base[2] * self.scaleY + self.offsetY
    dest[3] = base[3] * self.scaleX + self.offsetX
    dest[4] = base[4] * self.scaleY + self.offsetY
    SetViewMode("world")
    if not (self.animated) then EvaDrawRectA2(self.texture, dest, self.source, self.blend, color, x, y, z, angleX, angleY, angleZ) return end
    local ad = self.AnimationData[self.animFrame]
    local src = self._render_source
    src[1], src[2], src[3], src[4] = ad[2], ad[3], ad[4], ad[5]
    EvaDrawRectA2(self.texture, dest, src, self.blend, color, x, y, z, angleX, angleY, angleZ)
end

function dnhShot:kill()
    if not self.isBreakEffect then return end
    EvaCreateShotBreakEff(self)
end

function dnhShot:del()
    if not self.isBreakEffect then return end
    EvaCreateShotBreakEff(self)
end

--||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||

EVA_INFO_RECT = 1

function EvaGetShotData(graphic)
    return shotDataById[graphic]
end

function EvaGetShotDataInfoA1(graphic, type)
    local info = EvaGetShotData(graphic)
    type = ({"rect"})[type]
    local res = info[type]
    if not res then
        local ani = info.AnimationData[1]
        res = {ani[2], ani[3], ani[4], ani[5]}
    end
    return res
end

function EvaUpdateShotByData(shot, graphic)
    local info = EvaGetShotData(graphic)
    if not info then return end  -- 保险

    local rect = info.rect
    if not rect then
        local ad = info.AnimationData[1]
        rect = { ad[2], ad[3], ad[4], ad[5] }
        -- 只多做这一行：把算出来的 rect 缓存回去
        info.rect = rect
    end
    shot.source = rect

    local w = shot.source[3] - shot.source[1]
    local h = shot.source[4] - shot.source[2]

    -- 和原版一样，每发子弹都 new 一张 dest 表，避免共享
    shot.dest = { -w / 2, -h / 2, w / 2, h / 2 }

    shot.blend = info.render or EVA_BLEND_ALPHA
    shot.fixed_angle = info.fixed_angle or false
    shot.angular_velocity = info.angular_velocity or 0

    shot.animated = false

    if info.AnimationData then
        shot.animated = true
        shot.AnimationData = info.AnimationData
        shot.animFrameMax = #info.AnimationData
    end

    local collision = info.collision
    local default_collision = int(max(min(w, h) / 3 - 3, 3))
    local cond = type(collision) == "table"
    shot.a = cond and collision[1] or (collision or default_collision)
    shot.b = cond and collision[2] or (collision or default_collision)
    shot.rect = cond and false or (collision or true)
end

function EvaCreateShot(graphic, x, y, angle, speed, delay)
    local shot = New(dnhShot, graphic, x, y, angle, speed, delay)
    return shot
end

function EvaCreateUserShotA1(x, y, spd, ang, grap, delay)
    local objS = EvaCreateShot(grap, x, y, ang, spd, delay)

    return objS
end

function EvaCreateShotA1(x, y, spd, ang, grap, delay)
    local objS = EvaCreateShot(grap, x, y, ang, spd, delay)

    return objS
end

function EvaCreateUserShotA2(x, y, spd, ang, acce, sMax, grap, delay)
    local objS = EvaCreateShot(grap, x, y, ang, spd, delay)
    objS.accel = acce
    if(acce<0)then
        objS.min_speed = sMax
    else
        objS.max_speed = sMax
    end
    return objS
end

function EvaCreateShotA2(x, y, spd, ang, acce, sMax, grap, delay)
    local objS = EvaCreateShot(grap, x, y, ang, spd, delay)
    objS.accel = acce
    if(acce<0)then
        objS.min_speed = sMax
    else
        objS.max_speed = sMax
    end
    return objS
end

function EvaChangeShotAngle(shot, angle)
    shot.angle = angle
    shot.COSV = cos(angle)
    shot.SINV = sin(angle)
end

function EvaObjShot_SetAutoDelete(obj, autoDelete)
    obj.bound = autoDelete
end

function EvaSetIntersectionCircle(obj, r)
    obj.a = r
    obj.b = r
    obj.rect = false
end


----|||||||||||||||||||||||||||||| 鸡光 |||||||||||||||||||||||||||||||||||

local lColli = Class(object)

function lColli:init(master, a, b, rot)
    self.bound = false
    self.master = master
    self.group = GROUP_INDES
    self.colli = true
    self.a = a
    self.b = b
    self.rot = rot
    self.rect = true
end

function lColli:frame()
    if(IsValid(self.master)) then
        self.colli = self.master.colli
    else
        Del(self)
    end
end

local function CreateLaserColli(master, a, b, rot)
    return New(lColli, master, a, b, rot)
end

local stLaser = Class(object)

function stLaser:init(x, y, ang, len, wid, deleteTime, graphic, delay, NoColli)
    self.group = GROUP_INDES
    self.layer = LAYER_ENEMY_BULLET
    self.bound = false

    self.beginX = x
    self.beginY = y
    self.endX = x
    self.endY = y

    self.len = 128
    self.width = 16
    self.graphic = graphic
    self.texture = texture

    self.length = len
    self.width = wid

    self.source = {0, 0, 0, 0}
    self._render_source = {0, 0, 0, 0}

    self.dest = {0, self.width / 2, self.length, -self.width / 2}

    self.alpha = 255
    self.R = 255
    self.G = 255
    self.B = 255
    self.blend = EVA_BLEND_ADD_ARGB

    self.rot = ang
    self.COSA = cos(ang)
    self.SINA = sin(ang)
    self.ratioX = 0.5
    self.ratioY = 0.8
    self.a = 0
    self.b = 0
    self.rect = true
    self.colli_user = true
    self.colli = false
    if not NoColli then
        self.colliObject = CreateLaserColli(self, self.a, self.b, self.rot)
    end

    -- 弹雾
    self.deleteTime = deleteTime
    self.delay = delay

    -- 动画
    self.AnimationData = nil
    self.animated = false
    self.animCount = 0
    self.animFrame = 1
    self.animFrameMax = 1
    self.animDuration = 4

    EvaUpdateShotByData(self, graphic)

    self.a = 0
    self.b = 0

    task.New(self, function ()
        while(self.delay > 0)do
            task.Wait()
        end
        task.Wait(deleteTime)
        Del(self)
    end)
end

function stLaser:frame()
    task_Do(self)
    
    local bx, by = self.beginX, self.beginY
    local len, rot = self.length, self.rot

    self.x = bx
    self.y = by
    self.beginX = bx
    self.beginY = by
    self.endX = bx + len * self.COSA
    self.endY = by + len * self.SINA

    local delay = self.delay

    local w = delay > 0 and (self.width) / 15 or (self.width)

    delay = delay - 1
    
    if delay < 0 then delay = 0 end
    if delay == 0 then
        self.colli = self.colli_user
    end

    self.delay = delay

    local d = self.dest
    d[1] = -w / 2
    d[2] = 0
    d[3] =  w / 2
    d[4] =  self.length

    local c = self.colliObject
    if IsValid(c) then
        c.x = (bx + self.endX) * 0.5
        c.y = (by + self.endY) * 0.5
        c.a = self.length * self.ratioY * 0.5
        c.b = self.width * self.ratioX * 0.5
        c.rot = rot
    end

    if not self.animated then return end

    local anim = self.AnimationData
    local frame = self.animFrame
    self.animCount = self.animCount + 1
    local duration = anim[frame][1]
    if self.animCount % duration == 0 then
        frame = frame + 1
        if frame > self.animFrameMax then
            frame = 1
        end
        self.animFrame = frame
    end
end

function stLaser:render()
    if self.hide then return end

    local color = Color(self.alpha, self.R, self.G, self.B)
    local x = self.beginX
    local y = self.beginY
    local z = 0
    local angleX = 0
    local angleY = 0
    local angleZ = (-self.rot + 90)
    local dest = self.dest

    SetViewMode("world")

    if not self.animated then
        EvaDrawRectA2(self.texture, dest, self.source, self.blend,
                      color, x, y, z, angleX, angleY, angleZ)
        return
    end

    local ad = self.AnimationData[self.animFrame]
    local src = self._render_source
    src[1], src[2], src[3], src[4] = ad[2], ad[3], ad[4], ad[5]

    EvaDrawRectA2(self.texture, dest, src, self.blend,
                  color, x, y, z, angleX, angleY, angleZ)
end

---|||||loose laser||||||

local lsLaser = Class(object)

function lsLaser:init(x, y, spd, ang, len, wid, graphic, delay)
    self.texture = texture
    self.graphic = graphic
    self.group = GROUP_ENEMY_BULLET
    self.layer = LAYER_ENEMY_BULLET
    self.bound = false
    self.hide = false
    self.x = x
    self.y = y
    self.z = 0
    self.endX = x
    self.endY = y
    self.rot = 0
    self.navi = true
    self.angle = ang
    self.speed = spd
    self.COSV = cos(ang)
    self.SINV = sin(ang)
    self.accel = 0
    self.min_speed = 0
    self.max_speed = 9999
    self.alpha = 255
    self.R = 255
    self.G = 255
    self.B = 255
    self.angleX = 0
    self.angleY = 0
    self.angleZ = 0
    self.scaleX = 1
    self.scaleY = 1
    self.scaleZ = 0
    self.dest = {0, 0, 0, 0}
    self.source = {0, 0, 0, 0}
    self.blend = EVA_BLEND_ALPHA
    self.angular_velocity = 0
    self.fixed_angle = false
    self.deadtimer = 0
    --|||判定相关|||
    self.colli = false
    self.a = 0
    self.b = 0
    self.rect = true

    self.curLen = 0
    self.length = len
    self.width = wid

    self.ratioX = 0.6
    self.ratioY = 0.6

    ---动画
    self.AnimationData = nil
    self.animated = false
    self.animCount = 0
    self.animFrame = 1
    self.animFrameMax = 1
    self.animDuration = 4

    EvaUpdateShotByData(self, graphic)
    --|||弹雾相关|||
    self.stay = true
    self.delay_timer = delay or 11

    self.colliObject = CreateLaserColli(self, self.length, self.width, self.angle)
end

function lsLaser:frame()
    task_Do(self)
    
    if(self.delay_timer > 0)then
        self.hide = true
        self.delay_timer = self.delay_timer - 1
        return
    end

    if(self.delay_timer == 0)then
        self.hide = false
        self.colli = true
        self.delay_timer = self.delay_timer - 1
    end

    self.speed = self.speed + self.accel
    self.speed = max(self.min_speed, min(self.speed, self.max_speed))

    local w = (self.width)

    self.dest = {-w/2, 0, w/2, self.curLen}
    self.curLen = min(self.curLen + self.speed, self.length)

    self.x = self.x + self.speed * self.COSV
    self.y = self.y + self.speed * self.SINV
    self.angleZ = self.angleZ + self.angular_velocity

    self.endX = self.x + self.curLen * cos(self.angle + 180)
    self.endY = self.y + self.curLen * sin(self.angle + 180)

    local c = self.colliObject
    if(IsValid(c))then
        c.x = (self.x + self.endX)*0.5
        c.y = (self.y + self.endY)*0.5
        c.a = self.curLen * self.ratioY * 0.5
        c.b = self.width * self.ratioX * 0.5
        c.rot = self.angle
    end

    if (self.endX <= -320 - 16) or (self.endX >= 320 + 16) or (self.endY<= -240 - 16) or (self.endY >= 240 + 16) then
        Del(self)
    end

    if (not self.animated) then return end
    self.animCount = self.animCount + 1
    self.animDuration = self.AnimationData[self.animFrame][1]
    if(self.animCount % self.animDuration == 0) then
        self.animFrame = self.animFrame + 1
        if(self.animFrame > self.animFrameMax)then
            self.animFrame = 1
        end
    end
end

function lsLaser:render()
    if(self.hide)then return end
    local color = Color(self.alpha, self.R, self.G, self.B)
    local x = self.x
    local y = self.y
    local z = self.z
    local angleX = self.angleX
    local angleY = self.angleY
    local angleZ = (-self.rot + 90) + 180
    local dest = self.dest
    local source = self.source
    SetViewMode("world")
    if not (self.animated) then EvaDrawRectA2(self.texture, dest, source, self.blend, color, x, y, z, angleX, angleY, angleZ) return end
    local ad = self.AnimationData[self.animFrame]
    source = {ad[2], ad[3], ad[4], ad[5]}
    EvaDrawRectA2(self.texture, dest, source, self.blend, color, x, y, z, angleX, angleY, angleZ)
end

function EvaStLaserToItem(objL)
    local x1 = objL.beginX
    local y1 = objL.beginY
    local x2 = objL.endX
    local y2 = objL.endY
    local seg = 16
    local dis = Dist(x1, y1, x2, y2)
    local times = int(dis/seg)
    --[[for i = 0, times do
        New(item_faith_minor, x1 + (x2 - x1)*i/times, y1 + (y2 - y1)*i/times)
    end]]
    New(item_faith_minor, x1 + (x2 - x1)*0.5, y1 + (y2 - y1)*0.5)
    Del(objL)
end

function EvaCreateStraightLaserA1(x, y, ang, len, wid, deleteTime, graphic, delay, NoColli)
    return New(stLaser, x, y, ang, len, wid, deleteTime, graphic, delay, NoColli)
end

function EvaCreateLooseLaserA1(x, y, spd, ang, len, wid, graphic, delay)
    return New(lsLaser, x, y, spd, ang, len, wid, graphic, delay)
end

function EvaSetLaserWidth(obj, w)
    obj.width = w
end

function EvaSetLaserLength(obj, l)
    obj.length = l
end

function EvaSetStLaserPos(obj, x, y)
    obj.beginX = x
    obj.beginY = y
end

function EvaSetStLaserAngle(obj, a)
    obj.rot = a
    obj.COSA = cos(a)
    obj.SINA = sin(a)
end