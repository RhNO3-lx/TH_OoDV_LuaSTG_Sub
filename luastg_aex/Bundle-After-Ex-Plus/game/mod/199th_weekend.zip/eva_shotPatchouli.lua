local wait = task.Wait

--|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||

local EvaPatchouliTShotType1_Laser

function EvaPatchouliTShotType1(objE)
    EvaTask(function ()
        local d = 1
        for _ = 0, 2 do
            EvaCallSE(EVA_SE_SHOT4)
            EvaExplosionB1Type(objE.x, objE.y, 10, 2, {0,0,0}, EVA_COLOR_WHITE)
            for iW = 0, 5 do
                local x = objE.x
                local y = objE.y
                EvaPatchouliTShotType1_Laser(x, y, iW * (360/6), d * 2)
            end
            d = -d
            wait(20)
        end
    end)
end

function EvaPatchouliTShotType1_Laser(x, y, iniAng, dA)
    local spd = 0.05
    local objL = EvaCreateUserLooseLaserA1(x, y, spd, iniAng, 31, 36, EVA_COLOR_WHITE)
    EvaTask(function ()
        while IsValid(objL) do
            iniAng = iniAng + dA
            spd = spd + 0.2
            EvaObjMove_SetSpeed(objL, spd)
            EvaChangeShotAngle(objL, iniAng)
            wait()
        end
    end)
end

--|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||

local EvaPatchouliTShotType2_SnowFlake

function EvaPatchouliTShotType2(objE)
    EvaTask(function ()
        local dA = ran:Float(0, 360)
        local d = 3
        for _ = 1, 8 do
            EvaCallSE(EVA_SE_SHOT2)
            EvaFoliageExplosion(objE.x, objE.y, 5, 60, EVA_COLOR_WHITE)
            for iW = 0, 5 do
                local x = objE.x
                local y = objE.y
                EvaPatchouliTShotType2_SnowFlake(x, y, dA + iW * (360/6), d)
                d = -d
            end
            dA = ran:Float(0, 360)
            wait(15)
        end
    end)
end

function EvaPatchouliTShotType2_SnowFlake(x, y, iniAng, dA)
    local objS = EvaCreateUserShotA1(x, y, 4, iniAng, ADD_BGW_BALL_S_WHITE, 30)
    local objs = {}
    for i = 1, 6 do
        objs[i] = EvaCreateUserShotA1(x, y, 0, iniAng + i * 60, ADD_BGW_ICE_WHITE, 30)
    end
    objS.bound = true
    EvaSetPosition(objS, x, y, 0)
    EvaTask(function ()
        local x1,y1,ang
        for i = 1, 30 do
            iniAng = iniAng + dA
            local rate = i/30
            if not IsValid(objS) then break end
            EvaObjMove_SetSpeed(objS, 4*(1 - rate))
            for c = 1, 6 do
                ang = c*60 + iniAng
                x1 = objS.x + 16 * cos(ang)
                y1 = objS.y + 16 * sin(ang)
                if IsValid(objs[c]) then
                    EvaObjMove_SetPosition(objs[c], x1, y1)
                    EvaChangeShotAngle(objs[c], ang)
                end
            end
            wait()
        end
        if(IsValid(objS))then
            EvaChangeShotAngle(objS, iniAng)
        end
        for i = 1, 60 do
            iniAng = iniAng + dA
            local rate = i/30
            if not IsValid(objS) then break end
            EvaObjMove_SetSpeed(objS, 2*rate)
            for c = 1, 6 do
                ang = c*60 + iniAng
                x1 = objS.x + 16 * cos(ang)
                y1 = objS.y + 16 * sin(ang)
                if IsValid(objs[c]) then
                    EvaObjMove_SetPosition(objs[c], x1, y1)
                    EvaChangeShotAngle(objs[c], ang)
                end
            end
            wait()
        end
        while IsValid(objS) do
            iniAng = iniAng + dA
            for c = 1, 6 do
                ang = c*60 + iniAng
                x1 = objS.x + 16 * cos(ang)
                y1 = objS.y + 16 * sin(ang)
                if IsValid(objs[c]) then
                    EvaObjMove_SetPosition(objs[c], x1, y1)
                    EvaChangeShotAngle(objs[c], ang)
                end
            end
            wait()
        end
        for c = 1, 6 do
            if IsValid(objs[c]) then
                Del(objs[c])
            end
        end
    end)
end