local wait = task.Wait



--|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||

local EvaAliceTDoll
local EvaAliceTDollManage
local EvaAliceTDoll_Line
local EvaAliceTDoll_Laser
local EvaAliceTDoll_LaserAI

function EvaAliceTShotType1(alice, times)
    EvaTask(function ()
        local da = 100
        for i = 1, times do
            if(EvaIsTimeOut())then break end
            EvaCallSE(EVA_SE_SHOT4, 2.0, alice.x/320)
            for c = 0, 3 do
                EvaAliceTDollManage(alice, c * 90 + i * 90, da, 1 + (i - 1) * 1, 3)
            end
            da = da + 50
            da = -da
            wait(20)
        end
    end)
end

function EvaAliceTDollManage(objE, iniAng, dA, speed, ways)
    local obj = EvaDummyObjectForTask()
    local x = objE.x
    local y = objE.y
    local cx = objE.x
    local cy = objE.y
    local r = 0
    EvaSetPosition(obj, x, y, 0)
    obj.dAv = 0
    for c = 0, ways - 1 do
        local doll = EvaAliceTDoll(obj, objE, 120, c * (360/ways) + 90/ways, sign(dA)*2)
        for i = 0, 1 do
            EvaAliceTDoll_Laser(doll, i * 180, sign(dA)*15)
        end
    end
    EvaTask(function ()
        while true do
            if(not IsValid(objE)) then break end
            if(EvaIsOutScreen(x, y, 90))then
                break
            end
            r = r + speed
            --线速度化角速度
            obj.dAv = dA/r
            cx = objE.x
            cy = objE.y
            x = cx + r * cos(iniAng)
            y = cy + r * sin(iniAng)
            iniAng = iniAng + obj.dAv
            EvaSetPosition(obj, x, y, 0)
            wait()
        end
        EvaCallSE(EVA_SE_SHOT3)
        Del(obj)
    end)
end

function EvaAliceTDoll(objOrbit, objE, radius, iniAng, dA)
    local obj = EvaSimpleAliceDoll(objE)
    local time = 360
    local x = objOrbit.x
    local y = objOrbit.y
    local cx = objOrbit.x
    local cy = objOrbit.y
    local r = 0
    local dAv = dA
    EvaAliceTDoll_Line(objE, obj)
    EvaTask(function ()
        local i = 1
        while true do
            if(EvaIsOutScreen(x, y, 0)) then break end
            local scale = 1 * sin(min(i/30, 1)*90)
            EvaSetScaleXYZ(obj, scale, scale, 0 )
            if not IsValid(objOrbit) then break end
            r = radius * sin((min(i/time, 1)) * 90)
            --线速度化角速度
            dAv = dA
            cx = objOrbit.x
            cy = objOrbit.y
            x = cx + r * cos(iniAng)
            y = cy + r * sin(iniAng)
            iniAng = iniAng + dAv
            EvaSetPosition(obj, x, y, 0)
            i = i + 1
            wait()
        end
        Del(obj)
        EvaAliceTDoll_Explosion(x, y)
    end)
    return obj
end

function EvaAliceTDoll_Explosion(x, y)
    EvaTask(function ()
        EvaCallSE(EVA_SE_SHOT6)
        EvaExplosionB1Type(x, y, 30, 4, {0, 0, 0}, EVA_COLOR_WHITE)
        EvaExplosionB1Type(x, y, 30, 5, {ran:Float(30,90), ran:Float(30,90), ran:Float(30,90)}, EVA_COLOR_WHITE)
        EvaCherryExplosion(x, y, 8, 60, EVA_COLOR_WHITE)
        --Nuclear
        EvaCallSE(EVA_SE_FIRE2)
        local r = 40
        local nuclear = EvaExplosiveFlameSetA2(x, y, r, 10, 255, EVA_COLOR_WHITE)
        --r = r + 10
        for i = 1, 6 do
            local a = i * 36 + ran:Float(0, 0)
            local v = ran:Float(2, 4)
            local x1 = x + r * cos(a)
            local y1 = y + r * sin(a)
            --EvaCallSE(EVA_SE_SHOT3)
            EvaCreateShotA2(x1, y1, 0, a, 0.008, v, ADD_BGW_FIRE_WHITE, 20)
            wait(4)
        end
        Del(nuclear)
    end)
end

function EvaAliceTDoll_Laser(objE, iniAng, rotSpeed)
    local objL = EvaCreateStraightLaserA1(objE.x, objE.y, 0, 0, 10, 999999, ADD_BGB_RICE_S_WHITE, 0)
    objL.blend = EVA_BLEND_ALPHA
    objL.ratioX = 0.2
    EvaTask(function ()
        local rX = 40
        local rY = 15
        local x = 0
        local y = 0
        local l = 0
        local a = 0
        local count = 0
        while IsValid(objE) do
            x = rX * cos(iniAng)
            y = rY * sin(iniAng)
            a = Angle(0, 0, x, y)
            l = Dist(0, 0, x, y)
            EvaSetLaserLength(objL, l)
            EvaSetStLaserAngle(objL, a)
            EvaSetStLaserPos(objL, objE.x, objE.y)
            iniAng = iniAng + rotSpeed
            --if(count % 1 == 0) then
                EvaAliceTDoll_LaserAI(objL)
            --end
            count = count + 1
            wait()
        end
        Del(objL)
    end)
end

function EvaAliceTDoll_LaserAI(objL)
    local obj = EvaCreateStraightLaserA1(objL.beginX, objL.beginY, objL.rot, objL.length, objL.width, 999999, ADD_BGB_RICE_S_BLUE, 0, true)
    EvaTask(function ()
        local t = 8
        for i = t, 0, -1 do
            local rate = i/t
            EvaSetStLaserPos(obj, objL.beginX, objL.beginY)
            EvaSetAlpha(obj, 128 * rate)
            wait()
        end
        Del(obj)
    end)
end

--|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||

local EvaAliceTShotType2_Doll
local EvaAliceTShotType2_Doll_Laser


function EvaAliceTShotType2(alice)
    EvaTask(function ()
        local dA = ran:Float(0, 360)
        for _ = 1, 3 do
            for iW = 0, 4 do
                EvaCallSE(EVA_SE_SHOT5)
                EvaAliceTShotType2_Doll(alice, dA + iW * 30)
                wait(3)
            end
            dA = dA + 90
            wait(30)
        end
        wait(30)
        --来波一圈大的
        for i= 1, 20 do
            EvaCallSE(EVA_SE_SHOT5)
            EvaAliceTShotType2_Doll(alice, i * 18)
            wait(4)
        end
    end)
end

function EvaAliceTShotType2_Doll(objE, iniAng)
    local obj = EvaSimpleAliceDoll(objE)
    EvaAliceTDoll_Line(objE, obj)
    EvaSetScaleXYZ(obj, 0.0, 0.0, 0.0)
    EvaTask(function ()
        local dis = 100
        local time = 20
        local angle = -360 * 4
        local x = objE.x
        local y = objE.y
        local x1 = x
        local y1 = y
        for i = 1, time do
            local rate = i/time
            angle = -360 * 4 * (1-rate)
            local r = dis * sin(rate*90)
            x1 = x + r * cos(iniAng)
            y1 = y + r * sin(iniAng)
            EvaSetAngleXYZ(obj, 0, 0, angle)
            EvaSetScaleXYZ(obj, rate, rate, 0.0)
            EvaObjMove_SetPosition(obj, x1, y1)
            wait()
        end
        local a = Angle(obj, lstg.player)
        dis = 800
        EvaCallSE(EVA_SE_WAVE)
        EvaEffect_LaserWarning3(x1, y1, a, 16, 800, 20, 20, 255, EVA_COLOR_WHITE)
        wait(40)
        --突刺
        EvaExplosionB1Type(x1, y1, 20, 2, {ran:Float(20, 80), ran:Float(20, 80), ran:Float(0, 360)}, EVA_COLOR_WHITE)
        local objS = EvaCreateLooseLaserA1(x1, y1, 60, a, 256, 16, ADD_BGB_RICE_S_WHITE, 0)
        objS.raitoY = 0.5
        EvaCallSE(EVA_SE_SHOT4)
        for i = 1, 20 do
            if not IsValid(objE) then break end
            local rate = i/20
            local l = dis * sin(rate*90)
            local x2 = x1 + l * cos(a)
            local y2 = y1 + l * sin(a)
            EvaObjMove_SetPosition(obj, x2, y2)
            wait()
        end
        Del(obj)
    end)
end


--||||||||||||||||||||||||||||||||||||||||||||||||||
function EvaAliceTDoll_Line(objA, objB)
    local obj = EvaCreateStraightLaserA1(objA.x, objA.y, 0, 0, 16, 999999, ADD_BGW_BEAM_ST_YELLOW, 999999, true)
    local l = 0
    local a = Angle(objA, objB)
    obj.layer = LAYER_ENEMY - 1
    --EvaObjRender_SetColor_ColorNum(obj, EVA_COLOR_YELLOW)
    EvaSetAlpha(obj, 128)
    EvaTask(function ()
        while(IsValid(objA) and IsValid(objB))do
            if(objB.dying)then break end
            obj.beginX = objA.x
            obj.beginY = objA.y
            l = Dist(objA, objB)
            a = Angle(objA, objB)
            EvaSetStLaserAngle(obj, a)
            EvaSetLaserLength(obj, l)
            wait()
        end
        Del(obj)
    end)
end