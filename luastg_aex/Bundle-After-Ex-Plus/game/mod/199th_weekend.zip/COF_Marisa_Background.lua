Marisa_background=Class(background)
----------------  纯 Lua 实现，不 require 任何模块  ----------------
local function Rotate2D(x, y, a)
    local c, s = cos(a), sin(a)
    return x * c - y * s, x * s + y * c
end

local function Rotate3D(x, y, z, a, b, c)
    -- 顺序 X-Y-Z，与原来保持一致
    local xr = { {1,0,0}, {0,cos(a),-sin(a)}, {0,sin(a),cos(a)} }
    local yr = { {cos(b),0,-sin(b)}, {0,1,0}, {sin(b),0,cos(b)} }
    local zr = { {cos(c),sin(c),0}, {-sin(c),cos(c),0}, {0,0,1} }
    -- 预乘矩阵：zr * yr * xr * vec
    local vec = {x, y, z}
    local tmp = {}
    for i = 1, 3 do
        tmp[i] = xr[i][1]*vec[1] + xr[i][2]*vec[2] + xr[i][3]*vec[3]
    end
    vec = tmp
    for i = 1, 3 do
        tmp[i] = yr[i][1]*vec[1] + yr[i][2]*vec[2] + yr[i][3]*vec[3]
    end
    vec = tmp
    for i = 1, 3 do
        tmp[i] = zr[i][1]*vec[1] + zr[i][2]*vec[2] + zr[i][3]*vec[3]
    end
    return tmp[1], tmp[2], tmp[3]
end

-- 下面两个只有 world 用到，且 billboard 全传 nil，可先留空实现
local function WorldToBillboard(x, y)
    -- 按 draw.lua 原公式：return x / (world.t - world.b)
    local w = lstg.world
    return x / (w.t - w.b), y / (w.t - w.b)
end
local function WindowToBillboard(x, y)
    local h = screen.height * screen.scale
    return x / h, y / h
end
-- 在 world.lua 顶部（任何函数之外）插入下面这段
local function Rect3D(name, blend, color, dest, source, x, y, z, angleX, angleY, angleZ, billboard)
    -- 如果以后需要 billboard 换算再补，目前 world.lua 里全是 nil，可留空
    if billboard == "world" then
        -- 这里需要 calc.WorldToBillboard，下文一并给你
        dest[1], dest[3] = WorldToBillboard(dest[1], dest[3])
        dest[2], dest[4] = WorldToBillboard(dest[2], dest[4])
    elseif billboard == "window" then
        dest[1], dest[3] = WindowToBillboard(dest[1], dest[3])
        dest[2], dest[4] = WindowToBillboard(dest[2], dest[4])
    end

    -- 四个顶点依次旋转
    local x0, y0, z0 = Rotate3D(dest[1], dest[4], 0, angleX, angleY, angleZ)
    local x1, y1, z1 = Rotate3D(dest[2], dest[4], 0, angleX, angleY, angleZ)
    local x2, y2, z2 = Rotate3D(dest[2], dest[3], 0, angleX, angleY, angleZ)
    local x3, y3, z3 = Rotate3D(dest[1], dest[3], 0, angleX, angleY, angleZ)

    -- 直接调用 LSTG 原生接口
    RenderTexture(name, blend,
        {x + x0, y + y0, z + z0, source[1], source[4], color},
        {x + x1, y + y1, z + z1, source[2], source[4], color},
        {x + x2, y + y2, z + z2, source[2], source[3], color},
        {x + x3, y + y3, z + z3, source[1], source[3], color})
end
-- --------------  world.lua 顶部  --------------
local modes = {}        -- 手动建表，跟原来下标对齐
modes[0]  = function(x) return x end                                   -- linear
modes[2]  = function(x) return x * x end                               -- easeIn2
modes[3]  = function(x) return x * x * x end                           -- easeIn3
modes[12] = function(x) return 1 - (1 - x) * (1 - x) end               -- easeOut2
modes[13] = function(x) return 1 - (1 - x) * (1 - x) * (1 - x) end     -- easeOut3
-- 有需求再继续往表里加

local function func(from, to, t, mode)
    -- 默认线性
    if mode == nil or mode == 0 then
        return from + (to - from) * t
    end
    -- 数字下标
    local f = modes[mode]
    if f then
        return from + (to - from) * f(t)
    end
    -- 万一传了自定义函数
    if type(mode) == "function" then
        return from + (to - from) * mode(t)
    end
    -- 兜底
    return from + (to - from) * t
end
-- --------------  下方你的 world 逻辑照常写 --------------
function Marisa_background:init()
background.init(self,false)
-- 资源列表
	local tex_list = {
		{"leaf",   "COF_st02a2.png"},
		{"cliff",  "COF_st02a.png"},
		{"rainbow","COF_st02a3.png"}
		}

-- 保存句柄
self.tex = {}
	for _, v in ipairs(tex_list) do
		LoadTexture(v[1], v[2])
		SetTextureSamplerState(v[1], "linear+wrap")
		table.insert(self.tex, v[1])
	end

-- 可选：若后面还要当 Image 用，再补一行
	LoadImage("leaf",   "leaf",   0,0,256,256)
	LoadImage("cliff",  "cliff",  0,0,256,256)
	LoadImage("rainbow","rainbow",0,0,64,128)

    Set3D("up", 0.0, 1.0, 0.0)
    Set3D("fovy", 0.62831855)
    Set3D("eye", 0.0, 0.0, -800.0)
    self.facing = {0.0, 90.0, 60.0}
    Set3D("fog", 100.0, 800.0, Color(0xFF112626))
    Set3D("z", 0.1, 5120.0)
	self.time = -1
	self.flag = 0
    self.rocking = false
    self.rocking_t = 0

    self.script_t = {0, 0}
	self.timeMap = {
    {0,     1536,   0,    1536, false}, -- 0   ~1536  正常
    {1536,  2560, 512,    1536, true }, -- 1536~2560  512~1536 循环
    {2560,  3072, 1536,   2048, false}, -- 2560~3072  1536~2048 放慢×1
    {3072,  3328, 2048,   2176, false}, -- 3072~3328  2048~2176 放慢×1
    {3328,  3840, 2176,   2688, false}, -- 3328~3840  2176~2688
    {3840,  4608, 2688,   3456, false}, -- 3840~4608  2688~3456
    {4608,  5120, 3456,   3968, false}, -- 4608~5120  3456~3968
    {5120,  5632, 3968,   4480, false}, -- 5120~5632  3968~4480
    {5632,  6144, 4480,   4992, true }, -- 5632~6144  Boss段循环
	}
end
-- 把新的 self.time 转成旧的“虚拟时间”
	local function mapTime(t, map)
		for _, seg in ipairs(map) do
			local n0, n1, o0, o1, loop = seg[1], seg[2], seg[3], seg[4], seg[5]
			if t >= n0 and t < n1 then
				local lenNew = n1 - n0
				local lenOld = o1 - o0
				local k = (t - n0) / lenNew
				if loop then        -- 循环段：512~1536 无限重复
                k = (t - n0) % lenOld / lenOld
				end
				return o0 + k * lenOld
			end
		end
    -- 兜底：6144 以后继续 Boss 循环
    local last = map[#map]
    local n0, o0, o1 = last[1], last[3], last[4]
    local lenOld = o1 - o0
    return o0 + ((t - n0) % lenOld)
end
function Marisa_background:frame()
    if t == nil then
        t = 0  -- 或者你希望的默认值
    end
	if ext.sc_pr or self.jump_boss then
		if self.time < 5632 then
            self.time = 5632
        end
    end
	self.time = self.time + 1
	local vtime = mapTime(self.time, self.timeMap)
	local time = vtime
    if time >= 0 and time < 512 then
        local t = (time - 0)
        Set3D("eye", 0.0, func(0.0, 512.0, min(t / 512, 1), 0), -800.0)
    elseif time >= 512 and time < 1024 then
        local t = (time - 512)
        Set3D("eye", 0.0, func(512.0, 1024.0, min(t / 512, 1), 0), -800.0)
    elseif time >= 1024 and time < 1536 then
        local t = (time - 1024)
        Set3D("eye", 0.0, func(512.0, 1024.0, min(t / 512, 1), 0), -800.0)
    elseif time >= 1536 and time < 2048 then
        local t = (time - 1536)
        Set3D("eye", 0.0, func(512.0, 1024.0, min(t / 512, 1), 0), -800.0)
    elseif time >= 2048 and time < 2176 then
        local t = (time - 2048)
        Set3D("eye", 0.0, func(512.0, 640.0, min(t / 128, 1), 0), -800.0)
    elseif time >= 2176 and time < 3456 then
        local t = (time - 2176)
        self.rocking = true
        self.facing = {0.0,func(90.0, 60.0, min(t / 600, 1), 0), 60.0}
        if time >= 2176 and time < 2688 then
            Set3D("eye", 0.0, func(640.0, 1152.0, min(t / 512, 1), 0), -800.0)
        elseif time >= 2688 then
            t = (time - 2688)
            local c1, c2 = Color(0xFF112626), Color(0xFF483D8B)
            local a1, r1, g1, b1 = c1:ARGB()
            local a2, r2, g2, b2 = c2:ARGB()
            local color = Color(func(a1, a2, min(t / 512, 1), 0), func(r1, r2, min(t / 512, 1), 0), func(g1, g2, min(t / 512, 1), 0), func(b1, b2, min(t / 512, 1), 0))
            Set3D("fog", func(100.0, 900.0, min(t / 512, 1), 0), func(800.0, 1800.0, min(t / 512, 1), 0), color)
            if time >= 2688 and time < 2944 then
                t = (time - 2688)
                Set3D("eye", 0.0, func(640.0, 896.0, min(t / 256, 1), 0), -800.0)
            elseif time >= 2944 and time < 3456 then
                t = (time - 2944)
                Set3D("eye", 0.0, func(384.0, 896.0, min(t / 512, 1), 0), -800.0)
            end
        end
    elseif time >= 3456 and time < 3968 then
        local t = (time - 3456)
        Set3D("eye", 0.0, func(384.0, 896.0, min(t / 512, 1), 0), -800.0)
    elseif time >= 3968 and time < 4480 then
        local t = (time - 3968)
        Set3D("eye", 0.0, func(384.0, 896.0, min(t / 512, 1), 0), -800.0)
    elseif time >= 4480 and time < 4992 then
        if ext.sc_pr or self.jump_boss then
            self.flag = 1
            self.rocking = true
            local t = (time - 4480)
            Set3D("eye", 0.0, func(384.0, 896.0, min(t / 512, 1), 0), -800.0)
            self.facing = {0.0, 60.0, 60.0}
            Set3D("fog", 900.0, 1800.0, Color(0xFF483D8B))
        else
            self.time = 5120
        end
    elseif time >= 4992 then
        self.time = 5632
    end
   for i = 1, 3 do
        lstg.view3d.at[i] = lstg.view3d.eye[i] + self.facing[i]
    end
    if self.rocking then
        self.rocking_t = self.rocking_t + 1
        local t = self.rocking_t
        local a = 15 / 90 * 0.5
        Set3D("up", a * sin(t / 4), 1.0, 0.0)
    end
    for i, v in ipairs(self.script_t) do
        self.script_t[i] = v + 1
    end	
end

function Marisa_background:render()
	SetViewMode'3d'
	background.WarpEffectCapture()
    background.ClearToFogColor()
    for y = 2512, -48, -512 do
        local sx, sy, sz = 0, 0 + y, 0
        local color = Color(0xFFFFFFFF)
        local spr = {0, 0, 2048, 512}
        local w, h = 2048, 512
        Rect3D(self.tex[2], "", color, {-w / 2, w / 2, -h / 2, h / 2}, {spr[1] + 0, spr[1] + spr[3], spr[2] + spr[4], spr[2] + 0},
            sx, sy, sz, 0, 0, 0)
    end
	
    for y = 2512, -48, -512 do
        local sx, sy, sz = 0, 0 + y, -300
        local color = Color(128, 255, 255, 255)
        local spr = {0, 0, 2048, 512}
        local w, h = 2048, 512
        Rect3D(self.tex[3], "mul+add", color, {-w / 2, w / 2, -h / 2, h / 2}, {spr[1] + 0, spr[1] + spr[3], spr[2] + spr[4], spr[2] + 0},
            sx, sy, sz, 0, 0, 0)
    end

    for y = 2512, -48, -512 do
        local x, z = -160, -500
        local pos = {
            {0, 0, 0},
            {32, -128, 0},
            {0, -256, 0},
            {-32, -384, 0},
        }
        local d = {1, -1}
        for j = 1, 2 do
            for _, v in ipairs(pos)  do
                local sx, sy, sz = (x * d[j]) + v[1], y + v[2], z + v[3]
                local dx = 64 * d[j]
                local r, g, b = 255, 255, 255
                if self.flag == 0 then
                    if self.script_t[1] >= 4096 then
                        local t = (self.script_t[1] - 4096)
                        dx = func(64 * d[j], 0, min(t / 500, 1), 9)
                        r = func(255, 64, min(t / 500, 1), 9)
                        g = func(255, 64, min(t / 500, 1), 9)
                        b = func(255, 64, min(t / 500, 1), 9)
                    end
                elseif self.flag == 1 then
                    dx = 0
                    r, g, b = 64, 64, 64
                end
                local color = Color(255, r, g, b)
                local spr = {0, 0, 512, 435}
                local w, h = 512 * 0.5, 435 * 0.5
                local eye = lstg.view3d.eye
                local xa = atan2(sy - eye[2], sz - eye[3])
                Rect3D(self.tex[1], "", color, {-w / 2, w / 2, -h / 2, h / 2}, {spr[1] + 0, spr[1] + spr[3], spr[2] + spr[4], spr[2] + 0},
                sx + dx, sy, sz, -xa, 0, 0)
            end
        end
    end
    background.WarpEffectApply()
    SetViewMode("world")
end

return Marisa_background