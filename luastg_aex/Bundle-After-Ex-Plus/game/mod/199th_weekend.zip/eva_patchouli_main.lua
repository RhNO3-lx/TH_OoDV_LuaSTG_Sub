---@diagnostic disable: undefined-field, inject-field
--//五曜「终焉艾利克西尔」

--//总时长150s

local phase = 1
local phaseMax = 5

function EvaResetPhase()
    phase = 1
    phaseMax = 5
end

local AngleMove, Enemy
function AngleMove(objE, time)
	task.New(objE, function()
		local iniAng = objE.ENEMY_BASE_ANGLE
		local finAng = _boss.CommonValue.angA[objE.ENEMY_NUM]
		local dAng = finAng - iniAng
		while(dAng > 180)do
			dAng = dAng - 360
		end
		while(dAng < -180)do
			dAng = dAng + 360
		end
		for t = 1, time do
			local rate = 0.5-0.5*cos(180*t/time)
			local a = iniAng + dAng*rate
			objE.ENEMY_BASE_ANGLE = a
			task.Wait()
		end
	end)
end

function EvaGetBossLife(objE)
	return objE.hpHelper.hp
end

function EvaIsTimeOut()
	return _boss.countdown <= 0
end

function EvaIsInDialogue()
    return lstg.player.dialog
end

function EvaDummyHpForBoss(objE, hp)
	local obj = EvaDummyObjectForTask()
    obj.hp = hp
    obj.hpmax = hp
    EvaSetPosition(obj, EvaGetX(objE), EvaGetY(objE), 0)
	objE.hpHelper = obj
    objE.hpHelper.text = New(_editor_class["eva_showText"],objE.x, objE.y, obj, "hp", 20)
    task.New(obj, function ()
        while IsValid(objE) do
            obj.x = objE.x
            obj.y = objE.y
            if(phase == phaseMax and objE.colli)then
                obj.hp = objE.hp
            end
            task.Wait()
        end
        Del(objE.hpHelper)
        Del(objE.hpHelper.text)
        Del(obj)
    end)

	return obj
end

function EvaCon(objE, color)
	task.New(objE, function()
		task.Wait(60)
		EvaCallSE(EVA_SE_SHOT5)
		EvaBulletEffectA2(_boss, -16, 24, objE, 0, 0, 6, ran:Float(160, 200), 60, 1.0, 95, color)
		EvaBulletEffectA2(_boss, -16, 24, objE, 0, 0, 6, ran:Float(160, 200), 60, 1.0, 95, color)
		task.Wait(60)
		EvaCallSE(EVA_SE_FIRE1)
		EvaSetStoneElementColor(objE, color)
		EvaSetStoneDrawColor(objE, color)
		EvaChangeVanishEffectColor(objE, color)
		EvaCherryExplosion(objE.x, objE.y, 25, 90, color)
		
		EvaExplosionB2Type(objE.x, objE.y, 30, 1.75, color)
		EvaExplosionB2Type(objE.x, objE.y, 30, 2.50, color)
		task.Wait(60)
		objE.colli = true
	end)
end

function EvaSetStoneDamage(objE, num)
	objE["StoneDamage"] = num
end

function EvaGetStoneDamage(objE)
	return objE["StoneDamage"] or 0
end

function EvaAddStoneDamage(objE, num)
	objE["StoneDamage"] = objE["StoneDamage"] + num
end

local RandomShot

function EvaPatchouliMain(self)
    self.scRing = EvaCallSCRing(self, 150)
    --PlayMusic("EvaBGM01", 1.0, 0)
    if(not lstg.tmpvar.packageSet) then
        EvaClampPlayer()
        EvaDrawFrame()
        SetWorld(0, 0, 640, 480, 90, false)
    end
    EvaSetBossAlpha(self, 128)

    self.colli = false

    EvaBarrierEffect(0, 1)

    self.CommonValue = {}
    local cv = self.CommonValue
    cv.BaseX = 0
    cv.BaseY = 128
    cv.colorA = {EVA_COLOR_RED,EVA_COLOR_BLUE,EVA_COLOR_GREEN,EVA_COLOR_YELLOW,EVA_COLOR_ORANGE}
    cv.enemyA = {}
    cv.angA = {}
    cv.ANG_D = 1
    cv.phase = 1
    cv.phaseMax = 5
    cv.lifeMax = 0
    cv.lifeMaxAdd = 0
    cv.lifeAdd = 400
    cv.phaseTime = 120

    cv.lifeMax = 2400

    EvaDummyHpForBoss(self, cv.lifeMax)

    EvaSetMovePositionBraking01(self, cv.BaseX, cv.BaseY, 60)

    task.Wait(60)
    --EvaSetBossCast(self, 3, 30)
    task.Wait(30)

    EvaExplosionB1Type(self.x, self.y, 30, 6, {0, 0, 0}, EVA_COLOR_WHITE)
    EvaCallSE(EVA_SE_SHOT4)

    --||||||||||||||||||||||||| Summon Stone |||||||||||||||||||||||||||||
    local SP1_angP = 0
    local len = #cv.colorA
    for i = 1, len do
        table.insert(cv.angA, ( 360*i/len + SP1_angP )%360 )
        Enemy(cv.colorA[i])
    end

    EvaTask(function()
        task.Wait(40)
        EvaSetBossCast(self, 2, 60)
    end)

    --||||||||||||||||||||||||| Main Loop |||||||||||||||||||||||||||||
    task.Wait(cv.phaseTime)
    while( cv.phase < cv.phaseMax and not EvaIsTimeOut()) do
        RandomShot()
        while(EvaGetBossLife(self) > 0 and not EvaIsTimeOut()) do
            task.Wait()
        end
        if(EvaIsTimeOut())then break end
        phase = phase + 1
        cv.phase = cv.phase + 1
        local num = 1
        local DamageMax = EvaGetStoneDamage(cv.enemyA[1])
        for iL = 1, #cv.enemyA do
            if(EvaGetStoneDamage(cv.enemyA[iL]) > DamageMax)then
                DamageMax = EvaGetStoneDamage(cv.enemyA[iL])
                num = iL
            end
        end
        local id = cv.enemyA[num].ENEMY_NUM
        --print("Now Delete Stone " .. id .. ", num in table is " .. num)
        Del(cv.enemyA[num])
        table.remove(cv.enemyA, num)
        table.remove(cv.angA, num)
        len = #cv.enemyA
        for i = 1, len do
            --print("we have " ..  cv.enemyA[i].ENEMY_NUM)
        end
        --print("Current Array Len " .. len .. " !")
        if(cv.ANG_D>0)then
            local iniAng = cv.angA[1]
            cv.angA = {}
            for iL = 1, len do
                table.insert(cv.angA, (iniAng + 360*iL/len)%360)
            end
        else
            local finAng = cv.angA[len]
            cv.angA = {}
            for iL = 1, len do
                table.insert(cv.angA, (finAng - 360*iL/len)%360)
            end
        end
        for iL = 1, len do
            cv.enemyA[iL].ENEMY_NUM = iL
            AngleMove(cv.enemyA[iL], 150)
        end
        if IsValid(cv.enemyA[1].sprite) then cv.enemyA[1].sprite.layer = cv.enemyA[1].sprite.layer - 1 end
        task.Wait(30)
        cv.lifeMax = cv.lifeMax + cv.lifeAdd
        for t = 1, cv.phaseTime - 28 do
            self.hpHelper.hp = self.hpHelper.hp + cv.lifeMax/(cv.phaseTime - 30)
            cv.LifeMaxAdd = cv.lifeAdd*((cv.phase-2)+t/(cv.phaseTime-30))
            task.Wait()
        end
        self.hpHelper.hpmax = cv.lifeMax
        self.hpHelper.hp = cv.lifeMax
        cv.LifeMaxAdd = cv.lifeAdd*(cv.phase-1)
        cv.phaseTime = cv.phaseTime + 15
    end
    RandomShot()
    self.hp = cv.lifeMax
    task.Wait(30)
    self.DMG_factor = 4.0
    self.colli = true
    EvaSetBossAlpha(self, 255)
end

local IsCurrentPhase, ResetAllColorA, AddAllColorA, EraseAllColorA2

function RandomShot()
    local helper = _boss.hpHelper
    task.New(helper, function ()
        task.Wait(30)
        local currentPhase = phase
        local wt = 45 --发射间隔
        local wt2 = 45 --发射间隔

        local c = 0
        local cv = _boss.CommonValue
        while(EvaIsCurrentPhase(currentPhase) and not EvaIsTimeOut())do
            EvaResetAllColorA()
            EvaEraseAllColorA2()
            for iQ = 0, 2 do
                if(not EvaIsCurrentPhase(currentPhase) or EvaIsTimeOut()) then
                    return
                end
                local numA = {}
                for iL = 1, #cv.enemyA do
                    numA[iL] = iL
                end
                for iL = 1, #cv.enemyA do
                    if(not EvaIsCurrentPhase(currentPhase) or EvaIsTimeOut()) then
                        return
                    end
                    local num = ran:Int(1, #numA)
                    local objE = cv.enemyA[numA[num]]
                    table.remove(numA, num)
                    local color1 = EvaGetStoneElementColor(objE)
                    local color2 = EvaGetStoneDrawColor(objE)
                    if(color1 == EVA_COLOR_RED)    then EvaTShotRed(objE, currentPhase, wt) end
                    if(color1 == EVA_COLOR_BLUE)   then EvaTShotBlue(objE, currentPhase, wt) end
                    if(color1 == EVA_COLOR_GREEN)  then EvaTShotGreen(objE, currentPhase, wt) end
                    if(color1 == EVA_COLOR_YELLOW) then EvaTShotYellow(objE, currentPhase, wt) end
                    if(color1 == EVA_COLOR_ORANGE) then EvaTShotOrange(objE, currentPhase, wt) end
                    EvaCallSE(EVA_SE_CHARGE3)
                    EvaCherryConcentration(objE, 0, 0, wt, color2)
                    task.Wait(wt)
                end
                task.Wait(wt2)
                if(iQ == 0)then
                    EvaAddAllColorA()
                end
                c = c + 1
            end
            task.Wait(60)
        end
    end)
end

function EvaResetAllColorA()
    EvaResetShotRedArray()
    EvaResetShotBlueArray()
    EvaResetShotGreenArray()
    EvaResetShotYellowArray()
    EvaResetShotOrangeArray()
end

function EvaAddAllColorA()
    if(EvaGetShotRedArrayLength() <= 2)then
        EvaAddShotRedArray(EvaShotRedA_Add)
    end
    if(EvaGetShotBlueArrayLength() <= 2)then
        EvaAddShotBlueArray(EvaShotBlueA_Add)
    end
    if(EvaGetShotGreenArrayLength() <= 2)then
        EvaAddShotGreenArray(EvaShotGreenA_Add)
    end
    if(EvaGetShotYellowArrayLength() <= 2)then
        EvaAddShotYellowArray(EvaShotYellowA_Add)
    end
    if(EvaGetShotOrangeArrayLength() <= 2)then
        EvaAddShotOrangeArray(EvaShotOrangeA_Add)
    end
end

function EvaEraseAllColorA2()
    if(EvaShotRed_Count > 0)then
        EvaEraseShotRedArray2(EvaShotRedA_Chosen)
        EvaShotRedA_Add = EvaShotRedA_Chosen
    end
    if(EvaShotBlue_Count > 0)then
        EvaEraseShotBlueArray2(EvaShotBlueA_Chosen)
        EvaShotBlueA_Add = EvaShotBlueA_Chosen
    end
    if(EvaShotGreen_Count > 0)then
        EvaEraseShotGreenArray2(EvaShotGreenA_Chosen)
        EvaShotGreenA_Add =	EvaShotGreenA_Chosen
    end
    if(EvaShotYellow_Count > 0)then
        EvaEraseShotYellowArray2(EvaShotYellowA_Chosen)
        EvaShotYellowA_Add = EvaShotYellowA_Chosen
    end
    if(EvaShotOrange_Count > 0)then
        EvaEraseShotOrangeArray2(EvaShotOrangeA_Chosen)
        EvaShotOrangeA_Add = EvaShotOrangeA_Chosen
    end
end

function EvaTShotColorNum(num, objE, currentPhase, color)
    if(num == EVA_SP1_SHOT_RED_01) then EvaTShotRedType1( objE, currentPhase, color) end
    if(num == EVA_SP1_SHOT_RED_02) then EvaTShotRedType2( objE, currentPhase, color) end
    if(num == EVA_SP1_SHOT_RED_03) then EvaTShotRedType3( objE, currentPhase, color) end
    if(num == EVA_SP1_SHOT_RED_04) then EvaTShotRedType4( objE, currentPhase, color) end
    if(num == EVA_SP1_SHOT_BLUE_01) then EvaTShotBlueType1( objE, currentPhase, color) end
    if(num == EVA_SP1_SHOT_BLUE_02) then EvaTShotBlueType2( objE, currentPhase, color) end
    if(num == EVA_SP1_SHOT_BLUE_03) then EvaTShotBlueType3( objE, currentPhase, color) end
    if(num == EVA_SP1_SHOT_BLUE_04) then EvaTShotBlueType4( objE, currentPhase, color) end
    if(num == EVA_SP1_SHOT_GREEN_01) then EvaTShotGreenType1( objE, currentPhase, color) end
    if(num == EVA_SP1_SHOT_GREEN_02) then EvaTShotGreenType2( objE, currentPhase, color) end
    if(num == EVA_SP1_SHOT_GREEN_03) then EvaTShotGreenType3( objE, currentPhase, color) end
    if(num == EVA_SP1_SHOT_GREEN_04) then EvaTShotGreenType4( objE, currentPhase, color) end
    if(num == EVA_SP1_SHOT_YELLOW_01) then EvaTShotYellowType1( objE, currentPhase, color) end
    if(num == EVA_SP1_SHOT_YELLOW_02) then EvaTShotYellowType2( objE, currentPhase, color) end
    if(num == EVA_SP1_SHOT_YELLOW_03) then EvaTShotYellowType3( objE, currentPhase, color) end
    if(num == EVA_SP1_SHOT_YELLOW_04) then EvaTShotYellowType4( objE, currentPhase, color) end
    if(num == EVA_SP1_SHOT_ORANGE_01) then EvaTShotOrangeType1( objE, currentPhase, color) end
    if(num == EVA_SP1_SHOT_ORANGE_02) then EvaTShotOrangeType2( objE, currentPhase, color) end
    if(num == EVA_SP1_SHOT_ORANGE_03) then EvaTShotOrangeType3( objE, currentPhase, color) end
    if(num == EVA_SP1_SHOT_ORANGE_04) then EvaTShotOrangeType4( objE, currentPhase, color) end
end

function EvaIsCurrentPhase(currentPhase)
    return (EvaGetBossLife(_boss) > 0 and currentPhase == phase)
end


---|||||||||||||||||||||||| STONE ||||||||||||||||||||||||||||

local AI

function Enemy(color)
    local objE = EvaSimpleEnemy(_boss.hpHelper, _boss.x, _boss.y, 9999999, color)
    EvaDrawStone(objE, 90, EVA_COLOR_WHITE)
    objE.colli = false
    AI(objE, color)

    local cv = _boss.CommonValue


    table.insert(cv.enemyA, objE)

    objE.ENEMY_NUM = #cv.enemyA
    --print("My Enm Num is " .. objE.ENEMY_NUM)
    objE.ENEMY_BASE_ANGLE = cv.angA[objE.ENEMY_NUM]
    objE.StoneDamage = 0

    local ang = 0
    local aSpd = -0.311*cv.ANG_D
    local r = 0
    local rx = 0
    local ry = 0

    EvaCon(objE, color)

    task.New(objE, function()
        for t = 1, 90 do
            local angB = objE.ENEMY_BASE_ANGLE
            ang = ang + aSpd
            r = 150 * sin(90*t/90)
            rx = r * cos(ang + angB)
            ry = r/4 * sin(ang + angB)
            objE.x = cv.BaseX + rx
            objE.y = cv.BaseY + ry
            task.Wait()
        end
        r = 150
        while(IsValid(_boss) and cv.phase < cv.phaseMax)do
            local angB = objE.ENEMY_BASE_ANGLE
            ang = ang + aSpd
            rx = r * cos(ang + angB)
            ry = r/4 * sin(ang + angB)
            objE.x = cv.BaseX + rx
            objE.y = cv.BaseY + ry
            task.Wait()
        end
        for t = cv.phaseTime, 1, -1 do
            local rate = 0.5-0.5*cos(180*t/cv.phaseTime)
            local angB = objE.ENEMY_BASE_ANGLE
            ang = ang + aSpd
            r = 150 * rate
            rx = r * cos(ang + angB)
            ry = r/4 * sin(ang + angB)
            objE.x = cv.BaseX + rx
            objE.y = cv.BaseY + ry
            task.Wait()
        end
        objE.x = cv.BaseX
        objE.y = cv.BaseY
        while(IsValid(_boss))do
            task.Wait()
        end
        for i = 1, 20 do
            objE.sprite.alpha = 255 * (1 - i/20)
            task.Wait()
        end
        Del(objE)
    end)
end

function AI(objE, color)
    local oldX = EvaGetX(objE)
    local oldY = EvaGetY(objE)
    local oldL = objE.hp
    local c = 0
    local hpHelper = _boss.hpHelper
    local lifeRate = hpHelper.hp/5

    local objLifeNum = New(_editor_class["eva_showText"],objE.x, objE.y, objE, "StoneDamage", 4)
    local cv = _boss.CommonValue
    local dObj = EvaDummyObjectForTask()
    task.New(dObj, function ()
        while(IsValid(objE) and cv.phase < cv.phaseMax)do
            local life = objE.hp
            hpHelper.hp = max(hpHelper.hp + (life - oldL), 0)
            EvaAddStoneDamage(objE, oldL - life)
            EvaSetPosition(objLifeNum, EvaGetX(objE), EvaGetY(objE) - 16, 0)
            oldL = life
            oldX = EvaGetX(objE)
            oldY = EvaGetY(objE)
            if(c <= 0) then
                if(objE.hitCount > 0) then
                    c = 4
                    if(hpHelper.hp > lifeRate) then
                        EvaCallSE(EVA_SE_DAMAGE1)
                    else
                        EvaCallSE(EVA_SE_DAMAGE2)
                    end
                end
            end
            c = c - 1
            task.Wait()
        end
        Del(objLifeNum)
        task.Wait()
        if(not IsValid(objE) and not EvaIsTimeOut()) then
            local color1 = color
            local objS = EvaDummyObjectForTask()
            EvaSetPosition(objS, oldX, oldY, 0);
            EvaCallSE(EVA_SE_BOSS_VANISH)
            EvaCallSE(EVA_SE_SHOT5)
            EvaCherryExplosion_Lauge(oldX, oldY, 45, color1)
            for iL = 1, #cv.enemyA do
                cv.enemyA[iL].damage_rate = 0
                local dist = 80/cv.phase
                for iQ = 0, cv.phase - 1 do
                    EvaBulletEffectA2(objS, 0, 0, cv.enemyA[iL], 0, 0, 5, 160 + dist*iQ+ran:Float(0, dist), cv.phaseTime, 1.0, 79, color1)
                end
            end
            task.Wait(cv.phaseTime)
            EvaCallSE(EVA_SE_FIRE1)
            Del(objS)
            for iL = 1, #cv.enemyA do
                local color2 = EvaGetStoneDrawColor(cv.enemyA[iL])
                EvaCherryExplosion(EvaGetX(cv.enemyA[iL]), EvaGetY(cv.enemyA[iL]), 25, 90, color2)
                EvaExplosionB2Type(EvaGetX(cv.enemyA[iL]), EvaGetY(cv.enemyA[iL]), 30, 1.75, color2)
                EvaExplosionB2Type(EvaGetX(cv.enemyA[iL]), EvaGetY(cv.enemyA[iL]), 30, 2.5, color2)
                EvaSetStoneDamage(cv.enemyA[iL], 0)
            end
            task.Wait(75)
            for iL = 1, #cv.enemyA do
                cv.enemyA[iL].damage_rate = 1.0
            end
        end
        Del(dObj)
    end)
end