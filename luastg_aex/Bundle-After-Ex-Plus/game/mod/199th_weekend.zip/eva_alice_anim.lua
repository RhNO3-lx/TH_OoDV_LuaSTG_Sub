local wait = task.Wait
local _tex = "eva_dot_alice"
--||||| 图书弹幕风点阵图 从上往下逐行计数 0 1 2 3 每4张换列 |||||
local _idle = {
    0, 1, 2, 1,     0, 1, 2, 1,     0, 1, 2, 1,     0, 1, 4, 5
} --待机(带眨眼)
local _move    = { 9, 8, 0, 10, 11 } --左移右移
local _sp1     = { 12, 13, 14} --使用符卡
local _sp2     = { 16, 17, 18}    --施法动画1
local _sp3     = { 20, 21, 22} --施法动画2

local _rW = 128
local _rH = 128

local _dur = 8

local function GetUCoordByIndex(index)
    return int(index/4)*_rW
end

local function GetVCoordByIndex(index)
    return (index%4)*_rH
end

local AfterImage

local wisys = Class(object)

function wisys:init(obj)
    self.group = GROUP_GHOST
    self.layer = LAYER_ENEMY
    self.bound = false
    self.dest   = {-_rW*0.5, _rH*0.5, _rW*0.5, -_rH*0.5}
    self.source = {0, 0, _rW, _rH}
    self.blend  = EVA_BLEND_ALPHA
    self.alpha  = 255
    self.R = 255
    self.G = 255
    self.B = 255
    self.target = obj
    self.x      = obj.x
    self.y      = obj.y
    self.rot    = 0
    self.scaleX = 1.0
    self.scaleY = 1.0
    --||帧更新相关||
    self.index      = 0
    self.indexCount = 0
    self.idleCount  = 0
    self.slideX     = 0
    self.dir        = 0
    self.lastX      = 0
    self.diffX      = 0

    self.castTimer   = 0
    self.castFrame  = 0

    self.actSP  = _sp1
    self.actSPN = #self.actSP
    AfterImage(self, 30, 1.5, 3, {255, 255, 63})
end

function wisys:frame()
    task.Do(self)
    if not IsValid(self.target) then Del(self) return end

    self.x = self.target.x
    self.y = self.target.y

    if(self.diffX>0)then
        self.castTimer = 0
        self.castFrame = 0
        self.idleCount = 0
        self.dir = 1
        self.slideX = self.slideX + self.dir
        if(self.slideX >= _dur * 2) then
            self.slideX = _dur * 2
        end
        self.indexCount = int(self.slideX/_dur)
        self.index = _move[3 + self.indexCount]
    elseif(self.diffX<0)then
        self.castTimer = 0
        self.castFrame = 0
        self.idleCount = 0
        self.dir = -1
        self.slideX = self.slideX + self.dir
        if(self.slideX <= -_dur * 2) then
            self.slideX = -_dur * 2
        end
        self.indexCount = int(self.slideX/_dur)
        self.index = _move[3 + self.indexCount]
    else
        self.slideX = self.slideX - self.dir
        if(self.slideX*self.dir <= 1) then
            self.slideX = 0
            self.dir    = 0
        end
        if(self.slideX == 0)then
            self.indexCount = int(self.idleCount/_dur)
            self.index = _idle[self.indexCount + 1]
            self.idleCount = self.idleCount + 1
            if(self.idleCount >= _dur * 12)then
                self.idleCount = 0
            end
            --|||特殊动画(施法, 符卡等)||||
            if(self.castTimer>0)then
                self.idleCount = 0
                self.castTimer = max(self.castTimer - 1, 0)
                self.castFrame = min(self.castFrame + 1, _dur * self.actSPN - 1)
                self.indexCount = int(self.castFrame/_dur)
                self.index = self.actSP[self.indexCount + 1]
            elseif (self.castTimer == 0 and self.castFrame > 0)then
                self.idleCount = 0
                self.castFrame = max(self.castFrame - 1, 0)
                self.indexCount = int(self.castFrame/_dur)
                self.index = self.actSP[self.indexCount + 1]
            end
        else
            --//从Move过渡到Idle
            self.indexCount = int(self.slideX/_dur)
            self.index = _move[3 + self.indexCount]
        end
    end

    self.diffX = self.x - self.lastX
    self.lastX = self.x

    local u = GetUCoordByIndex(self.index)
    local v = GetVCoordByIndex(self.index)

    self.source[1] = u; self.source[3] = u + _rW;
    self.source[2] = v; self.source[4] = v + _rH;
end

function wisys:render()
    local dest = {
        self.dest[1] * self.scaleX,
        self.dest[2] * self.scaleY,
        self.dest[3] * self.scaleX,
        self.dest[4] * self.scaleY
    }
    local color = Color(self.alpha, self.R, self.G, self.B)
    EvaDrawRectA1(_tex, dest, self.source,
    self.blend, color,
    self.x, self.y, self.rot)
end

function EvaSetAliceCast(obj, type, time)
    local wis = obj.sprite
    local acts = {_sp1, _sp2, _sp3}
    wis.slideX = 0
    wis.dir = 0
    wis.diffX = 0
    wis.castTimer = time
    wis.castFrame = 0
    wis.actSP = acts[type]
    wis.actSPN = #wis.actSP
end


function EvaSetAliceAlpha(obj, alpha)
    local wis = obj.sprite
    wis.alpha = alpha
end

function AfterImage(target, duration, fscale, interval, colorA)
    task.New(target, function()
        while (true) do
            local alpha = 255
            local alpha2 = target.alpha 
            local scale = 1.0
            local scaleAdd = (fscale - 1.0)/duration

            local obj = EvaSimpleSprite2D(_tex, LAYER_ENEMY - 4, target.x, target.y)
            EvaSetBlendType(obj, EVA_BLEND_ADD_ARGB)
            EvaSetColor(obj, colorA[1], colorA[2], colorA[3])
            EvaSetSourceRect(obj, target.source[1], target.source[2], target.source[3], target.source[4])
            EvaSetDestRect(obj, -_rW*0.5, _rH*0.5, _rW*0.5, -_rH*0.5)
            task.New(obj, function ()
                for t = 1, duration do
                    local rate = t/duration
                    EvaSetScaleXYZ(obj, target.scaleX * scale, target.scaleY * scale, 1.0)
                    EvaSetAlpha(obj, alpha*alpha2/255*(1-rate))
                    scale = scale + scaleAdd
                    task.Wait()
                end
                Del(obj)
            end)

            task.Wait(interval)
        end
    end)
end

function EvaSetAliceAnimationDollOrbiting(target)
    local obj = EvaSimpleSprite2D(_tex, LAYER_ENEMY - 1, target.x, target.y)
    EvaSetSourceRect(obj, 768, 0, 800, 32)
    EvaSetDestRect(obj, -16, 16, 16, -16)
    EvaSetBlendType(obj, EVA_BLEND_ALPHA)
    EvaSetAlpha(obj, 255)
    EvaSetScaleXYZ(obj, 1.0, 1.0, 0.0)
    
    EvaTask(function ()
        local xR = 32
        local yR = 8
        local count = 0
        -- 计算带倾斜的椭圆参数
        local theta = 0   -- 当前绕椭圆运动的角度（度）
        local phi = 0      -- 椭圆长轴与X轴夹角（度）
        while IsValid(target) do
            local st = theta % 360
            if (st >= 0 and st < 180) then
                obj.layer = LAYER_ENEMY - 2
            else
                obj.layer = LAYER_ENEMY + 1
            end

            -- 椭圆参数方程
            local rad_theta = theta * math.pi / 180
            local rad_phi = phi * math.pi / 180
            local cos_theta, sin_theta = math.cos(rad_theta), math.sin(rad_theta)
            local cos_phi, sin_phi = math.cos(rad_phi), math.sin(rad_phi)

            local x = target.x + xR * cos_theta * cos_phi - yR * sin_theta * sin_phi
            local y = target.y + 8 + xR * cos_theta * sin_phi + yR * sin_theta * cos_phi

            EvaSetScaleXYZ(obj, 1.0 + 0.1 * sin(theta + 180), 1.0+ 0.1 * sin(theta + 180), 0.0)
            EvaSetPosition(obj, x, y, 0)
            local index = int(count/6) % 3
            EvaSetSourceRect(obj, 768, index * 32, 800, (index + 1) * 32)
            phi = 30 * cos(count*0.2)
            theta = theta + 2
            count = count + 1
            wait()
        end
        Del(obj)
    end)
    return obj
end

function EvaSimpleAliceDoll(target)
    local obj = EvaSimpleSprite2D(_tex, LAYER_ENEMY_BULLET + 1, target.x, target.y)
    EvaSetSourceRect(obj, 768, 0, 800, 32)
    EvaSetDestRect(obj, -16, 16, 16, -16)
    EvaSetBlendType(obj, EVA_BLEND_ALPHA)
    EvaSetAlpha(obj, 255)
    EvaSetScaleXYZ(obj, 1.0, 1.0, 0.0)
    
    EvaTask(function ()
        local count = 0
        local index = 0
        while IsValid(target) do
            index = int(count/6) % 3
            EvaSetSourceRect(obj, 768, index * 32, 800, (index + 1) * 32)
            count = count + 1
            wait()
        end
        Del(obj)
    end)
    return obj
end

function EvaSetAliceAnimation(target)
    target.sprite = New(wisys, target)
    EvaSetAliceAnimationDollOrbiting(target)
end