Darkness_background=Class(object)
function Darkness_background:init()
	--
	background.init(self,false)
	--resource
	LoadImageFromFile('Darkness_a','Darkness_a.png')
	LoadImageFromFile('Darkness_b','Darkness_b.png')
	LoadImageFromFile('Darkness_c','Darkness_c.png')
	LoadImageFromFile('Darkness_d','Darkness_d.png')

	--set 3d camera and fog
	Set3D('eye',0,4,-11)
	Set3D('at',0,-1.3,-5.5)
	Set3D('up',0,1,0)
	Set3D('z',2,23.5)
	Set3D('fovy',0.7)
	Set3D('fog',6.0,22.7,Color(200,0,0,10))
	--
	self.speed=0.02
	self._z=0
	--New(camera_setter)
end
function Darkness_background:frame()
	Set3D('eye',0,4+cos(self.timer/3)*1,-11)
	Set3D('up',cos(self.timer/5)*0.3,1,0)
	task.Do(self)
	self._z=self._z+self.speed
	SetImageState('Darkness_a','',Color(cos(self.timer/3)*100,255,255,255))
end

function Darkness_background:render()
	SetViewMode'3d'
	background.WarpEffectCapture()
	background.ClearToFogColor()
	for j=-2,10 do
		local dz=4*j-math.mod(self._z,4)

		Render4V('Darkness_a',
		0,0,dz+2,
		-4,0,dz+2,
		-4,0,dz-2,
		0,0,dz-2)
		Render4V('Darkness_a',
		0,0,dz+2,
		4,0,dz+2,
		4,0,dz-2,
		0,0,dz-2)

	end
	for j=-2,10 do
		local dz=4*j-math.mod(self._z,4)
		local Dx=0.2
		Render4V('Darkness_b',-2.5,1,dz+2,-0.5,1,dz+2,-0.5,1,dz-2,-2.5,1,dz-2)
		Render4V('Darkness_b',2.5-Dx,1,dz+2,0.5-Dx,1,dz+2,0.5-Dx,1,dz-2,2.5-Dx,1,dz-2)
	end
	for j=-2,10 do
		local dz=4*j-math.mod(self._z,4)
		local Dx=-0.2
		Render4V('Darkness_c',-2.5-Dx,1.5,dz+1.5,-0.5-Dx,1.5,dz+1.5,-0.5-Dx,1.5,dz-2.5,-2.5-Dx,1.5,dz-2.5)
		Render4V('Darkness_c',2.5+Dx,1.5,dz+2,0.5+Dx,1.5,dz+1,0.5+Dx,1.5,dz-2,2.5+Dx,1.5,dz-2)
	end
	SetImageState('Darkness_d','',Color(205+50*sin(self.timer),255,255,255))
	for j=-2,10 do
		local dz=4*j-math.mod(self._z,4)

		Render4V('Darkness_d',-2.5,2,dz+2,-0.5,2,dz+2,-0.5,2,dz-2,-2.5,2,dz-2)
		Render4V('Darkness_d',2.5,2,dz+2,0.5,2,dz+1,0.5,2,dz-2,2.5,2,dz-2)

	end
	SetImageState('Darkness_d','',Color(255,255,255,255))
	for j=-2,10 do
		local dz=4*j-math.mod(self._z,4)
		Render4V('Darkness_d',-3,2.6,dz+2,-1,2.6,dz+2,-1,2.6,dz-2,-3,2.6,dz-2)
		Render4V('Darkness_d',3,2.6,dz+1.5,1,2.6,dz+1.5,1,2.6,dz-2.5,3,2.6,dz-2.5)
	end
	background.WarpEffectApply()
	SetViewMode'world'
end













