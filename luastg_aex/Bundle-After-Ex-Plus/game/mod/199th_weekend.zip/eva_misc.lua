EVA_BLEND_ALPHA = "mul+alpha"
EVA_BLEND_ADD_ARGB = "mul+add"
EVA_BLEND_REVERSE = "mul+rev"

function EvaRotate2D(x, y, a)
    return x * cos(a) - y * sin(a), x * sin(a) + y * cos(a)
end

function EvaRotate3D(x, y, z, a, b, c)
    local cos_a, sin_a = cos(a), sin(a)
    local cos_b, sin_b = cos(b), sin(b)
    local cos_c, sin_c = cos(c), sin(c)

    local x_prime = (cos_c * cos_b) * x + (sin_c) * y + (-cos_c * sin_b) * z
    local y_prime = (-cos_a * sin_c * cos_b - sin_a * sin_b) * x + (cos_a * cos_c) * y + (cos_a * sin_c * sin_b - sin_a * cos_b) * z
    local z_prime = (-sin_a * sin_c * cos_b + cos_a * sin_b) * x + (sin_a * cos_c) * y + (sin_a * sin_c * sin_b + cos_a * cos_b) * z

    return x_prime, y_prime, z_prime
end

--|||||||||||||||| left, top, right, bottom |||||||||||||||||||
function EvaDrawRectA1(tex, dest, source, blend, color, x, y, angle)
    angle = angle or 0
    local x0,y0 = EvaRotate2D(dest[1], dest[2], angle)
    local x1,y1 = EvaRotate2D(dest[3], dest[2], angle)
    local x2,y2 = EvaRotate2D(dest[3], dest[4], angle)
    local x3,y3 = EvaRotate2D(dest[1], dest[4], angle)
    RenderTexture(tex, blend,
    {x + x0, y + y0, 0, source[1], source[2], color},
    {x + x1, y + y1, 0, source[3], source[2], color},
    {x + x2, y + y2, 0, source[3], source[4], color},
    {x + x3, y + y3, 0, source[1], source[4], color})
end

function EvaDrawRectA2(tex, dest, source, blend, color, x, y, z, angleX, angleY, angleZ)
    local x0,y0,_ = EvaRotate3D(dest[1], dest[2], 0, angleX, angleY, angleZ)
    local x1,y1,_ = EvaRotate3D(dest[3], dest[2], 0, angleX, angleY, angleZ)
    local x2,y2,_ = EvaRotate3D(dest[3], dest[4], 0, angleX, angleY, angleZ)
    local x3,y3,_ = EvaRotate3D(dest[1], dest[4], 0, angleX, angleY, angleZ)
    RenderTexture(tex, blend,
    {x + x0, y + y0, z, source[1], source[2], color},
    {x + x1, y + y1, z, source[3], source[2], color},
    {x + x2, y + y2, z, source[3], source[4], color},
    {x + x3, y + y3, z, source[1], source[4], color})
end

function EvaDrawRectA3(tex, dest, source, blend, color, x, y, z, angleX, angleY, angleZ)
    local x0,y0,z1  = EvaRotate3D(dest[1], dest[2], 0, angleX, angleY, angleZ)
    local x1,y1,z2  = EvaRotate3D(dest[3], dest[2], 0, angleX, angleY, angleZ)
    local x2,y2,z3  = EvaRotate3D(dest[3], dest[4], 0, angleX, angleY, angleZ)
    local x3,y3,z4  = EvaRotate3D(dest[1], dest[4], 0, angleX, angleY, angleZ)
    RenderTexture(tex, blend,
    {x + x0, y + y0, z + z1, source[1], source[2], color},
    {x + x1, y + y1, z + z2, source[3], source[2], color},
    {x + x2, y + y2, z + z3, source[3], source[4], color},
    {x + x3, y + y3, z + z4, source[1], source[4], color})
end

function EvaRotate3D_B(x, y, z, a, b, c)


    -- 先绕z，再绕x，再绕y，同时将角度从顺时针转为逆时针（取负号）
    -- 由于传入的a,b,c为角度，这里假定 a=X, b=Y, c=Z
    a = -a
    b = -b
    c = -c
    local cos_a, sin_a = cos(a), sin(a)
    local cos_b, sin_b = cos(b), sin(b)
    local cos_c, sin_c = cos(c), sin(c)
    -- 绕z轴
    local xz = cos_c * x - sin_c * y
    local yz = sin_c * x + cos_c * y
    local zz = z
    -- 绕x轴
    local xx = xz
    local yx = cos_a * yz - sin_a * zz
    local zx = sin_a * yz + cos_a * zz
    -- 绕y轴
    local x1 = cos_b * xx + sin_b * zx
    local y1 = yx
    local z1 = -sin_b * xx + cos_b * zx

    return x1, y1, z1
end

function EvaDrawRectA4(tex, dest, source, blend, color, x, y, z, angleX, angleY, angleZ)
    local x0,y0,_ = EvaRotate3D_B(dest[1], dest[2], 0, angleX, angleY, angleZ)
    local x1,y1,_ = EvaRotate3D_B(dest[3], dest[2], 0, angleX, angleY, angleZ)
    local x2,y2,_ = EvaRotate3D_B(dest[3], dest[4], 0, angleX, angleY, angleZ)
    local x3,y3,_ = EvaRotate3D_B(dest[1], dest[4], 0, angleX, angleY, angleZ)
    RenderTexture(tex, blend,
    {x + x0, y + y0, z, source[1], source[2], color},
    {x + x1, y + y1, z, source[3], source[2], color},
    {x + x2, y + y2, z, source[3], source[4], color},
    {x + x3, y + y3, z, source[1], source[4], color})
end


--||||||||||||| Simple Sprite ||||||||||||||
local simp = Class(object)

function simp:init(texture, layer, x, y)
    self.x = x
    self.y = y
    self.z = 0
    self.layer = layer
    self.group = GROUP_GHOST
    self.bound = false
    --|||||||||||||||||||||||||
    self.texture = texture
    self.dest   = {0, 0, 0, 0}
    self.source = {0, 0, 0, 0}
    self.blend  = EVA_BLEND_ALPHA
    self.alpha  = 255
    self.R      = 255
    self.G      = 255
    self.B      = 255
    self.angleX = 0
    self.angleY = 0
    self.angleZ = 0
    self.scaleX = 1
    self.scaleY = 1
    self.scaleZ = 0
end

function simp:frame()
    task.Do(self)
end

function simp:render()
    if(not self.texture)then return end
    local color = Color(self.alpha, self.R, self.G, self.B)
    local x = self.x
    local y = self.y
    local z = self.z
    local angleX = self.angleX
    local angleY = self.angleY
    local angleZ = self.angleZ
    local dest = {
        self.dest[1] * self.scaleX, self.dest[2]* self.scaleY,
        self.dest[3]* self.scaleX, self.dest[4]* self.scaleY}
    local source = self.source
    EvaDrawRectA2(self.texture, dest, source, self.blend, color, x, y, z, angleX, angleY, angleZ)
end

local simp_A = Class(simp)

function simp_A:render()
    if(not self.texture)then return end
    local color = Color(self.alpha, self.R, self.G, self.B)
    local x = self.x
    local y = self.y
    local z = self.z
    local angleX = self.angleX
    local angleY = self.angleY
    local angleZ = self.angleZ
    local dest = {
        self.dest[1] * self.scaleX, self.dest[2]* self.scaleY,
        self.dest[3]* self.scaleX, self.dest[4]* self.scaleY}
    local source = self.source
    EvaDrawRectA4(self.texture, dest, source, self.blend, color, x, y, z, angleX, angleY, angleZ)
end

function EvaSimpleSprite2D(texture, layer, x, y)
    return New(simp, texture, layer, x, y)
end

function EvaSimpleSprite2D_A(texture, layer, x, y)
    return New(simp_A, texture, layer, x, y)
end

function EvaSetDestRect(obj, left, top, right, bottom)
    obj.dest[1] = left
    obj.dest[2] = top
    obj.dest[3] = right
    obj.dest[4] = bottom
end

function EvaSetSourceRect(obj, left, top, right, bottom)
    obj.source[1] = left
    obj.source[2] = top
    obj.source[3] = right
    obj.source[4] = bottom
end

function EvaSetBlendType(obj, blend)
    obj.blend = blend
end

function EvaSetColor(obj, R, G, B)
    obj.R = R
    obj.G = G
    obj.B = B
end

function EvaSetAlpha(obj, alpha)
    obj.alpha = alpha
end

function EvaSetScaleXYZ(obj, X, Y, Z)
    obj.scaleX = X
    obj.scaleY = Y
    obj.scaleZ = Z
end

function EvaSetPosition(obj, x, y, z)
    obj.x = x
    obj.y = y
    obj.z = z
end

function EvaSetAngleXYZ(obj, X, Y, Z)
    obj.angleX = X
    obj.angleY = Y
    obj.angleZ = Z
end

function EvaGetX(obj)
    return IsValid(obj) and obj.x or 9999
end

function EvaGetY(obj)
    return IsValid(obj) and obj.y or 9999
end

function EvaGetRot(obj)
    return IsValid(obj) and obj.rot or 0
end

local dummyObj = Class(object)

function dummyObj:init()
    self.group = GROUP_GHOST
    self.layer = LAYER_TOP
    self.bound = false
end

function dummyObj:frame()
    task.Do(self)
end

function EvaDummyObjectForTask()
    return New(dummyObj)
end

--||||||||||| Primitive Object ||||||||||||||||


local prim = Class(object)

function prim:init(texture, layer, vertex_count)
    self.texture = texture
    self.group = GROUP_GHOST
    self.bound = false
    self.layer = layer
    self.blend = EVA_BLEND_ALPHA
    self.vertex_count = vertex_count
    self.index_count = (vertex_count - 2)*3
    self.meshData = MeshData(self.vertex_count, self.index_count)
    self.angleX = 0
    self.angleY = 0
    self.angleZ = 0

    self.vertex = {}
    self.alpha = 255
    for i = 1, self.vertex_count do
        self.vertex[i] = {0, 0, 0}
    end
    --Triangle Fan (中心的顶点是0)
    for i = 1, self.vertex_count - 2 do
        local bi = (i - 1)*3
        self.meshData:setIndex(bi    ,         0)
        self.meshData:setIndex(bi + 1,         i)
        self.meshData:setIndex(bi + 2,         i+1)
    end

    self.meshData:setAllVertexColor(Color(255, 255, 255, 255))
end

function prim:frame()
    task.Do(self)
    self.meshData:setAllVertexColor(Color(self.alpha, 255, 255, 255))
    for i = 1, self.vertex_count do
        local vertex = self.vertex[i]
        local x, y, z = EvaRotate3D(
        vertex[1], vertex[2], vertex[3],
        self.angleX, self.angleY, self.angleZ)
        self.meshData:setVertexPosition(i - 1, self.x + x, self.y + y, self.z + z )
    end
end

function prim:render()
    SetViewMode("world")
    RenderMesh(self.texture, self.blend, self.meshData)
end

function EvaSimplePrimObject_TriangleFan(texture, layer, vertex_count)
    return New(prim, texture, layer, vertex_count)
end

function EvaSetVertexPosition(obj, vertex, x, y, z)
    obj.vertex[vertex + 1] = {x, y, z}
end

function EvaSetUVT(obj, vertex, u, v)
    obj.meshData:setVertexCoords(vertex, u, v)
end


--|||||||||||||||| 移动相关 ||||||||||||||||||

function EvaSetMovePositionBraking01(obj, fin_x, fin_y, time)
    local x = EvaGetX(obj)
	local y = EvaGetY(obj)
	local dx = fin_x - x
	local dy = fin_y - y
    task.New(obj, function()
        for t = 1 , time do
            local rate = sin(90 * t / time)
            EvaSetPosition(obj, x + dx * rate, y + dy * rate, 0)
            task.Wait()
        end
        EvaSetPosition(obj, fin_x, fin_y, 0)
    end)
end

function EvaObjMove_SetAcceleration(obj, a)
    obj.accel = a
end

function EvaObjMove_SetMaxSpeed(obj, ms)
    if(obj.accel>0)then
        obj.max_speed = ms
    else
        obj.min_speed = ms
    end
end

function EvaObjMove_SetSpeed(obj, s)
    obj.speed = s
end

function EvaObjMove_SetAngle(obj, a)
    obj.angle = a
end

function EvaObjMove_SetPosition(obj, x, y)
    obj.x = x
    obj.y = y
end

function EvaObjMove_GetSpeed(obj)
    return obj.speed
end

--|||||||||||||||| 杂鱼相关 ||||||||||||||||||||

function EvaChangeVanishEffectColor(obj, Vcolor)
    obj["VANISH_EFFECT_COLOR"] = Vcolor
end


--|||||||||||||||| 数组 |||||||||||||||||||||||
function EvaArray(...)
    return {...}
end

function CopyArray(tar)
    local res = {}
    for i = 1, #tar do
        res[i] = tar[i]
    end
    return res
end

---|||||||||||| 数学 |||||||||||||||||||

function EvaGetCenterX()
    return 0
end

function EvaGetCenterY()
    return 0
end

function EvaGetClipWidth()
    return 384
end

function EvaGetClipHeight()
    return 448
end

function EvaGetClipMinX()
	return -192
end

function EvaGetClipMaxX()
	return 192
end

function EvaGetClipMinY()
	return 224
end

function EvaGetClipMaxY()
	return -224
end

function EvaIsOut(x, y, d)
	return(EvaIsOutXLine(x, d) or EvaIsOutYLine(y, d))
end

function EvaIsOutXLine(x, d)
	return ( abs(EvaGetCenterX() - x) > (EvaGetClipWidth()/2 + d) )
end

function EvaIsOutYLine(y, d)
	return ( abs(EvaGetCenterY() - y) > (EvaGetClipHeight()/2 + d) )
end

function EvaIsOutScreen(x, y, d)
	return(EvaIsOutXScreenLine(x, d) or EvaIsOutYScreenLine(y, d))
end

function EvaIsOutXScreenLine(x, d)
	return ( abs(EvaGetCenterX() - x) > (320 + d) )
end

function EvaIsOutYScreenLine(y, d)
	return ( abs(EvaGetCenterY() - y) > (240 + d) )
end

function EvaGetScreenLineStates(x, y, d, ang)
	if(EvaIsOutScreen(x, y, d))then return {x, y, 0} end
	local maxX = 320+d
	local minX = -320-d
	local maxY = 240+d
	local minY = -240-d
	local dx = {minX-x, maxX-x}
	local dy = {minY-y, maxY-y}
	local da = {
		atan2(dy[2], dx[2])%360,
		atan2(dy[2], dx[1])%360,
		atan2(dy[1], dx[1])%360,
		atan2(dy[1], dx[2])%360
    }
	ang = ang % 360
	local l = 0
	if(ang <= da[1])then
		l = dx[2]/cos(ang)
		return {maxX, y+l*sin(ang), l}
	elseif(ang <= da[2]) then
		l = dy[2]/sin(ang)
		return {x+l*cos(ang), maxY, l}
	elseif(ang <= da[3]) then
		l = dx[1]/cos(ang)
		return {minX, y+l*sin(ang), l}
	elseif(ang <= da[4]) then
		l = dy[1]/sin(ang)
		return {x+l*cos(ang), minY, l}
	else
		l = dx[2]/cos(ang)
		return {maxX, y+l*sin(ang), l}
    end
end

function EvaGetScreenLinePosition(x, y, d, ang)
	local pos = EvaGetScreenLineStates(x, y, d, ang)
	return {pos[1], pos[2]}
end

function EvaGetScreenLineLength(x, y, d, ang)
	local pos = EvaGetScreenLineStates(x, y, d, ang)
	return pos[3]
end

function EvaDrawFrame()
    local obj = EvaSimpleSprite2D("eva_frame", LAYER_TOP, 0, 0)
    EvaSetDestRect(obj, -320, 240, 320, -240)
    EvaSetSourceRect(obj, 0, 0, 640, 480)
    EvaSetAlpha(obj, 159)
    EvaSetBlendType(obj, EVA_BLEND_ALPHA)
    return obj
end

function EvaClampPlayer()
    local obj = EvaDummyObjectForTask()
    task.New(obj, function ()
        local p = lstg.player
        local b = 8
        while true do
            if (p.x > 192 - b) then p.x = 192 - b end
            if (p.x < -192 + b) then p.x = -192 + b end
            if (p.y < -224 + b) then p.y = -224 + b end
            if (p.x > 224 - b) then p.y = 224 - b end
            task.Wait()
        end
    end)
end