local wait = task.Wait

function EvaObjStLaser_GetEndX(objL)
	return EvaGetX(objL) + objL.length *cos(objL.angle)
end

function EvaObjStLaser_GetEndY(objL)
	return EvaGetY(objL) + objL.length *sin(objL.angle)
end

function EvaObjLaser_GetEndX(objL)
	return EvaGetX(objL) + objL.length *cos(objL.angle)
end

function EvaObjLaser_GetEndY(objL)
	return EvaGetY(objL) + objL.length *sin(objL.angle)
end

function EvaCreateUserLooseLaserA1(x, y, spd, ang, lLeng, lWid, color, graph)
	return EvaCreateUserLooseLaserA2_Ex(x, y, spd, ang, 0, spd, lLeng, lWid, color, 0, graph)
end
function EvaCreateUserLooseLaserA1_Ex(x, y, spd, ang, lLeng, lWid, color, delay, graph)
	return EvaCreateUserLooseLaserA2_Ex(x, y, spd, ang, 0, spd, lLeng, lWid, color, delay, graph)
end
function EvaCreateUserLooseLaserA2(x, y, spd, ang, acce, mSpd, lLeng, lWid, color, graph)
	return EvaCreateUserLooseLaserA2_Ex(x, y, spd, ang, acce, mSpd, lLeng, lWid, color, 0, graph)
end
local TLaser1
local TLaser2
function EvaCreateUserLooseLaserA2_Ex(x, y, spd, ang, acce, mSpd, lLeng, lWid, color, delay, graph)
    graph = graph or ADD_BGW_LIGHT_L_RED
    local objS = EvaCreateShotA2(x, y, spd, ang, acce, mSpd, ADD_BGW_LIGHT_L_RED + (color%8), 0)
    local oldX = x
    local oldY = y
    local outFlag = false
    objS.hide_user = true
    objS.colli_user = false
    function TLaser1(objS, delay)
        function TLaser2(x_, y_, ang_, lLeng_, lWid_, grap, time, delay_)
            local objL = EvaCreateStraightLaserA1(x_, y_, ang_, lLeng_, lWid_, time, grap, delay_)
            objL.ratioY = 0.5
            EvaTask(function ()
                wait(delay_)
                local alpha = 0
                for t = time, time - 5, -1 do
                    if(not IsValid(objS) and not EvaIsOutScreen(EvaGetX(objS), EvaGetY(objS), 32))then
                        EvaStLaserToItem(objL)
                        return
                    end
                    local rate = t/time
                    local rate2 = (time - t)/6
                    EvaSetLaserLength(objL, lLeng_ * rate)
                    EvaSetLaserWidth(objL, lWid_ * rate)
                    objL.ratioX = 0.4
                    alpha = 191 * rate2
                    EvaSetAlpha(objL, alpha)
                    wait()
                end
                objL.colli = true
                alpha = 191
                EvaSetAlpha(objL, alpha)
                for t = time - 6, int(time/3) + 1, -1 do
                    if(not IsValid(objS) and not EvaIsOutScreen(EvaGetX(objS), EvaGetY(objS), 32))then
                        EvaStLaserToItem(objL)
                        return
                    end
                    local rate = t/time
                    EvaSetLaserLength(objL, lLeng_ * rate)
                    EvaSetLaserWidth(objL, lWid_*rate)
                    objL.ratioX = 0.4
                    wait()
                end
                objL.colli = false
                for t = int(time/3), 1, -1 do
                    if(not IsValid(objS) and not EvaIsOutScreen(EvaGetX(objS), EvaGetY(objS), 32))then
                        EvaStLaserToItem(objL)
                        return
                    end
                    local rate = t/time
                    local rate2 = t/(time/3)
                    EvaSetLaserLength(objL, lLeng_ * rate)
                    EvaSetLaserWidth(objL, lWid_*rate)
                    objL.ratioX = 0.4
                    alpha = 191 * rate2
                    EvaSetAlpha(objL, alpha)
                    wait()
                end
                Del(objL)
            end)
        end
        EvaTask(function ()
            while IsValid(objS) do
                outFlag = EvaIsOut(EvaGetX(objS), EvaGetY(objS), 32)
                local dx = EvaGetX(objS) - oldX
                local dy = EvaGetY(objS) - oldY
                local dl = hypot(dx, dy)
                local da = atan2(dy, dx)
                if(EvaObjMove_GetSpeed(objS) > 0)then
                    TLaser2(EvaGetX(objS) + 3*dl*cos(da), EvaGetY(objS) + 3*dl*sin(da), da+180, 9*dl, lWid, graph + (color%8), lLeng, delay)
                end
                oldX = EvaGetX(objS)
                oldY = EvaGetY(objS)
                wait()
            end
        end)
    end
    TLaser1(objS, delay)
    return objS
end

