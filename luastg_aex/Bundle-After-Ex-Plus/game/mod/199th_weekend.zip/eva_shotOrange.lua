local sin, cos = sin, cos
local atan2 = atan2
local wait = EvaWait

local EvaTask = EvaTask
local EvaCreateUserShotA2 = EvaCreateUserShotA2
local EvaCreateStraightLaserA1 = EvaCreateStraightLaserA1
local EvaSetLaserLength = EvaSetLaserLength
local EvaSetLaserWidth  = EvaSetLaserWidth
local EvaSetPosition    = EvaSetPosition
local EvaSetAlpha       = EvaSetAlpha
local EvaSetColor       = EvaSetColor
local IsValid           = IsValid
local Del               = Del
local Kill              = Kill
local Angle             = Angle
local EvaChangeShotAngle = EvaChangeShotAngle
local ran_Float         = function(a, b) return ran:Float(a, b) end
local ran_Sign          = function() return ran:Sign() end
local ran_Int           = function(a, b) return ran:Int(a, b) end


EvaShotOrangeA = {}
EvaShotOrange_Count = 0
EvaShotOrangeA_Chosen = 0
EvaShotOrangeA_Add = 0
EvaShotOrangeA_Reset = {
    EVA_SP1_SHOT_ORANGE_01,
    EVA_SP1_SHOT_ORANGE_02,
    EVA_SP1_SHOT_ORANGE_03,
    EVA_SP1_SHOT_ORANGE_04
}

function EvaResetShotOrangeArray()
    EvaShotOrangeA = CopyArray(EvaShotOrangeA_Reset)
end

function EvaGetShotOrangeArrayLength()
    return #EvaShotOrangeA
end

function EvaEraseShotOrangeArray(num)
    table.remove(EvaShotOrangeA, num)
end

function EvaEraseShotOrangeArray2(num)
    for iQ = 1, EvaGetShotOrangeArrayLength() do
        if EvaShotOrangeA[iQ] == num then
            table.remove(EvaShotOrangeA, iQ)
            break
        end
    end
end

function EvaAddShotOrangeArray(num)
    table.insert(EvaShotOrangeA, num)
end

function EvaTShotOrange(objE, currentPhase, wt)
    task.New(objE, function()
        task.Wait(wt)
        if(not EvaIsCurrentPhase(currentPhase)) then return end
        local color = EVA_COLOR_ORANGE
        local num = ran:Int(1, EvaGetShotOrangeArrayLength())
        EvaShotOrangeA_Chosen = EvaShotOrangeA[num]
        EvaTShotColorNum(EvaShotOrangeA[num], objE, currentPhase, color)
        EvaEraseShotOrangeArray(num)
        EvaShotOrange_Count = EvaShotOrange_Count + 1
    end)
end

--||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||

local EvaTShotOrangeType1_Shot

function EvaTShotOrangeType1(objE, currentPhase, color)
    local angA = {}
    local rSpd = 1.5
    local aSpd = 0.3
    local way = EvaArray(3, 4, 5, 6, 7)[currentPhase]
    local qnt = EvaArray(24, 30, 30, 40, 40)[currentPhase]
    local wt = EvaArray(5, 4, 4, 4, 3)[currentPhase]
    local sMax = EvaArray(3.6, 3.6, 4.2, 4.8, 6.0)[currentPhase]
    local sMin = EvaArray(1.2, 1.2, 1.8, 2.4, 3.6)[currentPhase]
    local r2 = 0
    local r = 10
    local D = ran_Sign()

    local aaa = 0
	for _ = 0, 180 do
		aaa = aaa + aSpd*540/(r2+270)*D
		table.insert(angA, aaa)
		r2 = r2 + rSpd
	end
	local ang = ran_Float(0, 360)
    EvaTask(function()
        for iQ = 0, qnt - 1 do
            if(not IsValid(objE)) then return end
            EvaCallSE(EVA_SE_SHOT7)
            local rr = ran_Float(0, 12)
            local aa = ran_Float(0, 360)
            local s = sMax-sMin*iQ/qnt
            local mSpd = 0.75
            local acce = (mSpd-s)/60.0
            local a = ang - 360*iQ/qnt*D
            for iW = 0, way - 1 do
                local a2 = a + 360*iW/way
                EvaTShotOrangeType1_Shot(EvaGetX(objE)+r*cos(a2)+rr*cos(aa), EvaGetY(objE)+r*sin(a2)+rr*sin(aa), s, angA, a2 + ran_Float(-60/way, 60/way), acce, mSpd, color, 10)
            end
            wait(wt)
        end
    end)
end

function EvaTShotOrangeType1_Shot(x, y, spd, angA, ang, acce, mSpd, color)
    local objS = EvaCreateUserShotA2(x, y, spd, ang, acce, mSpd, BGB_BALL_S_RED + color, 10)
    EvaTask(function()
		for t = 1, #angA do
			EvaChangeShotAngle(objS, ang+angA[t])
			wait(1)
		end
    end)
end

--||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||

local EvaTShotOrangeType2_TLaser
local EvaTShotOrangeType2_Shot
local EvaTShotOrangeType2_Shot_Shot
local EvaTShotOrangeType2_Laser

function EvaTShotOrangeType2(objE, currentPhase, color)
    local way = EvaArray(1, 3, 5, 7, 9)[currentPhase]
	local arc = EvaArray(0, 60, 36, 30, 24)[currentPhase]
	local arc2 = EvaArray(20, 20, 20, 20, 20)[currentPhase]
	local ang = Angle(objE, lstg.player)
	local wt = EvaArray(5, 5, 4, 3, 2)[currentPhase]
	local bWay = 36
	local bWay2 = EvaArray(6, 5, 5, 4, 4)[currentPhase]
	local bSpd = 1.25
	local bTime = 75
	local D = ran_Sign()

    EvaTask(function()
        for iW = 0, way - 1 do
            if(not IsValid(objE)) then return end
            EvaTShotOrangeType2_TLaser(objE, EvaGetX(objE), EvaGetY(objE), ang + arc*(iW-(way-1)/2)*D, arc2, bWay, bWay2, bSpd, bTime, color)
            wait(wt)
        end
    end)
end

function EvaTShotOrangeType2_TLaser(objE, x, y, ang, arc, bWay, bWay2, bSpd, time2, color)
    EvaTask(function()
        EvaCallSE(EVA_SE_SHOT4)
		while(not EvaIsOutScreen(x, y, 12)) do
			local leng = ran_Int(7, 10)*15
			local time = int(leng/15)
			EvaTShotOrangeType2_Laser(x, y, ang, leng, time, time2, color)
			x = x + leng *cos(ang)
			y = y + leng *sin(ang)
			wait(time)
			EvaTShotOrangeType2_Shot(objE, x, y, ran_Float(0, 360), time2, bWay, bWay2, bSpd, color)
			ang = ang + ran_Float(-arc, arc)
		end
    end)
end

local EvaTShotOrangeType2_Shot_SharedVars = {
    flag = false
}

function EvaTShotOrangeType2_Shot(objE, x, y, ang, time, bWay, bWay2, bSpd, color)
    local objS = EvaCreateShotA1(x, y, 0, ang, BGW_BALL_S_RED + color, 0)
	objS.colli_user = false
    objS.isBreakEffect = false
	EvaSetAlpha(objS, 191)
	EvaObjRender_SetColor_ColorNum(objS, color)
    EvaTask(function()
        for t = time, 1, - 1 do
            local rate = t/time
			EvaSetColor(objS, 255, 95*rate+32, 31*rate+32)
			wait(1)
        end
        if(not IsValid(objS)) then return end
		EvaCallSE(EVA_SE_FIRE1)
		local num = {}
		for iW2 = 0, bWay2 - 1 do
			EvaTShotOrangeType2_Shot_SharedVars.flag = false
			local n
			while(not EvaTShotOrangeType2_Shot_SharedVars.flag) do
				n = ran_Int(0, bWay)
				EvaTShotOrangeType2_Shot_SharedVars.flag = true
				for iQ = 1, #num do
					if(n == num[iQ]) then
						EvaTShotOrangeType2_Shot_SharedVars.flag = false
						break
					end
				end
			end
			local c = 1
			for iQ = 1, #num do
				if(n > num[iQ]) then c = c + 1
				else break end
			end
			table.insert(num, c, n)
		end
        table.insert(num, 99999)
        local c = 1
		for iW = 0, bWay - 1 do
			EvaTShotOrangeType2_Shot_SharedVars.flag = (iW == num[c])
			if(EvaTShotOrangeType2_Shot_SharedVars.flag) then c = c + 1 end
			EvaTShotOrangeType2_Shot_Shot(objE, x, y, bSpd+ran_Float(-0.075, 0.075), ang+360*iW/bWay, color)
		end
		Del(objS)
    end)
end

function EvaTShotOrangeType2_Shot_Shot(objE,x, y, spd, ang, color)
    local objS = EvaCreateUserShotA2(x, y, spd, ang, -spd/60, 0, ADD_BGW_BALL_S_RED + color, 5)
    objS.isBreakEffect = false
    local flag = EvaTShotOrangeType2_Shot_SharedVars.flag
    EvaTask(function()
        for _ = 1, 60 do
            if(not IsValid(objE)) then Del(objS) return end
            wait(1)
        end
        if(flag and IsValid(objS)) then
            for iQ = 0, 3 do
                local s = 0.9*ran_Float(0.975, 1.025)
                EvaCreateUserShotA2(EvaGetX(objS), EvaGetY(objS), 0, ang+ran_Float(-1.5, 1.5), s/100, s, BGW_BALL_S_RED + color, 5)
            end
            Del(objS)
        else
            objS.colli_user = false
            objS.colli = false
            for t = 9, 1, -1 do
                EvaSetAlpha(objS, 255*t/10)
                wait(1)
            end
            Del(objS)
        end
    end)
end

local EvaTShotOrangeType2_Laser_LengManager
local EvaTShotOrangeType2_Laser_Efc
local EvaTShotOrangeType2_Laser_Efc2

function EvaTShotOrangeType2_Laser(x, y, ang, leng, time, time2, color)
    local objL = EvaCreateStraightLaserA1(x, y, ang, 0, 80, 0, ADD_BGW_BEAM_ST_RED + color, 999)
    EvaObjRender_SetColor_ColorNum(objL, color)
    EvaTShotOrangeType2_Laser_LengManager(objL, x, y, time, ang, leng, color)
    EvaTask(function()
        for t = 1, time2 do
			local alpha = 63+192*t/time2
			EvaSetAlpha(objL, alpha)
			wait(1)
		end
    end)
end

function EvaTShotOrangeType2_Laser_LengManager(objL, x, y, time, ang, leng, color)
    EvaTShotOrangeType2_Laser_Efc(x, y, time, color, ang, leng)
    EvaTask(function ()
        for t = 1, time do
            EvaSetLaserLength(objL, leng*t/time)
            wait(1)
        end
        wait(75-time)
        EvaTShotOrangeType2_Laser_Efc(x, y, time, color, ang, leng)
        for t = time - 1, 1, -1 do
            --local l = leng*(1 - t/time)
            objL.beginX = objL.beginX + leng/time*cos(ang)
            objL.beginY = objL.beginY + leng/time*sin(ang)
            EvaSetLaserLength(objL, leng*t/time)
            wait(1)
        end
        Del(objL)
    end)
end

function EvaTShotOrangeType2_Laser_Efc(x, y, time, color, ang, leng)
    EvaTask(function ()
        for i = 0, time - 1 do
            if not IsValid(_boss) then
                return
            end
            for j = 0, 3 do
                local bx = x + leng*((i+j/4)/time)*cos(ang)
                local by = y + leng*((i+j/4)/time)*sin(ang)
                EvaTShotOrangeType2_Laser_Efc2(bx, by, ang, 30, color)
            end
            wait(1)
        end
    end)
end

function EvaTShotOrangeType2_Laser_Efc2(x, y, ang, time, color)
    local objS = EvaCreateShotA1(x, y, 0, ang, ADD_BGW_BALL_M_RED + color, 0)
    EvaObjRender_SetColor_ColorNum(objS, color)
    objS.isBreakEffect = false
    objS.colli_user = false
    objS.colli = false
    EvaTask(function ()
        for t = time, 1, -1 do
            local rate = t/time
            EvaSetAlpha(objS, 95*rate)
            EvaSetScaleXYZ(objS, rate, rate, rate)
            wait(1)
        end
        Del(objS)
    end)
end



--||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||

local EvaTShotOrangeType3_LaserAI
local EvaTShotOrangeType3_TGeyser
local EvaTShotOrangeType3_TGeyser_Laser

function EvaTShotOrangeType3(objE, currentPhase, color)
    EvaCallSE(EVA_SE_WAVE)
	local time = 75
    local phaseMax = _boss.CommonValue.phaseMax
	local x = (currentPhase==phaseMax) and ran:Int(EvaGetClipMinX()+60, EvaGetClipMaxX()-60) or EvaGetX(objE)
	local dist = EvaArray(3.0, 3.4, 3.8, 4.2, 4.5)[currentPhase]
    EvaEffect_LaserWarning2(x, EvaGetClipMaxY()-32, 90, dist*40, 600, 30, 127, color)
    EvaTask(function ()
        for t = time, 1, -1 do
            if(not IsValid(objE)) then return end
            local a = ran:Float(0, 360)
            local r = dist*20*t/time
            for iQ = 0, 2 do
                EvaTShotOrangeType3_LaserAI(x + r*cos(a+120*iQ) * ran_Float(0.85, 1.15), EvaGetClipMaxY()-32, 90, 600, 6, 15, 95+96*(1-t/time), color)
            end
            wait(1)
        end
        wait(15)
        if(not IsValid(objE)) then return end
        EvaShakeSTGFrame(3, 20)
        EvaCallSE(EVA_SE_SHOT4)
        EvaCallSE(EVA_SE_FIRE1)
        EvaTShotOrangeType3_TGeyser(objE, x, EvaGetClipMaxY(), 90, dist, color)

    end)
end

function EvaTShotOrangeType3_TGeyser(objE, x, y, ang, dist, color)
    local l = 1800
    local w = 20
    local time = 5
    local time2 = 40
    local c = 0
    EvaTShotOrangeType3_TGeyser_Laser(x, y, ang, l, w, time, time2, color)
    EvaTask(function()
        while true do
            if(not IsValid(objE)) then return end
            l = l * 0.85
            if(l < 20) then return end
            c = c + 1
            local dx = dist*c * cos(ang+90)
            local dy = dist*c * sin(ang+90)
            EvaTShotOrangeType3_TGeyser_Laser(x + dx, y + dy, ang, l, w, time, time2, color)
            EvaTShotOrangeType3_TGeyser_Laser(x - dx, y - dy, ang, l, w, time, time2, color)
            wait(1)
        end
    end)
end

function EvaTShotOrangeType3_TGeyser_Laser(x, y, a, l, w, time, time2, color)
    local objL = EvaCreateStraightLaserA1(x, y, a, 0, w, 99999, ADD_BGW_LIGHT_L_RED + color, 0);
    EvaObjRender_SetColor_ColorNum(objL, color)
    EvaObjShot_SetAutoDelete(objL, false)
    objL.ratioY = 0.8
    EvaTask(function()
        for t = 1, time do
            local leng = l * sin(90*t/time)
            EvaSetLaserLength(objL, leng)
            wait(1)
        end
        for t = time2 - 1, 1, -1 do
            local leng = l * sin(90*t/time2)
            EvaSetLaserLength(objL, leng)
            wait(1)
        end
        Del(objL)
    end)
end

function EvaTShotOrangeType3_LaserAI(x, y, a, l, w, time, alpha, color)
    local objLE = EvaCreateStraightLaserA1(x, y, a, l, w, 99999, ADD_BGW_BEAM_ST_RED + color, 0, true)
    EvaObjRender_SetColor_ColorNum(objLE, color)
    EvaObjShot_SetAutoDelete(objLE, false)
    EvaTask(function()
        for t = 1, time do
            EvaSetAlpha(objLE, alpha*t/time)
            wait(1)
        end
        Del(objLE)
    end)
end

--||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||

local EvaTShotOrangeType4_TShot
local EvaTShotOrangeType4_TShot_RhombusShot

function EvaTShotOrangeType4(objE, currentPhase, color)
    local leng = EvaArray(60, 60, 66, 72, 80)[currentPhase]
    local wt = EvaArray(10, 8, 10, 10, 12)[currentPhase]
    local qnt = EvaArray(1, 2, 3, 4, 5)[currentPhase]
    local wt2 = EvaArray(40, 40, 30, 24, 20)[currentPhase]

    EvaCallSE(EVA_SE_FIRE1)

    EvaTask(function ()
        for iQ = 0, qnt - 1 do
            EvaShakeSTGFrame(2, 10)
            for iW = 0, 1 do
                local leng2 = leng*(0.5*((iQ+1)%2))
                local ang2 = 180*iW
                EvaTShotOrangeType4_TShot(objE, EvaGetX(objE)+leng2*cos(ang2), EvaGetClipMinY()+leng2*sin(ang2), 270, 24, ang2, leng, wt, color)
            end
            wait(wt2)
        end
    end)
end

function EvaTShotOrangeType4_TShot(objE, x, y, ang, arc, ang2, leng, wt, color)
    EvaTask(function()
        while(not EvaIsOutScreen(x, y, 32) and IsValid(objE)) do
			local spd = ran_Float(1.01, 2.4)
			local distW = ran_Float(3.0, 3.6)
			local qnt = 3+int((2.4-spd)/0.7)
			EvaCallSE(EVA_SE_SHOT5)
			EvaTShotOrangeType4_TShot_RhombusShot(qnt, distW*2, distW, x, y, spd, ang + ran_Float(-arc/2, arc/2), BGB_ICE_RED + color, 5)
			wait(wt)
			x = x + leng*cos(ang2)
			y = y + leng*sin(ang2)
		end
    end)
end

function EvaTShotOrangeType4_TShot_RhombusShot(qnt, distH, distW, x, y, spd, ang, grap, delay)
    local wayArray = {}
    for i = 1, qnt*2 - 1 do
        if(i>qnt)then
            wayArray[i] = qnt*2 - i
        else
            wayArray[i] = i
        end
    end
    local iWHMinus = (#wayArray-1)/2
    local bx = x
    x = 0
    local by = y
    y = 0
    local count = 0
    EvaTask(function()
        for i = 1, #wayArray do
            local way = wayArray[i]
            x = -count*cos(ang)
            y = -count*sin(ang)
            count = count + distH
            if(way ~= 1) then
                local rx = (i-iWHMinus)*distH
                local ry = (way-1)*distW
                --local a = atan2(ry, rx)
                --local r = sqrt(ry^2 + rx^2)
                EvaCreateUserShotA2(bx+x+ry*cos(ang+90), by+y+ry*sin(ang+90),  0, ang, spd/50, spd, grap, delay)
                EvaCreateUserShotA2(bx+x+ry*cos(ang-90), by+y+ry*sin(ang-90),  0, ang, spd/50, spd, grap, delay)
            else
                EvaCreateUserShotA2(bx+x, by+y,  0, ang, spd/50, spd, grap, delay)
            end
            while(count >= 0) do
                if(not IsValid(_boss)) then return end
                count = count - spd
                wait(1)
            end
        end
    end)
end

