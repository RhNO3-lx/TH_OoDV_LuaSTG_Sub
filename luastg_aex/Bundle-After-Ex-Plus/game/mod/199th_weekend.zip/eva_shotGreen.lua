local sin, cos = sin, cos
local atan2 = atan2
local wait = EvaWait

local EvaTask = EvaTask
local EvaCreateUserShotA2 = EvaCreateUserShotA2
local EvaCreateStraightLaserA1 = EvaCreateStraightLaserA1
local EvaSetLaserLength = EvaSetLaserLength
local EvaSetLaserWidth  = EvaSetLaserWidth
local EvaSetPosition    = EvaSetPosition
local EvaSetAlpha       = EvaSetAlpha
local EvaSetColor       = EvaSetColor
local IsValid           = IsValid
local Del               = Del
local Kill              = Kill
local Angle             = Angle
local EvaChangeShotAngle = EvaChangeShotAngle
local ran_Float         = function(a, b) return ran:Float(a, b) end
local ran_Sign          = function() return ran:Sign() end

EvaShotGreenA = {}
EvaShotGreen_Count = 0
EvaShotGreenA_Chosen = 0
EvaShotGreenA_Add = 0
EvaShotGreenA_Reset = {
    EVA_SP1_SHOT_GREEN_01,
    EVA_SP1_SHOT_GREEN_02,
    EVA_SP1_SHOT_GREEN_03,
    EVA_SP1_SHOT_GREEN_04
}

function EvaResetShotGreenArray()
    EvaShotGreenA = CopyArray(EvaShotGreenA_Reset)
end

function EvaGetShotGreenArrayLength()
    return #EvaShotGreenA
end

function EvaEraseShotGreenArray(num)
    table.remove(EvaShotGreenA, num)
end

function EvaEraseShotGreenArray2(num)
    for iQ = 1, EvaGetShotGreenArrayLength() do
        if EvaShotGreenA[iQ] == num then
            table.remove(EvaShotGreenA, iQ)
            break
        end
    end
end

function EvaAddShotGreenArray(num)
    table.insert(EvaShotGreenA, num)
end

function EvaTShotGreen(objE, currentPhase, wt)
    task.New(objE, function()
        task.Wait(wt)
        if(not EvaIsCurrentPhase(currentPhase)) then return end
        local color = EVA_COLOR_GREEN
        local num = ran:Int(1, EvaGetShotGreenArrayLength())
        EvaShotGreenA_Chosen = EvaShotGreenA[num]
        EvaTShotColorNum(EvaShotGreenA[num], objE, currentPhase, color)
        EvaEraseShotGreenArray(num)
        EvaShotGreen_Count = EvaShotGreen_Count + 1
    end)
end

-- |||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||

local EvaTShotGreenType1_TShot
local EvaTShotGreenType1_LaserEffect
local EvaTShotGreenType1_LineEffect_ADD
local EvaTShotGreenType1_LineEffect

function EvaTShotGreenType1(objE, currentPhase, color)
    local ang = Angle(objE, lstg.player)
	local lPos = EvaGetScreenLinePosition(EvaGetX(objE), EvaGetY(objE), 31, ang+180)
	local lLeng = EvaGetScreenLineLength(lPos[1], lPos[2], 32, ang)

	local wid = EvaArray(80, 95, 110, 125, 140)[currentPhase]
	local delay = 90

    EvaTShotGreenType1_TShot(objE, lPos[1], lPos[2], ang, lLeng, wid, delay, color)
end

--Green Dragon
function EvaTShotGreenType1_TShot(objE,x, y, ang, leng, wid, delay, color)
    EvaCallSE(EVA_SE_LASER1)
    EvaCallSE(EVA_SE_WAVE)

    local spd = 40
    local objL = EvaCreateLooseLaserA1(x, y, spd, ang, spd*90, 3, ADD_BGW_BALL_M_RED + color, 0)
    objL.colli = false
    EvaTask(function()
        for iQ = 0, 2 do
            if(not IsValid(objE)) then return end
            EvaEffect_LaserWarning3(x, y, ang, wid, 800, 60-15*iQ, 15, 127, color)
            wait(delay/3)
        end
        if(not IsValid(objE)) then return end
        EvaCallSE(EVA_SE_SHOT5)
        EvaCallSE(EVA_SE_FIRE1)
        for _ = 0, 15 do
			local lAng = ran_Float(0, 360)
			EvaTShotGreenType1_LaserEffect(ang, x, y, 45, lAng, ran_Float(18,33), leng, wid-10, color, 127)
			EvaTShotGreenType1_LaserEffect(ang, x, y, 45, lAng, ran_Float(18,33), leng, wid-10, color, 127)
			wait(1)
		end
    end)
end

function EvaTShotGreenType1_LaserEffect(ang, bx, by, lSpd, lAng, lASpd, leng, wid, color, alp)
    --print("I WAS REACHED")
    local l = 0
    local qnt = 2
    local pos = {EvaRotate2D(0, 0.1*wid*sin(lAng), ang)}
    local oldX = bx+pos[1]
    local oldY = by+pos[2]
    local c = 0

    EvaTask(function()
        local CS = cos(ang)
        local SN = sin(ang)
        --print("TASK HERE")
        while(l < leng)do
            --print("l < leng failed")
            if(not IsValid(_boss)) then return end
            for _ = 0, qnt - 1 do
                c = c + 1
                local lS = lSpd/qnt
                l = l + lS
                lAng = lAng + lASpd/qnt
                bx = bx + lS*CS
                by = by + lS*SN
                local lr = wid/2
                pos = {EvaRotate2D(0, lr*sin(lAng), ang)}
                local xx = bx+pos[1]
                local yy = by+pos[2]
                local ll = Dist(xx, yy, oldX, oldY)
                local la = atan2(yy-oldY, xx-oldX)
                EvaTShotGreenType1_LineEffect_ADD(xx+ll*cos(la), yy+ll*sin(la), ll*5, la+180, 20, color, alp, 20)
                oldX = xx
                oldY = yy
            end
            wait(1)
        end
    end)
end

function EvaTShotGreenType1_LineEffect_ADD(x, y, l, a, lWidth, color, alp, time)
    EvaTShotGreenType1_LineEffect(x, y, l, a, lWidth, color, alp, time, EVA_BLEND_ADD_ARGB)
end

function EvaTShotGreenType1_LineEffect(x, y, l, a, lWidth, color, alp, time, type)
    local objL = EvaCreateStraightLaserA1(x, y, a, l, lWidth, 999999, ADD_BGW_BALL_M_RED+color, 0)
    objL.ratioY = 0.5
    EvaSetBlendType(objL, type)
    EvaObjRender_SetColor_ColorNum(objL, color)
    EvaSetAlpha(objL, alp)
    EvaTask(function()
        wait(time-10)
        objL.colli = false
        for t = 9, 1, -1 do
            EvaSetAlpha(objL, alp*t/10)
            wait()
        end
        Del(objL)
    end)
end

-- |||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||

local EvaTShotGreenType2_TShotB

function EvaTShotGreenType2(objE, currentPhase, color)
    local way = EvaArray(4, 4, 5, 6, 7)[currentPhase]
	local arc = EvaArray(15, 21, 28, 36, 45, 55, 66)
	local ang = Angle(_boss, lstg.player)+180
	local wt = 5
	local rate = 3.3
	local spd = 40
	local spd2 = 10
	local bWayIni = EvaArray(3, 3, 3, 4, 4)[currentPhase]
	local bWay = EvaArray(5, 6, 6, 8, 8)[currentPhase]
	local bArc = EvaArray(1.5, 1.75, 2.0, 2.5, 3.0)[currentPhase]
	local bSpd = EvaArray(6.0, 6.0, 6.0, 6.0, 6.0)[currentPhase]
	local bSpd2 = EvaArray(3.5, 3.25, 3.0, 2.75, 2.5)[currentPhase]
	local D = ran_Sign()

    EvaTask(function ()
        for iW = 0, way - 1 do
            if(not IsValid(objE))then return end
            local a = ang + (45 - rate * arc[iW + 1])*D
            EvaTShotGreenType2_TShotB(EvaGetX(objE)+10*cos(a), EvaGetY(objE)+10*sin(a), spd, spd2, a, color, bWayIni, bWay, bArc, bSpd, bSpd2)
            wait(wt)
        end
    end)
end

function EvaTShotGreenType2_TShotB(x, y, spd, spd2, ang, color, bWayIni, bWay, bArc, bSpd, bSpd2)
    EvaCallSE(EVA_SE_SHOT2)
	EvaCallSE(EVA_SE_LASER2)
    local pos =  EvaGetScreenLineStates(x, y, 0, ang)
    local time = int(pos[3]/spd)
    local objL = EvaCreateStraightLaserA1(x, y, ang, 0, 80, 999999, ADD_BGW_BEAM_ST_RED + color, 999999)
    EvaObjRender_SetColor_ColorNum(objL, color)
    EvaTask(function ()
        for t = 1, time do
            EvaSetLaserLength(objL, pos[3]*t/time)
            wait()
        end
        if(not IsValid(_boss))then Del(objL) return end
        EvaSetLaserLength(objL, pos[3])
        EvaExplosionB2Type(pos[1], pos[2], 30, 1.0, color)
        local x2 = pos[1]
        local y2 = pos[2]
        local ang2 = atan2(lstg.player.y-y2, lstg.player.x-x2)
        local pos2 = EvaGetScreenLineStates(x2, y2, 0, ang2)
        local time2 = int(pos2[3]/spd)
        local objL2 = EvaCreateStraightLaserA1(x2, y2, ang2, 0, 80, 999999, ADD_BGW_BEAM_ST_RED + color, 999999)
		EvaObjRender_SetColor_ColorNum(objL2, color)
        for t = 1, time2 do
            EvaSetLaserLength(objL2, pos2[3]*(t/time))
            wait()
        end
        EvaSetLaserLength(objL2, pos2[3])
        wait(45 - time - time2)
        if(not IsValid(_boss))then Del(objL2) return end
        EvaCallSE(EVA_SE_SHOT4)
        EvaCallSE(EVA_SE_LASER1)
        local objL3 = EvaCreateUserLooseLaserA1(x, y, 0, ang, 24, 40, color)
        EvaObjMove_SetAcceleration(objL3, spd/50)
		EvaObjMove_SetMaxSpeed(objL3, spd)
        local l = 0
        while(not EvaIsOutScreen(EvaGetX(objL3), EvaGetY(objL3), 0)) do
            l = l + EvaObjMove_GetSpeed(objL3)
            wait()
        end
        if(not IsValid(_boss))then Del(objL3) return end
        if (IsValid(objL)) then Del(objL) end
        l = l - pos[3]
        EvaChangeShotAngle(objL3, ang2)
        EvaObjMove_SetPosition(objL3, pos[1]+l*cos(ang2), pos[2]+l*sin(ang2))
        EvaExplosionB2Type(pos[1], pos[2], 30, 1.0, color)

        for iW = bWay, bWayIni, -1 do
            local a = ang2 + bArc * iW/bWay
            local a2 = ang2 - bArc * iW/bWay
            local bs = bSpd + (bSpd2 - bSpd)*(iW/bWay)
            for iQ = 2, 0, -1 do
                local bs2 = bs * ( 1 - 0.015 * iQ)
                EvaCreateUserShotA1(pos[1], pos[2], bs2, a, BGB_ICE_RED + color, 5)
				EvaCreateUserShotA1(pos[1], pos[2], bs2, a2, BGB_ICE_RED + color, 5)
            end
        end
        wait()
        while(not EvaIsOutScreen(EvaGetX(objL3), EvaGetY(objL3), 0))do
			wait()
		end
		Del(objL2)
    end)
end

-- |||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||

local EvaTShotGreenType3_Shot, EvaCreateUserLooseLaserA11

function EvaTShotGreenType3(objE, currentPhase, color)
    local spdA = {}
	local angA = {}
	local aSpd = 4.0
	local rrr = 0
	local rrrSpd = 30
	local D = ran_Sign()
	local aaa = 0
	local time = 40
	local oldX = 0
	local oldY = 0

    for t = 1, time do
        rrr = rrr + rrrSpd*(0.2+0.8*t/time)
        aaa = aaa + aSpd*(0.5+0.5*t/time)*D
        local x = rrr*cos(aaa)
        local y = rrr*sin(aaa)
        local dx = x-oldX
        local dy = y-oldY
        table.insert(angA, atan2(dy, dx))
        table.insert(spdA, hypot(dx, dy))
        oldX = x
        oldY = y
    end
    --local r = 30
    local way = EvaArray(4, 5, 6, 8, 10)[currentPhase]
    local arc = EvaArray(36, 30, 24, 15, 10)[currentPhase]
    local bSpd = 1.0
    local bItv = 3
    local ang = Angle(objE, lstg.player) + ran_Float(-arc/2, arc/2)
    local wt = 2
    local D2 = 1
    local D22 = EvaArray(1, 1, 1, -1, -1)[currentPhase]
    local delay = 60
    EvaTask(function ()
        for iW = 0, way - 1 do
            if(not IsValid(objE)) then return end
            local a = ang -45*D*D2 - arc*(iW-(way-1)/2)*D*D2
            EvaTShotGreenType3_Shot(EvaGetX(objE)+10*cos(a), EvaGetY(objE)+10*sin(a), 0, a, D2, delay, bSpd, bItv, color, spdA, angA)
            D2 = D2 * D22
            wait(wt)
        end
    end)
end

function EvaTShotGreenType3_Shot(x, y, spd, ang, D, delay, bSpd, bItv, color, spdA, angA)
    local objS = EvaCreateUserLooseLaserA11(x, y, spd, ang, 36, 40, color, delay)
    local c = 0
    EvaTask(function()
        for t = 1, #spdA do
            EvaObjMove_SetSpeed(objS, spdA[t])
            EvaChangeShotAngle(objS, ang+angA[t]*D)
            if(c%bItv == 0) then
                EvaTShotGreenType3_Shot2(EvaGetX(objS), EvaGetY(objS), bSpd, objS.angle, BGB_ICE_RED + color, delay)
            end
            c = c + 1
            wait()
        end
    end)
end

function EvaTShotGreenType3_Shot2(x, y, spd, ang, grap, delay)
    local objS = EvaCreateShotA1(x, y, 0, ang, grap, 0);
	objS.colli_user = false
    objS.hide_user = true
    objS.isBreakEffect = false
    EvaTask(function()
        wait(delay)
        if(not IsValid(objS)) then return end
        for iQ = 2, 0, -1 do
            local bs = spd * (1-0.02*iQ)
            EvaCreateUserShotA2(x, y, 0, ang, bs/50, bs, grap, 5)
        end
        Del(objS)
    end)
end

local EvaCreateUserLooseLaserA11_Laser

function EvaCreateUserLooseLaserA11(x, y, spd, ang, lLeng, lWid, color, delay)
    local objS = EvaCreateShotA1(x, y, spd, ang, ADD_BGW_LIGHT_L_RED + (color%8), 0)
    objS.hide_user = true
    objS.colli_user = false
    local X = x
    local Y = y

    function EvaCreateUserLooseLaserA11_Laser(x_, y_, angle, lLength, lWidth, grap, time, delay_)
        local objL = EvaCreateStraightLaserA1(x_-lLength*cos(angle)/2, y_-lLength*sin(angle)/2, angle, lLength, lWidth, 99999, grap, delay_)
        objL.colli = false
        objL.colli_user = true
        objL.ratioY = 0.3
		local alpha = 0
        EvaTask(function()
            wait(delay_ - 1)
            for t = time, time-5, -1 do
				if(not IsValid(objS) and not EvaIsOut(X,Y,32))then
					EvaStLaserToItem(objL)
					return
				end
				local rate = t/time
				local rate2 = (time-t)/6
				EvaSetLaserLength(objL, lLength*rate)
				EvaSetLaserWidth(objL, lWidth*rate)
				objL.ratioX = 0.4
				alpha = 191*rate2
				EvaSetAlpha(objL, alpha)
				wait()
			end
            objL.colli = true
            alpha = 191
            EvaSetAlpha(objL, alpha)
            for t = time-6, int(time/3)+1, -1 do
                if(not IsValid(objS) and not EvaIsOut(X,Y,32))then
                    EvaStLaserToItem(objL)
                    return
                end
                local rate = t/time
                EvaSetLaserLength(objL, lLength*rate)
                EvaSetLaserWidth(objL, lWidth*rate)
                objL.ratioX = 0.4
                wait()
            end
            objL.colli = false
            for t = int(time/3), 1, -1 do
                if(not IsValid(objS) and not EvaIsOut(X,Y,32))then
                    EvaStLaserToItem(objL)
                    return
                end
                local rate = t/time
                local rate2 = t/(time/3)
                EvaSetLaserLength(objL, lLength*rate)
                EvaSetLaserWidth(objL, lWidth*rate)
                objL.ratioX = 0.4
                alpha = 191*rate2
                EvaSetAlpha(objL, alpha)
                wait()
            end
            Del(objL)
        end)
    end

    EvaTask(function()
        EvaTask(function()
            EvaCallSE(EVA_SE_SHOT2)
            EvaCallSE(EVA_SE_LASER2)
            wait(delay)
            EvaCallSE(EVA_SE_SHOT4)
            EvaCallSE(EVA_SE_LASER1)
        end)
        while(IsValid(objS))do
            if(EvaObjMove_GetSpeed(objS) > 0)then
                EvaCreateUserLooseLaserA11_Laser(EvaGetX(objS), EvaGetY(objS), objS.angle, 5*EvaObjMove_GetSpeed(objS), lWid, ADD_BGW_LIGHT_L_RED + (color%8), lLeng, delay)
            end
            X = EvaGetX(objS)
            Y = EvaGetY(objS)
            wait()
        end
    end)

    return objS
end

-- |||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||

local EvaTShotGreenType4_TShot

function EvaTShotGreenType4(objE, currentPhase, color)
    local way = EvaArray(3, 4, 6, 7, 9)[currentPhase]
    local arc = EvaArray(20, 20, 20, 16, 12)[currentPhase]
    local wt = EvaArray(10, 8, 5, 4, 3)[currentPhase]
    local r = 10
    local spd = 6
    local ang = Angle(objE, lstg.player)+180
    local bWay = 24
    local bSpd = 2.0

    EvaTShotGreenType4_TShot(EvaGetX(objE) + r*cos(ang), EvaGetY(objE) + r*sin(ang), spd, ang, bWay, bSpd, color)

    EvaTask(function ()
        wait(wt)
        for iW = 1, way - 1 do
            if(not IsValid(objE)) then return end
            local a = ang+arc*iW
            local a2 = ang-arc*iW
            local sRate = 1.0-0.2*iW/(way-1)
            EvaTShotGreenType4_TShot(EvaGetX(objE) + r*cos(a), EvaGetY(objE) + r*sin(a), spd*sRate, a, bWay, bSpd*sRate, color)
            EvaTShotGreenType4_TShot(EvaGetX(objE) + r*cos(a2), EvaGetY(objE) + r*sin(a2), spd*sRate, a2, bWay, bSpd*sRate, color)
            wait(wt)
        end
    end)
end

function EvaTShotGreenType4_TShot(x, y, spd, ang, bWay, bSpd, color)
    EvaCallSE(EVA_SE_SHOT3)
    local objS = EvaCreateUserShotA2(x, y, 0, ang, spd/100, spd, ADD_BGW_BALL_L_RED + color, 10)
    EvaTask(function ()
        while(not EvaIsOutScreen(EvaGetX(objS), EvaGetY(objS), 0))do
            wait(1)
        end
        if(not IsValid(objS)) then return end
        EvaCallSE(EVA_SE_SHOT6)
        local bAng = ran_Float(0, 360)
        local bx = EvaGetX(objS)
        local by = EvaGetY(objS)
        --Del(objS)
        EvaExplosionB2Type(bx, by, 30, 1.0, color)
        for iW = 0, bWay - 1 do
            local ba = bAng+360*iW/bWay
            local bs = bSpd*(1-0.25*(iW%2))
            EvaCreateUserShotA2(bx, by, 0, ba-0.25, bs/50*0.9875, bs*0.9875, BGB_SCALE_RED + color, 10)
            EvaCreateUserShotA2(bx, by, 0, ba+0.25, bs/50*0.9875, bs*0.9875, BGB_SCALE_RED + color, 10)
            EvaCreateUserShotA2(bx, by, 0, ba     , bs/50*1.0000, bs*1.0000, BGB_SCALE_RED + color, 10)
        end
    end)
end