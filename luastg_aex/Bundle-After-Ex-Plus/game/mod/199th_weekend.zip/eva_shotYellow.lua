local sin, cos = sin, cos
local atan2 = atan2
local wait = EvaWait

local EvaTask = EvaTask
local EvaCreateUserShotA2 = EvaCreateUserShotA2
local EvaCreateStraightLaserA1 = EvaCreateStraightLaserA1
local EvaSetLaserLength = EvaSetLaserLength
local EvaSetLaserWidth  = EvaSetLaserWidth
local EvaSetPosition    = EvaSetPosition
local EvaSetAlpha       = EvaSetAlpha
local EvaSetColor       = EvaSetColor
local IsValid           = IsValid
local Del               = Del
local Kill              = Kill
local Angle             = Angle
local EvaChangeShotAngle = EvaChangeShotAngle
local EvaSetStLaserAngle = EvaSetStLaserAngle
local ran_Float         = function(a, b) return ran:Float(a, b) end
local ran_Sign          = function() return ran:Sign() end
local ran_Int           = function(a, b) return ran:Int(a, b) end

EvaShotYellowA = {}
EvaShotYellow_Count = 0
EvaShotYellowA_Chosen = 0
EvaShotYellowA_Add = 0
EvaShotYellowA_Reset = {
    EVA_SP1_SHOT_YELLOW_01,
    EVA_SP1_SHOT_YELLOW_02,
    EVA_SP1_SHOT_YELLOW_03,
    EVA_SP1_SHOT_YELLOW_04
}

function EvaResetShotYellowArray()
    EvaShotYellowA = CopyArray(EvaShotYellowA_Reset)
end

function EvaGetShotYellowArrayLength()
    return #EvaShotYellowA
end

function EvaEraseShotYellowArray(num)
    table.remove(EvaShotYellowA, num)
end

function EvaEraseShotYellowArray2(num)
    for iQ = 1, EvaGetShotYellowArrayLength() do
        if EvaShotYellowA[iQ] == num then
            table.remove(EvaShotYellowA, iQ)
            break
        end
    end
end

function EvaAddShotYellowArray(num)
    table.insert(EvaShotYellowA, num)
end

function EvaTShotYellow(objE, currentPhase, wt)
    task.New(objE, function()
        task.Wait(wt)
        if(not EvaIsCurrentPhase(currentPhase)) then return end
        local color = EVA_COLOR_YELLOW
        local num = ran:Int(1, EvaGetShotYellowArrayLength())
        EvaShotYellowA_Chosen = EvaShotYellowA[num]
        EvaTShotColorNum(EvaShotYellowA[num], objE, currentPhase, color)
        EvaEraseShotYellowArray(num)
        EvaShotYellow_Count = EvaShotYellow_Count + 1
    end)
end

--|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||

local EvaTSquare

function EvaTShotYellowType1(objE, currentPhase, color)
    local way = EvaArray(3, 3, 5, 7, 9)[currentPhase]
	local arc = EvaArray(60, 60, 40, 30, 24)[currentPhase]
	local r = EvaArray(40, 45, 45, 45, 45)[currentPhase]

	EvaTSquare(objE, way, 2, ran_Sign(), r*2, r, 1.20, arc, ran_Float(-180, 180), 2.4, color)
end

--|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||

local EvaTShotYellowType2_TShot
local EvaTShotYellowType2_TRender
local EvaTShotYellowType2_Render
local EvaTShotYellowType2_Laser

function EvaTShotYellowType2(objE, currentPhase, color)
    local r = EvaArray(90, 95, 100, 110, 120)[currentPhase]
    local time = 40
    local time2 = 70
    EvaTShotYellowType2_TShot(objE, lstg.player.x, lstg.player.y, ran_Float(-180, 180), r, time, time2, color)
end

function EvaTShotYellowType2_TShot(objE, x, y, ang, r, time, time2, color)
    EvaCallSE(EVA_SE_SHOT2)
    local objS = EvaCreateUserShotA1(EvaGetX(objE), EvaGetY(objE), 0, ang, BGW_KNIFE_RED + color, 0);
    objS.colli_user = false
    objS.colli = false
    objS.isBreakEffect = false
    EvaSetAlpha(objS, 127)
    EvaSetMovePositionBraking01(objS, x, y, time)
    EvaObjRender_SetColor_ColorNum(objS, color)
    EvaTShotYellowType2_TRender(objS, ADD_BGW_KNIFE_RED + color, color)
    EvaTask(function ()
        for t = time, 1, -1 do
            if(not IsValid(objS)) then return end
			local rAng = 720*cos(90*t/time)
			EvaChangeShotAngle(objS, ang+rAng)
			wait()
        end
        local way = 10
		local way2 = 8
		for iQ = 0, 1 do
			if(not IsValid(objS)) then return end
			for iW = 0, way - 1 do
				for iW2 = 0, way2 - 1 do
					local a = 360*(iW+iW2/way2)/way
					local rx = r*1.00*cos(a)
					local ry = r*0.75*sin(a)
					local ra = atan2(ry, rx)
					local rr = hypot(rx, ry)
					EvaTShotYellowType2_Laser( x, y, ang+ra+90*iQ, rr, time2, color, (iW==0))
				end
				wait(1)
			end
		end
		wait(time2-way)
		Del(objS)
    end)
end

function EvaTShotYellowType2_TRender(objS, grap, color)
    EvaTask(function ()
        while(IsValid(objS))do
            EvaTShotYellowType2_Render(EvaGetX(objS), EvaGetY(objS), objS.angle, grap, color, 12)
            wait(1)
        end
    end)
end

function EvaTShotYellowType2_Render(x, y, ang, grap, color, time)
    EvaTask(function ()
        local obj = EvaCreateShotA1(x, y, 0, ang, grap, 0)
        EvaObjRender_SetColor_ColorNum(obj, color)
        obj.isBreakEffect = false
        obj.colli_user = false
        for i = time, 1, -1 do
            local alpha = 127*i/time
            EvaSetAlpha(obj, alpha)
            wait()
        end
        Del(obj)
    end)
end

function EvaTShotYellowType2_Laser(x, y, ang, leng, time, color, flag)
    EvaTask(function ()
        local time2 = 30
        local objL = EvaCreateStraightLaserA1(x+leng*0.2*cos(ang), y+leng*0.2*sin(ang), ang, leng*0.8, 24, 99999, ADD_BGW_BEAM_ST_RED + color, 0)
        EvaObjRender_SetColor_ColorNum(objL, color)
        objL.colli_user = false
        EvaSetLaserWidth(objL, 4)
        if(flag)then
            EvaCallSE(EVA_SE_SHOT3)
        end
        for t = time, 1, -1 do
            local alpha = 31+96*t/time
            EvaSetAlpha(objL, alpha)
            wait()
        end
        local graphic = ADD_BGW_KNIFE_RED + color
        EvaUpdateShotByData(objL, graphic)
        objL.colli_user = true
        EvaSetLaserWidth(objL, 24)
        if(flag)then
            EvaCallSE(EVA_SE_SHOT4)
        end
        objL.beginX = x
        objL.beginY = y
        EvaSetLaserLength(objL, leng)
        for t = time2, time2/2+1, -1 do
            local alpha = 255*t/time2
            EvaSetAlpha(objL, alpha)
            wait()
        end
        objL.colli_user = false
        for t = time2/2, 1, -1 do
            local alpha = 255*t/time2
            EvaSetAlpha(objL, alpha)
            wait()
        end
        Del(objL)
    end)
end

--|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||

local EvaTShotYellowType3_TShot2
local EvaTShotYellowType3_TShot
local EvaTShotYellowType3_Laser
local EvaTShotYellowType3_Shot

function EvaTShotYellowType3(objE, currentPhase, color)
    local r = 105
    local qnt = EvaArray(1, 1, 1, 2, 2)[currentPhase]
    local way = EvaArray(10, 12, 15, 12, 15)[currentPhase]
    local wt = EvaArray(2, 2, 2, 1, 1)[currentPhase]
    local bWay = EvaArray(5, 5, 6, 6, 6)[currentPhase]
    local bSpd = EvaArray(2.0, 2.0, 2.0, 2.4, 2.4)[currentPhase]
    local bArc = EvaArray(10, 10, 10, 10, 10)[currentPhase]
    local D = ran_Sign()
    local lSpd = 30
    local lWay = 5

    EvaTask(function ()
        for _= 1, qnt do
            local ang = Angle(objE, lstg.player)+180+ran_Float(180/way, 180/way)
            EvaTShotYellowType3_TShot2(objE, r, ang, way, wt, lWay, lSpd, 60, 0.75, bWay, bSpd, bArc, D, color)
            D = -D
            wait(16)
        end
    end)
end

function EvaTShotYellowType3_TShot2(objE, r, ang, way, wt, lWay, lSpd, lAng, lArc, bWay, bSpd, bArc, D, color)
    EvaTask(function ()
        for iW = 0, way - 1 do
            if(not IsValid(objE)) then return end
            local a = ang+360*iW/way*D
            EvaTShotYellowType3_TShot(r, EvaGetX(objE), EvaGetY(objE), a, way, lWay, lSpd, a-lAng*D, lArc, bWay, bSpd, bArc, color)
            wait(wt)
        end
    end)
end

function EvaTShotYellowType3_TShot(r, x, y, ang, way,lWay, lSpd, lAng, lArc, bWay, bSpd, bArc, color)
    local time = 36
    local time2 = 54
    EvaCallSE(EVA_SE_SHOT2)
    local objS = EvaCreateUserShotA1(x, y, 0, ang, BGW_KNIFE_RED + color, 5)
    EvaSetMovePositionBraking01(objS, x + r*cos(ang), y + r*sin(ang), 30)
    EvaTask(function ()
        for t = time, 1, -1 do
            if(not IsValid(objS)) then return end
			local rAng = lAng + 720*cos(90*t/time)
			EvaChangeShotAngle(objS, rAng)
			wait()
        end
        local lLeng = lSpd*18
		if(not IsValid(objS)) then return end
		EvaTShotYellowType3_Laser(EvaGetX(objS), EvaGetY(objS), lSpd, lAng, lLeng, time2, bWay, bSpd, bArc, color)
		wait(1)
		for iW = 1, lWay - 1 do
			if(not IsValid(objS)) then return end
			local la =  lAng+lArc*iW
			local la2 = lAng-lArc*iW
			EvaTShotYellowType3_Laser(EvaGetX(objS), EvaGetY(objS), lSpd, la , lLeng, time2, 0, bSpd, bArc, color)
			EvaTShotYellowType3_Laser(EvaGetX(objS), EvaGetY(objS), lSpd, la2, lLeng, time2, 0, bSpd, bArc, color)
			wait(1)
		end
		wait(time2-way)
		EvaCallSE(EVA_SE_LASER1)
		Del(objS)
    end)
end

function EvaTShotYellowType3_Laser(x, y, spd, ang, leng, time, bWay, bSpd, bArc, color)
    local objL = EvaCreateStraightLaserA1(x, y, ang, 480, 80, 999999, ADD_BGW_BEAM_ST_RED + color, 99999, true)
    EvaObjRender_SetColor_ColorNum(objL, color)
    EvaTask(function ()
        for t = time, 1, -1 do
            EvaSetLaserLength(objL, 480*sin(90*t/time))
            local alpha = 63+191*t/time
            EvaSetAlpha(objL, alpha)
            wait()
        end
        Del(objL)
        local objL2 = EvaCreateLooseLaserA1(x, y, spd, ang, leng, 20, ADD_BGW_KNIFE_RED + color, 0)
        objL2.ratioX = 0.1
        objL2.ratioY = 0.8
        if(bWay > 0)then
            local bAng = ang+180
            for iW = bWay-1, 1, -1 do
                local a = bArc*iW/(bWay-1)
                local bS = bSpd*(1-0.5*iW/(bWay-1))
                EvaTShotYellowType3_Shot(x, y, 3*bS, bAng+a, -2*bS/50, bS, color, 10)
                EvaTShotYellowType3_Shot(x, y, 3*bS, bAng-a, -2*bS/50, bS, color, 10)
            end
            EvaTShotYellowType3_Shot(x, y, 3*bSpd, bAng, -2*bSpd/50, bSpd, color, 10)
        end
    end)
end

function EvaTShotYellowType3_Shot(x, y, spd, ang, acce, mSpd, color, delay)
    EvaCreateUserShotA2(x           , y           , spd, ang, acce, mSpd, BGB_KUNAI_RED + color, delay)
    EvaCreateUserShotA2(x+7*cos(ang), y+7*sin(ang), spd, ang, acce, mSpd, BGB_SCALE_RED + color, delay)
end

--|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||

local EvaTShotYellowType4_TShot
local EvaTShotYellowType4_TShot2
local EvaTShotYellowType4_Shot
local EvaTShotYellowType4_Laser
local EvaTShotYellowType4_TRender
local EvaTShotYellowType4_Render

function EvaTShotYellowType4(objE, currentPhase, color)
    local ang = Angle(objE, lstg.player)
	EvaTShotYellowType4_TShot(objE, currentPhase, EvaGetX(objE)+60*cos(ang), EvaGetY(objE)+60*sin(ang), ang, color)	
end

function EvaTShotYellowType4_TShot(objE, currentPhase, x, y, ang, color)
    EvaCallSE(EVA_SE_SHOT2)
    local time = 30
    local time2 = 45
    local scl = 2.0
    local r = EvaArray(300, 330, 360, 360, 360)[currentPhase]
    local r2 = r/3
    local bQnt = EvaArray(1, 1, 1, 2, 2)[currentPhase]
    local bWay = EvaArray(80, 100, 120, 80, 100)[currentPhase]
    local bSpd = 6.0

    local objS = EvaCreateUserShotA1(EvaGetX(objE), EvaGetY(objE), 0, ang, BGW_KNIFE_RED + color, 0)
    objS.colli_user = false
    objS.isBreakEffect = false
    EvaSetScaleXYZ(objS, scl, scl, scl)
    EvaSetAlpha(objS, 127)
    EvaSetMovePositionBraking01(objS, x, y, 45)
    EvaTShotYellowType4_TRender(objS, ADD_BGW_KNIFE_RED + color, color, scl)
    EvaTask(function ()
        for t = time, 1, -1 do
            if(not IsValid(objS)) then return end
            local rAng = 720*cos(90*t/time)
            EvaChangeShotAngle(objS, ang+rAng)
            wait()
        end
        local D = ran_Sign()
        for iQ = 0, bQnt - 1 do
            EvaTShotYellowType4_TLaser(objS, x, y, ang+36*(iQ-(bQnt-1)/2), r, r2, D, bWay, bSpd, time2, color)
            D = -D
            wait(15)
        end
        wait(time2-bQnt*15)
        Del(objS)
    end)
end

function EvaTShotYellowType4_TLaser(objS, x, y, ang, r, r2, D, bWay, bSpd, time2, color)
    local way = 10
    local way2 = 20
    EvaTask(function ()
        if(not IsValid(objS)) then return end
        for iW = 0, way - 1 do
            for iW2 = 0, way2 - 1 do
                local a = -180+360*(iW+iW2/way2)/way*D
                local rx = r2*cos(a)
                local ry = r*sin(a)
                local ra = atan2(ry, rx)
                local rr = hypot(rx, ry)
                EvaTShotYellowType4_Laser(x, y, ang+ra, rr, time2, iW2/way2, color, (iW==0))
            end
        end
        wait(time2-way)
        EvaTShotYellowType4_TShot2(x, y, ang, r, r2, D, way, bWay, bSpd, color)
    end)
end

function EvaTShotYellowType4_TShot2(x, y, ang, r, r2, D, time, way, spd, color)
    EvaTask(function ()
        local c = 0
        local cRate = ran_Float(0, 0.9999)
        for iW = 0, way - 1 do
            local a = -180+360*(iW+cRate)/way*D
            local rx = r2*cos(a)
            local ry = r*sin(a)
            local ra = atan2(ry, rx)
            local rr = hypot(rx, ry)
            local ba = ang+ra
            local bs = rr/r*spd*(1-0.5*(iW%2))
            for iQ = 2, 0, -1 do
                local bx = x+rr*cos(ba)*(0.8-0.6*iQ/2)
                local by = y+rr*sin(ba)*(0.8-0.6*iQ/2)
                local bs2 = bs*(1-0.02*iQ)
                EvaTShotYellowType4_Shot(bx, by, 0, ba, bs2/100, bs2, color, 10)
            end
            c = c + time/way
            while(c >= 1) do
                c = c - 1
                wait(1)
            end
        end
    end)
end

function EvaTShotYellowType4_Shot(x, y, spd, ang, acce, mSpd, color, delay)
    EvaCreateUserShotA2(x           , y           , spd, ang, acce, mSpd, BGW_KUNAI_RED + color, delay)
    EvaCreateUserShotA2(x+7*cos(ang), y+7*sin(ang), spd, ang, acce, mSpd, BGW_SCALE_RED + color, delay)
end

function EvaTShotYellowType4_Laser(x, y, ang, leng, time, alpRate, color, flag)
    EvaTask(function ()
        local time2 = 30
        local objL = EvaCreateStraightLaserA1(x, y, ang, leng, 20, 99999, ADD_BGW_BEAM_ST_RED + color, 0)
        EvaObjRender_SetColor_ColorNum(objL, color)
        objL.colli_user = false
        EvaSetLaserWidth(objL, 10)
        if(flag)then
            EvaCallSE(EVA_SE_SHOT3)
        end
        for t = time, 1, -1 do
            local alpha = 31+96*(t+alpRate)/time
            EvaSetAlpha(objL, alpha)
            wait()
        end
        EvaUpdateShotByData(objL, ADD_BGW_KNIFE_RED + color)
        objL.a = 0
        objL.b = 0
        objL.colli_user = true
        EvaSetLaserWidth(objL, 50)
        if(flag)then
            EvaCallSE(EVA_SE_FIRE1)
            EvaCallSE(EVA_SE_SHOT6)
        end
        for t = time2, time2/2+1, -1 do
            local alpha = 255*(t+alpRate)/time2
            EvaSetAlpha(objL, alpha)
            wait()
        end
        objL.colli_user = false
        for t = time2/2, 1, -1 do
            local alpha = 255*(t+alpRate)/time2
            EvaSetAlpha(objL, alpha)
            wait()
        end
        Del(objL)
    end)
end

function EvaTShotYellowType4_TRender(objS, grap, color, scl)
    EvaTask(function ()
        while(IsValid(objS))do
            EvaTShotYellowType4_Render(EvaGetX(objS), EvaGetY(objS), objS.angle, grap, color, scl, 12)
			wait(1)
        end
    end)
end

function EvaTShotYellowType4_Render(x, y, ang, grap, color, scl, time)
    local obj = EvaCreateShotA1(x, y, 0, ang, grap, 0)
    EvaObjRender_SetColor_ColorNum(obj, color)
    obj.colli_user = false
    obj.isBreakEffect = false
    EvaSetScaleXYZ(obj, scl, scl, scl)
    EvaTask(function ()
        for i = time, 1, -1 do
            local alpha = 127*i/time
            EvaSetAlpha(obj, alpha)
            wait()
        end
        Del(obj)
    end)
end

--|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||

local Square_Ini
local Square

function EvaTSquare(objE, way, wt, D, rMax, rMin, spd, arc, ang2, aSpd2, color)
    local time = 45
    EvaCallSE(EVA_SE_WAVE)
    Square_Ini(objE, time, way, wt, rMax, ang2, D, color)
    EvaTask(function ()
        wait(time)
        local D2 = D
        local ang = Angle(objE, lstg.player)
        for iW = 0, way - 1 do
            if(not IsValid(objE))then return end
            EvaCallSE(EVA_SE_SHOT2)
            Square(EvaGetX(objE), EvaGetY(objE), rMax, rMin, spd, ang+arc*(iW-(way-1)/2)*D, ang2, aSpd2*D2, -D2, color)
            D2 = -D2
            wait(wt)
        end
    end)
end

local rManage
local SquareLaser
local SquareLaserAI
local rManage2
local SpeedManage2
local Laser2
local Laser2AI

function Square_Ini(objE, time, way, wt, rMax, ang2, D, color)
    --flag
    local obj = EvaDummyObjectForTask()
    obj.flag = false
    obj.bx = EvaGetX(objE)
    obj.by = EvaGetY(objE)
    obj.r = 0
    obj.ix = obj.r*cos(0)
    obj.iy = obj.r*sin(0)
    obj.fx = obj.r*cos(90)
    obj.fy = obj.r*sin(90)
    obj.dx1 = obj.fx-obj.ix
    obj.dy1 = obj.fy-obj.iy
    obj.da = atan2(obj.dy1, obj.dx1)
    obj.dl = hypot(obj.dx1, obj.dy1)

    obj.ang2 = ang2
    obj.color = color
    obj.bA = ang2
    obj.rMax = rMax
    obj.D = D

    rManage(objE, time, way*wt, obj)

    for iW = 0, 3 do
        SquareLaser(obj, 90*iW)
    end
    EvaTask(function ()
        wait(time + way * wt)
        obj.flag = true
    end)
end

function rManage(objE, time, time2, obj)
    EvaTask(function ()
        for t = 0, time do
            if(not IsValid(objE))then
                obj.flag = true
                return
            end
            local rate = sin(90*t/time)
            obj.bx = EvaGetX(objE)
            obj.by = EvaGetY(objE)
            obj.r = obj.rMax * rate
            obj.ix = obj.r*cos(0)
            obj.iy = obj.r*sin(0)
            obj.fx = obj.r*cos(90)
            obj.fy = obj.r*sin(90)
            obj.dx1 = obj.fx-obj.ix
            obj.dy1 = obj.fy-obj.iy
            obj.da = atan2(obj.dy1, obj.dx1)
            obj.dl = hypot(obj.dx1, obj.dy1)
            obj.ang2 = obj.bA-180*(1-rate)*obj.D
            wait()
        end
        for _ = 1, time2 do
            if(not IsValid(objE))then
                obj.flag = true
                return
            end
            obj.bx = EvaGetX(objE)
            obj.by = EvaGetY(objE)
            wait()
        end
    end)
end

function SquareLaser(obj, angP)
    local a = obj.ang2 + angP
    local objLA = EvaCreateStraightLaserA1(obj.bx + obj.r*cos(a), obj.by + obj.r*sin(a), a + obj.da, obj.dl, 12, 99999, ADD_BGW_BEAM_ST_RED + obj.color, 0)
    EvaObjShot_SetAutoDelete(objLA, false)
    objLA.ratioY = 1.0
    local t = 0
    EvaTask(function ()
        while(IsValid(objLA) and not obj.flag)do
            obj.a = obj.ang2 + angP
            objLA.beginX = obj.bx + obj.r * cos(obj.a)
            objLA.beginY = obj.by + obj.r * sin(obj.a)
            EvaSetLaserLength(objLA, obj.dl)
            EvaSetStLaserAngle(objLA, obj.a + obj.da)
            SquareLaserAI(obj, 30)
            t = t + 1
            wait()
        end
        Del(objLA)
    end)
end

function SquareLaserAI(obj, time)
    local objLE = EvaCreateStraightLaserA1(obj.bx + obj.r*cos(obj.a), obj.by + obj.r*sin(obj.a), obj.a + obj.da, obj.dl, 12, 99999, ADD_BGW_BEAM_ST_RED + obj.color, 0, true)
    EvaObjRender_SetColor_ColorNum(objLE, obj.color)
    EvaObjShot_SetAutoDelete(objLE, false)
    EvaTask(function ()
        for t = time, 1, -1 do
            EvaSetAlpha(objLE, 127*t/time)
            wait()
        end
        Del(objLE)
    end)
end

--|||||||||||||||||||

function Square(x, y, rMax, rMin, spd, ang, ang2, aSpd2, D, color)
    local flag = false
    local bx = x
    local by = y
    local r = rMax
    local ix = r*cos(0)
    local iy = r*sin(0)
    local fx = r*cos(90)
    local fy = r*sin(90)
    local dx = fx-ix
    local dy = fy-iy
    local da = atan2(dy, dx)
    local dl = hypot(dx, dy)

    local xSpd = spd*cos(ang)
    local ySpd = spd*sin(ang)

    function rManage2(time)
        EvaTask(function ()
            for t = 0, time do
				r = rMax - (rMax-rMin)*sin(90*t/time)
				ix = r*cos(0)
				iy = r*sin(0)
				fx = r*cos(90)
				fy = r*sin(90)
				dx = fx-ix
				dy = fy-iy
				da = atan2(dy, dx)
				dl = hypot(dx, dy)
				wait()
			end
        end)
    end

    function SpeedManage2(rate, rate2, time)
        EvaTask(function ()
            for t = time, 1, -1 do
				local rateB = (rate-1)*t/time
				local rate2B = (rate2-1)*t/time
				bx = bx + xSpd*rateB
				by = by + ySpd*rateB
				ang2 = ang2 + aSpd2*rate2B
                wait()
            end
        end)
    end

    function Laser2(angP)
        local a = ang2 + angP
        local objLA = EvaCreateStraightLaserA1(bx + r*cos(a), by + r*sin(a), a + da, dl, 12, 99999, ADD_BGW_BEAM_ST_RED + color, 0)
        EvaObjShot_SetAutoDelete(objLA, false)
        objLA.ratioY = 1.0
        local t = 0

        EvaTask(function ()
            while (IsValid(objLA) and not flag) do
                a = ang2 + angP
                objLA.beginX = bx + r * cos(a)
                objLA.beginY = by + r * sin(a)
                EvaSetLaserLength(objLA, dl)
                EvaSetStLaserAngle(objLA, a + da)
                if(t % 5 == 0) then Laser2AI(30, bx, by, r, a, da, dl, color) end -- 调用时传递当前值
                t = t + 1
                wait()
            end
            Del(objLA)
        end)
    end

    rManage2(90)
    SpeedManage2(2, 2, 90)

    EvaTask(function ()
        for iW = 0, 3  do
            Laser2(90 * iW)
        end
        while(IsValid(_boss) and not EvaIsTimeOut() and not EvaIsOutScreen(bx, by, r))do
            bx = bx + xSpd
            by = by + ySpd
            ang2 = ang2 + aSpd2
            wait()
        end
        flag = true
    end)
end

--金边AfterImage
function Laser2AI(time, _bx, _by, _r, _a, _da, _dl, _color) -- 接收当前位置和角度作为参数
    EvaTask(function ()
        local objLE = EvaCreateStraightLaserA1(_bx + _r*cos(_a), _by + _r*sin(_a), _a + _da, _dl, 12, 99999, ADD_BGW_BEAM_ST_RED + _color, 0, true)
        EvaObjRender_SetColor_ColorNum(objLE, _color)
        EvaObjShot_SetAutoDelete(objLE, false)
        for tt = time, 1, -1 do
            EvaSetAlpha(objLE, 127 * tt/time)
            wait()
        end
        Del(objLE)
    end)
end
