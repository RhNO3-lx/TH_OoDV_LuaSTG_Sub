--栈，栈的大小
local NormalTasks       = {}
local NormalTaskSize    = 0

--||==============================================================[Private Methods]=====================================================================

--- [Private]恢复全体有效协程
local function ResumeTasks()
    --NormalTasks
    for i = 1, NormalTaskSize do
        local task = NormalTasks[i]
        if task and coroutine.status(task) ~= "dead" then
            coroutine.resume(task)
        end
    end
end

--- [Private]清理全体无效协程
local function GcTasks()
    -- NormalTasks
    local j = 1
    for i = 1, NormalTaskSize do
        local task = NormalTasks[i]
        if task and coroutine.status(task) ~= "dead" then
            NormalTasks[j] = task
            j = j + 1
        end
    end
    for k = j, NormalTaskSize do
        NormalTasks[k] = nil
    end
    NormalTaskSize = j - 1
end

--||==============================================================[Public Methods]======================================================================

--- 创建Task
---@param f function The function to run as a coroutine
---@return thread thread The created coroutine
function EvaTask(f, ...)
    local args = {...}
    local t = coroutine.create(function ()
        f(unpack(args))
    end)
    NormalTaskSize = NormalTaskSize + 1
    NormalTasks[NormalTaskSize] = t
    return t
end

--- 清除所有协程
function EvaClearTasks()
    for i = NormalTaskSize, 1, -1 do
        NormalTasks[i] = nil
    end
    NormalTaskSize  = 0
end

--- 返回当前有效协程个数
---@return integer
function EvaGetTaskCount()
    return NormalTaskSize
end

--- 更新全体Task
function EvaTaskFrame()
    ResumeTasks()
    GcTasks()
end

--- 等待n帧
function EvaWait(n)
    if(not n) then coroutine.yield() return end
    n = max(n, 1)
    for _ = 1, n do
        coroutine.yield()
    end
end

local tC = Class(object)

function tC:init()
    self.bound = false
    self.group = GROUP_GHOST
    EvaClearTasks()
end

function tC:frame()
    EvaTaskFrame()
end

local EVA_TASK_CONTROLLER = nil

function EvaCreateTaskCtronller()
    local obj = New(tC)
    EVA_TASK_CONTROLLER = obj
    return obj
end

function EvaClearTaskController()
    if IsValid(EVA_TASK_CONTROLLER) then
        Del(EVA_TASK_CONTROLLER)
        EVA_TASK_CONTROLLER = nil
    end
end