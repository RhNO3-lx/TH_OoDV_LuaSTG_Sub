LoadTexture("eva_world01a", "eva_world01a.png")
SetTextureSamplerState("eva_world01a", "linear+wrap")
LoadTexture("eva_world01b", "eva_world01b.png")
SetTextureSamplerState("eva_world01b", "linear+wrap")

function EvaSetWorld01()
    local tex1 = "eva_world01a"
    local tex2 = "eva_world01b"
    local tex3 = "eva_dummy"
    local fogObj =  EvaSimpleSprite3D(tex3, LAYER_BG - 1, 0, 0)
    local obj = {
        EvaSimpleSprite3D(tex1, LAYER_BG - 1, 0, 0),
        EvaSimpleSprite3D(tex1, LAYER_BG - 1, 0, 0),
        EvaSimpleSprite3D(tex1, LAYER_BG - 1, 0, 0),
        EvaSimpleSprite3D(tex1, LAYER_BG - 1, 0, 0),
        EvaSimpleSprite3D(tex1, LAYER_BG - 1, 0, 0),
    }
    local obj2 = {
        EvaSimpleSprite3D(tex2, LAYER_BG, 0, 0),
        EvaSimpleSprite3D(tex2, LAYER_BG, 0, 0),
        EvaSimpleSprite3D(tex2, LAYER_BG, 0, 0),
        EvaSimpleSprite3D(tex2, LAYER_BG, 0, 0),
        EvaSimpleSprite3D(tex2, LAYER_BG, 0, 0),
    }
    local cc			= 0
    local cc_plus		= 0
    local cc_max		= 2
    local move1		    = 0
    local moveA		    = 0
    local scroll1		= 0
    local count		    = 0
    local dummy = EvaDummyObjectForTask()

    for i = 1, #obj do
        EvaSetScaleXYZ(obj[i], 1, 2, 0)
        EvaSetSourceRect(obj[i], 0, 0, 512, 512)
        EvaSetDestRect(obj[i], -256, -256, 256, 256)
        EvaSetColor(obj[i], 128, 128, 128)
        EvaSetAlpha(obj[i], 255)

        EvaSetScaleXYZ(obj2[i], 1, 2, 0)
        EvaSetSourceRect(obj2[i], 0, 0, 512, 512)
        EvaSetDestRect(obj2[i], -256, -256, 256, 256)
    end

    EvaSetSourceRect(fogObj, 0, 0, 1, 1)
    EvaSetDestRect(fogObj, -1.0, -1.0, 1.0, 1.0)
    EvaSetPosition(fogObj, 0, 0, 2)
    EvaSetScaleXYZ(fogObj, 1.5, 1.5, 0)
    EvaSetAngleXYZ(fogObj, 0, 0, 0)

    local const1 = math.rad(45)
    local const2 = tan(36)

    task.New(dummy, function()
        while true do
            
            Set3D("fog", 2.0, 2.73 + 0.3 * move1 * sin(cc/8), Color(255, 16, 16, 32))
            Set3D("eye", 0, 0, -1)
            Set3D("at", 0.1 * cos(cc/4), 0.1 * sin(cc/4), 0)
            Set3D("up", 0, 1, 0)
            Set3D("z", 1, 20)
            Set3D("fovy", const1)

            local plus = count/5
            for i = 1, #obj do
                EvaSetPosition(obj[i], 1.0 * cos((i-1)*72 + plus), 1.0 * sin((i-1)*72 + plus), 1.0)
                EvaSetAngleXYZ(obj[i],  90, 90 - (i-1)*72 - plus, 0)
                EvaSetPosition(obj2[i], 1.0 * cos((i-1)*72 + plus), 1.0 * sin((i-1)*72 + plus), 1.0)
                EvaSetAngleXYZ(obj2[i], 90, 90 - (i-1)*72 - plus, 0)
                EvaSetColor(obj2[i], 128 - 127*sin(count), 128 + 127*sin(count), 255 )
            end

            local _rect = 2.0 * const2
            local _rect2 = _rect * 512
            for i = 1, #obj do
                EvaSetSourceRect(obj[i], 0-cc/8, 0+cc*2, _rect2-cc/8, _rect2+cc*2)
                EvaSetDestRect(obj[i], -_rect/2, -_rect/2, _rect/2, _rect/2)
                EvaSetSourceRect(obj2[i], 0-cc/8, 0+cc*2, _rect2-cc/8, _rect2+cc*2)
                EvaSetDestRect(obj2[i], -_rect/2, -_rect/2, _rect/2, _rect/2)
            end

            count = count + 1
            cc = cc + cc_plus
            if move1 < 1 then
                moveA = moveA + 0.5
            else
                if cc_plus < cc_max then
                    cc_plus = cc_plus + 0.02
                else
                    cc_plus = cc_max
                end
            end
            move1 = 1 * sin( moveA )
            scroll1 = scroll1 + cc_plus
            if 512 <= scroll1 then scroll1 = 0 end

            task.Wait()
        end
    end)
end