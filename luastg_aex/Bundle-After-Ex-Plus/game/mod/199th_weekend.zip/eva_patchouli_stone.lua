local texture = "eva_patchouli_efc1"

EVA_SP1_SHOT_RED_01 	= 0
EVA_SP1_SHOT_RED_02 	= 1
EVA_SP1_SHOT_RED_03 	= 2
EVA_SP1_SHOT_RED_04 	= 3
EVA_SP1_SHOT_BLUE_01 	= 4
EVA_SP1_SHOT_BLUE_02 	= 5
EVA_SP1_SHOT_BLUE_03 	= 6
EVA_SP1_SHOT_BLUE_04 	= 7
EVA_SP1_SHOT_GREEN_01 	= 8
EVA_SP1_SHOT_GREEN_02 	= 9
EVA_SP1_SHOT_GREEN_03 	= 10
EVA_SP1_SHOT_GREEN_04 	= 11
EVA_SP1_SHOT_YELLOW_01 	= 12
EVA_SP1_SHOT_YELLOW_02 	= 13
EVA_SP1_SHOT_YELLOW_03 	= 14
EVA_SP1_SHOT_YELLOW_04 	= 15
EVA_SP1_SHOT_ORANGE_01 	= 16
EVA_SP1_SHOT_ORANGE_02 	= 17
EVA_SP1_SHOT_ORANGE_03 	= 18
EVA_SP1_SHOT_ORANGE_04 	= 19

local DrawStoneCircle

function EvaDrawStone(objE, time, color)
    EvaSetStoneElementColor(objE, color)
    EvaSetStoneDrawColor(objE, color)

    local obj = EvaSimpleSprite2D(texture, LAYER_ENEMY, 0, 0)
    objE.sprite = obj
    EvaSetDestRect(obj, 32, -32, -32, 32)
	DrawStoneCircle(objE, time, LAYER_ENEMY + 1, -90, 180)
	DrawStoneCircle(objE, time, LAYER_ENEMY - 1,  90, 180)
    task.New(obj, function ()
        for t = 1, time do
            local RectX = 64 * (EvaGetStoneDrawColor(objE)%4)
            local RectY = 64 * int((EvaGetStoneDrawColor(objE)/4))
            EvaSetSourceRect(obj, RectX, RectY, RectX+64, RectY+64)
            EvaSetPosition(obj, EvaGetX(objE), EvaGetY(objE), 0)
            EvaSetAngleXYZ(obj, 0, 0, EvaGetRot(objE) + 180)
            EvaSetAlpha(obj, 255 * t/time)
            task.Wait()
        end
        EvaSetAlpha(obj, 255)
        while(IsValid(objE))do
            local RectX = 64 * (EvaGetStoneDrawColor(objE)%4)
            local RectY = 64 * int((EvaGetStoneDrawColor(objE)/4))
            EvaSetSourceRect(obj, RectX, RectY, RectX+64, RectY+64)
            EvaSetPosition(obj, EvaGetX(objE), EvaGetY(objE), 0)
            EvaSetAngleXYZ(obj, 0, 0, EvaGetRot(objE) + 180)
            task.Wait()
        end
        Del(obj)
    end)
end

local SetVertexPosition, SetVertexUVT

function DrawStoneCircle(objE, time, priority, arcIni, arc)
    local way = 6
    local renderAng = 0
    local obj = EvaSimplePrimObject_TriangleFan("eva_circle_servant", priority, way + 2)
    EvaSetBlendType(obj, EVA_BLEND_ADD_ARGB)
    task.New(obj, function ()
        for t = 1, time do
            EvaSetPosition(obj, EvaGetX(objE), EvaGetY(objE), 0)
            EvaSetAngleXYZ(obj, 0, 0, EvaGetRot(objE) + 90)
            EvaSetAlpha(obj, 255 * t/60)
            SetVertexPosition(obj, way, arcIni, arc)
            SetVertexUVT(obj, objE, way, arcIni, arc, renderAng)
            renderAng = renderAng - 1
            task.Wait()
        end
        EvaSetAlpha(obj, 255)
        while(IsValid(objE))do
            EvaSetAlpha(obj, objE.sprite.alpha)
            EvaSetPosition(obj, EvaGetX(objE), EvaGetY(objE), 0)
            EvaSetAngleXYZ(obj, 0, 0, EvaGetRot(objE) + 90)
            SetVertexPosition(obj, way, arcIni, arc)
            SetVertexUVT(obj, objE, way, arcIni, arc, renderAng)
            renderAng = renderAng - 1
            task.Wait()
        end
        Del(obj)
    end)
end

function SetVertexPosition(obj, way, arcIni, arc)
    EvaSetVertexPosition(obj, 0, 0, 0, 0)
    for i = 1, way + 1 do
        local a = arcIni + arc*(i - 1)/way
        EvaSetVertexPosition(obj, i, 16 * cos(a), 64 * sin(a), 0)
    end
end

function SetVertexUVT(obj, objE, way, arcIni, arc, renderAng)
    local RectBX = 128 * (EvaGetStoneDrawColor(objE)%4)+64
    local RectBY = 128 * int(EvaGetStoneDrawColor(objE)/4)+64
    local texW, texH = GetTextureSize(obj.texture)
    EvaSetUVT(obj, 0, RectBX/texW, RectBY/texH)
    for i = 1, way + 1 do
        local a = renderAng + arcIni + arc*(i - 1)/way
        EvaSetUVT(obj, i, (RectBX+64*cos(a))/texW, (RectBY+64*sin(a))/texH)
    end
end

function EvaSetStoneDrawColor(objE, color)
    objE["StoneDrawColor"] = color
end

function EvaGetStoneDrawColor(objE)
    return objE["StoneDrawColor"] or EVA_COLOR_WHITE
end

function EvaSetStoneElementColor(objE, color)
    objE["StoneElementColor"] = color
end

function EvaGetStoneElementColor(objE)
    return objE["StoneElementColor"] or EVA_COLOR_WHITE
end
