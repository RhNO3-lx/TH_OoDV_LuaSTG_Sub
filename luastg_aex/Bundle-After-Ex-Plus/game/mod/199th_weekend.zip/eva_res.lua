function EvaLoadAllResource()
    LoadTexture("eva_dummy", "eva_dummy.png")
    LoadTexture("eva_dot_patchouli", "eva_dot_patchouli.png")
    SetTextureSamplerState("eva_dot_patchouli", "point+wrap")
    LoadTexture("eva_dot_alice", "eva_dot_alice.png")
    SetTextureSamplerState("eva_dot_alice", "point+wrap")
    LoadTexture("eva_circle_servant", "eva_circle_servant.png")
    --||||| Effect |||||
    LoadTexture("eva_Effect",       "eva_Effect.png")
    LoadTexture("eva_circle",       "eva_circle.png")
    LoadTexture("eva_circle_1024",  "eva_circle_1024.png")
    LoadTexture("eva_circle_512",   "eva_circle_512.png")
    LoadTexture("eva_circle_256",   "eva_circle_256.png")
    LoadTexture("eva_barrierRing",  "eva_barrierRing.png")
    LoadTexture("eva_patchouli_efc1", "eva_patchouli_efc1.png")
    SetTextureSamplerState("eva_patchouli_efc1", "point+wrap")
    LoadTexture("eva_patchouli_efc2", "eva_patchouli_efc2.png")
    SetTextureSamplerState("eva_patchouli_efc2", "point+wrap")
    --||||| System |||||
    LoadTexture("eva_Hexagram",  "eva_Hexagram.png")
    LoadTexture("eva_MagicCircle",  "eva_MagicCircle.png")
    SetTextureSamplerState("eva_MagicCircle", "linear+wrap")
    LoadTexture("eva_SystemDigit",  "eva_SystemDigit.png")
    SetTextureSamplerState("eva_SystemDigit", "point+wrap")
    LoadTexture("eva_frame", "eva_frame.png")
    SetTextureSamplerState("eva_frame", "point+wrap")
    --||||| Shot |||||
    LoadTexture("eva_bullet_nuclear",  "eva_bullet_nuclear.png")
    LoadTexture("eva_shot",  "eva_shot.png")
    LoadTexture("eva_bbEfc",  "eva_bbEfc.png")
    --||||| Sound |||||
    local snd = {
        "shot1.wav",
        "shot2.wav",
        "shot3.wav",
        "shot4.wav",
        "shot5.wav",
        "shot6.wav",
        "shot7.wav",
        "fire1.wav",
        "fire2.wav",
        "mecha04.wav",
        "nuclear.wav",
        "stop.wav",
        "laser1.wav",
        "laser2.wav",
        "laser3.wav",
        "master.wav",
        "charge1.wav",
        "charge2.wav",
        "charge3.wav",
        "freeze.wav",
        "wolf.wav",
        "boss_vanish.wav",
        "usespellcard.wav",
        "failed.wav",
        "getspellcard.wav",
        "enemy_vanish1.wav",
        "enemy_damage1.wav",
        "enemy_damage2.wav",
    }
    for i = 1, #snd do
        LoadSound("EVA_SE"..(i - 1), snd[i])
    end
    --||||||||| BGM ||||||||||||
    --LoadMusic("EvaBGM01", "eva_bgm06.ogg", 298, 298)
end