---@diagnostic disable: undefined-field
EVA_COLOR_RED 		= 0
EVA_COLOR_GREEN 	= 1
EVA_COLOR_BLUE 		= 2
EVA_COLOR_YELLOW 	= 3
EVA_COLOR_PURPLE 	= 4
EVA_COLOR_AQUA 		= 5
EVA_COLOR_ORANGE 	= 6
EVA_COLOR_WHITE 	= 7

EVA_CArray_Rainbow = {
	EVA_COLOR_RED,
	EVA_COLOR_ORANGE,
	EVA_COLOR_YELLOW,
	EVA_COLOR_GREEN,
	EVA_COLOR_AQUA,
	EVA_COLOR_BLUE,
	EVA_COLOR_PURPLE,
	EVA_COLOR_WHITE
}

EVA_EFFECT_CHERRY 	= 0
EVA_EFFECT_LEAF 	= 1
EVA_EFFECT_FOLIAGE 	= 2
EVA_EFFECT_SNOW 	= 3

function EvaGetColorArray(colorNum)
	local color = {191, 191, 191}
	local val = (colorNum%8)
	if (val == EVA_COLOR_RED)       then color = {255, 95, 95} end
	if (val == EVA_COLOR_GREEN)     then color = { 95,255, 95} end
	if (val == EVA_COLOR_BLUE)      then color = { 95, 95,255} end
	if (val == EVA_COLOR_YELLOW)    then color = {255,255, 63} end
	if (val == EVA_COLOR_PURPLE)    then color = {255, 63,255} end
	if (val == EVA_COLOR_AQUA)      then color = { 63,255,255} end
	if (val == EVA_COLOR_ORANGE)	then color = {255,127, 63} end
	return color
end

function EvaObjRender_SetColor_ColorNum(obj, colorNum)
    local c = EvaGetColorArray(colorNum)
    EvaSetColor(obj, c[1], c[2], c[3])
end

function EvaCreateParticleEffect(pType, prio)
	local obj = EvaSimpleSprite2D("eva_Effect", prio, 0, 0)
	local rectX = 64*(pType%4)
	local rectY = 64*int(pType/4)
	EvaSetSourceRect(obj, rectX, rectY, rectX+64, rectY+64)
	EvaSetDestRect(obj, -32, -32, 32, 32)
	return obj
end

function EvaCherryConcentration(obj, x, y, frame, cNum)
    EvaParticleEffectConcentration(obj, EVA_EFFECT_CHERRY, x, y, frame, EvaGetColorArray(cNum))
end

function EvaLeafConcentration(obj, x, y, frame, cNum)
    EvaParticleEffectConcentration(obj, EVA_EFFECT_LEAF, x, y, frame, EvaGetColorArray(cNum))
end

function EvaFoliageConcentration(obj, x, y, frame, cNum)
    EvaParticleEffectConcentration(obj, EVA_EFFECT_FOLIAGE, x, y, frame, EvaGetColorArray(cNum))
end

function EvaSnowConcentration(obj, x, y, frame, cNum)
    EvaParticleEffectConcentration(obj, EVA_EFFECT_SNOW, x, y, frame, EvaGetColorArray(cNum))
end


local function Particle(pType, x, y, time, colorA)
    local angX = ran:Float(0, 360)
    local angX_r = ran:Float(-12, 12)
    local angY = ran:Float(0, 360)
    local angY_r = ran:Float(-12, 12)
    local angZ = ran:Float(0, 360)
    local angZ_r = ran:Float(-12, 12)

    local alpha = 0
    local acce = ran:Float(0.15, 0.55)
    local ang = ran:Float(0, 360)
    local r = acce*(time^2)/2
    x = x + r*cos(ang)
    y = y + r*sin(ang)

    local obj = EvaCreateParticleEffect(pType, LAYER_ENEMY_BULLET_EF)
    EvaSetBlendType(obj, EVA_BLEND_ADD_ARGB);
	EvaSetAlpha(obj, 153)
	EvaSetColor(obj, colorA[1], colorA[2], colorA[3])
    task.New(obj, function ()
        local t = 15
        while(alpha < 153)do
            alpha = alpha + 153/t
            task.Wait()
		end
		alpha = 153
    end)
    task.New(obj, function ()
        for t = 1, time do
            local rate = 0.25+0.75*t/time
			local scl = 1.50-1.25*t/time
			EvaSetPosition(obj, x, y, 0)
			EvaSetAngleXYZ(obj, angX, angY, angZ)
			EvaSetScaleXYZ(obj, scl, scl, 1.0)
			EvaSetAlpha(obj, alpha)
			x = x - acce*t*cos(ang)
			y = y - acce*t*sin(ang)
			angX = angX + angX_r*rate
			angY = angY + angY_r*rate
			angZ = angZ + angZ_r*rate
            task.Wait()
        end
        Del(obj)
    end)
end

function EvaParticleEffectConcentration(obj, pType, x, y, frame, colorA)
    task.New(obj, function()
        local c = 0
        for _ = 1, frame - 31 do
            c = c + 2.5
            local q = int(c)
            for _ = 1, q do
                Particle(pType, obj.x + x, obj.y + y, 30, colorA)
            end
            c = c - q
            task.Wait()
        end
        EvaRingConcentration(obj.x + x, obj.y + y, 4, colorA)
		for _ = 1, 5 do
			Particle(pType, obj.x + x, obj.y + y, 30, colorA)
        end
    end)
end

function EvaRingConcentration(x, y, last_scale, color)
    local obj = EvaSimpleSprite2D("eva_Effect", LAYER_ENEMY + 1, x, y)
    EvaSetSourceRect(obj, 0, 128, 128, 256)
    EvaSetDestRect(obj, -64, -64, 64, 64)
    EvaSetColor(obj, color[1], color[2], color[3])
    EvaSetBlendType(obj, EVA_BLEND_ADD_ARGB)
    task.New(obj, function()
        for t = 0, 30 do
            local rate = t/30
            EvaSetAlpha(obj, 255 * rate)
            local scl = last_scale*(1-rate)
            EvaSetScaleXYZ(obj, scl, scl, 1.0)
            task.Wait()
        end
        Del(obj)
    end)
end

function EvaCherryExplosion(x, y, l, frame, cNum)
	EvaParticleEffectExplosion(EVA_EFFECT_CHERRY, x, y, l, frame, EvaGetColorArray(cNum))
end

function EvaLeafExplosion(x, y, l, frame, cNum)
	EvaParticleEffectExplosion(EVA_EFFECT_LEAF, x, y, l, frame, EvaGetColorArray(cNum))
end

function EvaFoliageExplosion(x, y, l, frame, cNum)
	EvaParticleEffectExplosion(EVA_EFFECT_FOLIAGE, x, y, l, frame, EvaGetColorArray(cNum))
end

function EvaSnowExplosion(x, y, l, frame, cNum)
	EvaParticleEffectExplosion(EVA_EFFECT_SNOW, x, y, l, frame, EvaGetColorArray(cNum))
end

local function ParticleExp(pType, x, y, time, colorA)
    local angX = ran:Float(0, 360)
    local angX_r = ran:Float(-12, 12)
    local angY = ran:Float(0, 360)
    local angY_r = ran:Float(-12, 12)
    local angZ = ran:Float(0, 360)
    local angZ_r = ran:Float(-12, 12)

    local spd = ran:Float(1.5, 3.5)
    local ang = ran:Float(0, 360)

    local obj = EvaCreateParticleEffect(pType, LAYER_ENEMY_BULLET_EF)
    EvaSetBlendType(obj, EVA_BLEND_ADD_ARGB)
	EvaSetAlpha(obj, 153)
	EvaSetColor(obj, colorA[1], colorA[2], colorA[3])
    task.New(obj, function ()
        for t = time - 1, 1, -1 do
            local rate = t/time
            local s = spd * rate
			local scl = 1.0*rate
			EvaSetPosition(obj, x, y, 0)
			EvaSetAngleXYZ(obj, angX, angY, angZ)
			EvaSetScaleXYZ(obj, scl, scl, 1.0)
			x = x + s*cos(ang)
			y = y + s*sin(ang)
			angX = angX + angX_r*rate
			angY = angY + angY_r*rate
			angZ = angZ + angZ_r*rate
            task.Wait()
        end
        Del(obj)
    end)
end

function EvaParticleEffectExplosion(pType, x, y, l, frame, colorA)
    for _= 1, l do
        ParticleExp(pType, x, y, frame, colorA)
    end
end

function EvaCherryExplosion_Lauge(x, y, frame, cNum)
	EvaParticleEffectExplosion_Lauge(EVA_EFFECT_CHERRY, x, y, frame, EvaGetColorArray(cNum))
end

local EvaParticleEffect_Lauge

function EvaParticleEffectExplosion_Lauge(pType, x, y, frame, colorA)
	local quant = 20
	EvaExplosionB2(x, y, frame, 3.50, colorA)
	EvaExplosionB2(x, y, frame, 5.00, colorA)
	for _= 1, quant do
		EvaParticleEffect_Lauge(pType, x, y, frame+15, colorA)
    end
end

function EvaParticleEffect_Lauge(pType, x, y, time, colorA)
    local angX = ran:Float(0, 360)
    local angX_r = ran:Float(-12, 12)
    local angY = ran:Float(0, 360)
    local angY_r = ran:Float(-12, 12)
    local angZ = ran:Float(0, 360)
    local angZ_r = ran:Float(-12, 12)

    local spd = ran:Float(4, 8)
	local acce = spd/(time+30)
	local ang = ran:Float(0, 360)
	local scale = 2.0

    local obj = EvaCreateParticleEffect(pType, 0.3)
    EvaSetBlendType(obj, EVA_BLEND_ADD_ARGB);
	EvaSetAlpha(obj, 127)
	EvaSetColor(obj, colorA[1], colorA[2], colorA[3])
    task.New(obj, function ()
        for t = time + 29, 30, -1 do
            local rate = t/(time+30)
			EvaSetPosition(obj, x, y, 0)
			EvaSetAngleXYZ(obj, angX, angY, angZ)
			EvaSetScaleXYZ(obj, scale, scale, 1.0)
			x = x + spd*cos(ang)
			y = y + spd*sin(ang)
            spd = spd - acce
			angX = angX + angX_r*rate
			angY = angY + angY_r*rate
			angZ = angZ + angZ_r*rate
            scale = scale - 1.0/time
            task.Wait()
        end
        for t = 29, 0, -1 do
            local rate = t/(time+30)
			EvaSetPosition(obj, x, y, 0)
			EvaSetAngleXYZ(obj, angX, angY, angZ)
			EvaSetScaleXYZ(obj, scale, scale, 1.0)
			x = x + spd*cos(ang)
			y = y + spd*sin(ang)
            spd = spd - acce
			angX = angX + angX_r*rate
			angY = angY + angY_r*rate
			angZ = angZ + angZ_r*rate
            scale = scale - 1.0/30
            task.Wait()
        end
        Del(obj)
    end)
end

function EvaExplosionA1(x, y, dAlpha, dScale)
    EvaExplosionA2(x, y, dAlpha, dScale, {255, 255, 255})
end

function EvaExplosionA2Type(x, y, dAlpha, dScale, cNum)
    EvaExplosionA2(x, y, dAlpha, dScale, EvaGetColorArray(cNum))
end

function EvaExplosionA2(x, y, dAlpha, dScale, color)
    local obj = EvaSimpleSprite2D("eva_Effect", LAYER_ENEMY + 1, x, y)
    EvaSetSourceRect(obj, 129, 129, 191, 191)
    EvaSetDestRect(obj, -31, -31, 31, 31)
    EvaSetColor(obj, color[1], color[2], color[3])
    EvaSetBlendType(obj, EVA_BLEND_ADD_ARGB)
    task.New(obj, function()
        local scale = 0
        local alpha = 255
        while(alpha>0)do
            EvaSetAlpha(obj, alpha)
            EvaSetScaleXYZ(obj, scale, scale, 1.0)
            scale = scale + dScale
            alpha = alpha - dAlpha
            task.Wait()
        end
        Del(obj)
    end)
end

function EvaExplosionB1Type(x, y, frame, last_scale, angle, type)
    EvaExplosionB1(x, y, frame, last_scale, angle, EvaGetColorArray(type))
end

function EvaExplosionB1(x, y, frame, last_scale, angle, color)
    local scale = 0
    local obj = EvaSimpleSprite2D("eva_Effect", LAYER_ENEMY + 1, x, y)
    EvaSetSourceRect(obj, 129, 129, 191, 191)
    EvaSetDestRect(obj, -31, -31, 31, 31)
    EvaSetAngleXYZ(obj, angle[1], angle[2], angle[3])
    EvaSetColor(obj, color[1], color[2], color[3])
    EvaSetBlendType(obj, EVA_BLEND_ADD_ARGB)
    EvaSetPosition(obj, x, y, 0)
    EvaSetAlpha(obj, 255)
    task.New(obj, function()
        for i = 0, frame do
            local alpha = 255*(frame-i)/frame
            EvaSetAlpha(obj, alpha)
            EvaSetScaleXYZ(obj, scale, scale, 1.0)
            scale = last_scale*sin(90*i/frame)
            task.Wait()
        end
        Del(obj)
    end)
end

function EvaExplosionB2Type(x, y, frame, scale, type)
    EvaExplosionB2(x, y, frame, scale, EvaGetColorArray(type))
end

function EvaExplosionB2(x, y, frame, scale, color)
    local scaleR = scale/frame
	local frameC = int(frame/2)
	scale = 0

    local obj = EvaSimpleSprite2D("eva_Effect", LAYER_ENEMY + 1, x, y)
    EvaSetSourceRect(obj, 0, 128, 128, 256)
    EvaSetDestRect(obj, -64, -64, 64, 64)
    EvaSetColor(obj, color[1], color[2], color[3])
    EvaSetBlendType(obj, EVA_BLEND_ADD_ARGB)
    EvaSetPosition(obj, x, y, 0)
    EvaSetAlpha(obj, 255)
    task.New(obj, function()
        for _ = frame, frameC+1, -1 do
            EvaSetScaleXYZ(obj, scale, scale, 1.0)
            scale = scale + scaleR
            task.Wait()
        end
        for i = frameC, 0, -1 do
            local alpha = 255*i/frameC
		    EvaSetAlpha(obj, alpha)
            EvaSetScaleXYZ(obj, scale, scale, 1.0)
            scale = scale + scaleR
            task.Wait()
        end
        Del(obj)
    end)
end

function EvaBulletEffectA1(obj1, obj2, way, rMax, time, scale, alpha, color)
	EvaBulletEffectA2_ColorArray(obj1, 0, 0, obj2, 0, 0, way, rMax, time, scale, alpha, EvaGetColorArray(color))
end


function EvaBulletEffectA2(obj1, x1, y1, obj2, x2, y2, way, rMax, time, scale, alpha, color)
	EvaBulletEffectA2_ColorArray(obj1, x1, y1, obj2, x2, y2, way, rMax, time, scale, alpha, EvaGetColorArray(color))
end

local Effect, Obj_Particle, AI

function Obj_Particle(x, y, blend, scale, alpha, color)
    local obj = EvaSimpleSprite2D("eva_Effect", LAYER_ENEMY + 1, x, y)
    EvaSetBlendType(obj, blend)
    EvaSetSourceRect(obj, 192, 128, 256, 192)
    EvaSetDestRect(obj, -16, -16, 16, 16)
    EvaSetColor(obj, color[1], color[2], color[3])
    EvaSetBlendType(obj, EVA_BLEND_ADD_ARGB)
    EvaSetScaleXYZ(obj, scale, scale, scale)
    EvaSetAlpha(obj, alpha)

    return obj
end

function AI(x, y, ang, scl, AItime, alpha, color)
    local objEfc = Obj_Particle(x, y, EVA_BLEND_ADD_ARGB, scl, alpha/2, color)
    EvaSetPosition(objEfc, x, y, 0)
    EvaSetAngleXYZ(objEfc, 0, 0, ang)
    
    task.New(objEfc, function ()
        for t = AItime - 1, 1, -1 do
            local sc = scl*t/AItime
            EvaSetScaleXYZ(objEfc, sc, sc, sc)
            task.Wait()
        end
        Del(objEfc)
    end)
end

function Effect( twinFlag, angX_, angY_, angZ_, radius, time_, scale, alpha, color, obj1, obj2, quant)
    local way2 = twinFlag and 2 or 1
    local objEfc = {}
    for iW = 0, way2 - 1 do
        objEfc[iW + 1] = Obj_Particle(0, 0, EVA_BLEND_ALPHA, scale, alpha, color)
        EvaSetPosition(objEfc[iW + 1], obj1.X1, obj1.Y1, 0)
    end
    local ang = 0
    task.New(obj1, function ()
        for t = 0, time_ - 1 do
            if(not IsValid(obj1) or not IsValid(obj2)) then break end
            local x, y = EvaRotate2D(cos(angZ_), cos(angX_)*sin(angZ_), angY_)
            local r = radius * sin(180*t/time_)
            local s = scale*(0.5+0.5*sin(90*t/time_))
            local D = 1
            for iW = 0, way2 - 1 do
                local efcX = obj1.X1 + r*x*D
                local efcY = obj1.Y1 + r*y*D
                EvaSetPosition(objEfc[iW + 1], efcX, efcY, 0)
                EvaSetAngleXYZ(objEfc[iW + 1], 0, 0, ang)
                EvaSetScaleXYZ(objEfc[iW + 1], s, s, s)
                AI(efcX, efcY, ang, s, quant, alpha, color)
                D = -D
            end
            angZ_ = angZ_ + 5*(time_-t)/time_
            ang = ang + 24
            task.Wait()
        end
        for i = 1, #objEfc do
            Del(objEfc[i])
        end
    end)
end

function EvaBulletEffectA2_ColorArray(obj1, x1, y1, obj2, x2, y2, way, rMax, time, scale, alpha, color)
    local angX = ran:Float(0, 360)
	local angY = ran:Float(0, 360)
	local angZ = ran:Float(0, 360)
	local X1 = obj1.x + x1
	local Y1 = obj1.y + y1
    obj1.X1 = X1
    obj1.Y1 = Y1
    local quant = 4 --或者12

    if(way%2 == 0)then
		for iW = 0, way/2 - 1 do
			Effect( true, angX, angY, angZ+360*iW/way, rMax, time, scale, alpha, color, obj1, obj2, quant)
        end
	else
		for iW = 0, way - 1 do
			Effect( false, angX, angY, angZ+360*iW/way, rMax, time, scale, alpha, color, obj1, obj2, quant)
        end
	end

    task.New(obj1, function ()
        for t = 0, time - 10 do
            if not IsValid(obj2) then Del(obj1) break end
            local X2 = obj2.x + x2
            local Y2 = obj2.y + y2
            X1 = X1 + (X2 - X1) * 0.1 * (1-cos(90*t/(time-10)))
            Y1 = Y1 + (Y2 - Y1) * 0.1 * (1-cos(90*t/(time-10)))
            obj1.X1 = X1
            obj1.Y1 = Y1
            task.Wait()
        end
        for t = 1, 10 do
            if not IsValid(obj2) then Del(obj1) break end
            local X2 = obj2.x + x2
            local Y2 = obj2.y + y2
            X1 = X1 + (X2-X1)*(1-cos(90*t/10))
            Y1 = Y1 + (Y2-Y1)*(1-cos(90*t/10))
            obj1.X1 = X1
            obj1.Y1 = Y1
            task.Wait()
        end
    end)
end

function EvaEffect_LaserWarning(x, y, ang, r, qnt, color)
    EvaEffect_LaserWarning3_ColorArray(x, y, ang, r, 800, qnt, 30, 127, EvaGetColorArray(color))
end

function EvaEffect_LaserWarning2(x, y, ang, wid, leng, qnt, alpha, color)
    EvaEffect_LaserWarning3_ColorArray(x, y, ang, wid, leng, qnt, 30, alpha, EvaGetColorArray(color))
end

function EvaEffect_LaserWarning3(x, y, ang, wid, leng, qnt, time, alpha, color)
    EvaEffect_LaserWarning3_ColorArray(x, y, ang, wid, leng, qnt, time, alpha, EvaGetColorArray(color))
end

local Effect2

function Effect2(x, y, ang, leng, time, alpha, cArray)
    local obj = EvaSimpleSprite2D("eva_shot", LAYER_ENEMY_BULLET_EF, x, y)
    EvaSetBlendType(obj, EVA_BLEND_ADD_ARGB)
    local Rect = EvaGetShotDataInfoA1(ADD_BGW_BEAM_ST_WHITE, EVA_INFO_RECT)
    EvaSetSourceRect(obj, Rect[1], Rect[2], Rect[3], Rect[4])
    EvaSetDestRect(obj, -1, leng, 1, 0)
    EvaSetPosition(obj, x, y, 0)
    EvaSetAngleXYZ(obj, 0, 0, -ang+90)
    EvaSetColor(obj, cArray[1], cArray[2], cArray[3])
    EvaTask(function ()
        for i = time, 1, -1 do
            EvaSetAlpha(obj, alpha*i/time)
            EvaWait()
        end
        Del(obj)
    end)
end

function EvaEffect_LaserWarning3_ColorArray(x, y, ang, wid, leng, qnt, time, alpha, cArray)
    EvaTask(function ()
        for iQ = 1, qnt do
            local r2 = wid*sin(90*iQ/qnt)/2
            Effect2(x+r2*cos(ang+90), y+r2*sin(ang+90), ang, leng, time, alpha, cArray)
            Effect2(x+r2*cos(ang-90), y+r2*sin(ang-90), ang, leng, time, alpha, cArray)
            task.Wait()
        end
    end)
end

function EvaCircleEffect_INI(Priority)
	local obj = EvaSimpleSprite2D("eva_circle", Priority, 0, 0)
	EvaSetBlendType(obj, EVA_BLEND_ADD_ARGB)
	EvaSetSourceRect(obj, 1024, 0, 2048, 1024)
	EvaSetDestRect(obj, -512, -512, 512, 512)
	return obj
end

function EvaCircleEffect_SetScareToRadius(obj, r)
	EvaSetScaleXYZ(obj, r/512, r/512, 1.0)
end

function EvaCircleEffect_SetScareToRadius2(obj, rX, rY)
	EvaSetScaleXYZ(obj, rX/512, rY/512, 1.0)
end

function EvaRingEffect_INI(Priority)
	local obj = EvaSimpleSprite2D("eva_circle", Priority, 0, 0)
	EvaSetSourceRect(obj, 0, 0, 1024, 1024)
	EvaSetDestRect(obj, -512, -512, 512, 512)
	return obj
end

function EvaRingEffect_SetScareToRadius(obj, r)
	EvaCircleEffect_SetScareToRadius(obj, r)
end

function EvaRingEffect_SetScareToRadius2(obj, rX, rY)
	EvaCircleEffect_SetScareToRadius2(obj, rX, rY)
end

function EvaShakeSTGFrame(r, time)
    misc.ShakeScreen(time, r)
end