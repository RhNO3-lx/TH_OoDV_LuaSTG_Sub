local SPELLCARD_LEFT_PATH   = 'Trestone_Resources\\Others\\Trestone_Cardleft.png'
local BOSSMARK_PATH         = 'Trestone_Resources\\Others\\Trestone_Mark.png'
local ATTACK_RING_PATH      = 'Trestone_Resources\\Others\\Trestone_BossRing.png'

LoadTexture("boss_sc_left", SPELLCARD_LEFT_PATH)
LoadTexture("boss_mark", BOSSMARK_PATH)
LoadTexture("boss_att_ring", ATTACK_RING_PATH )

LoadImage("boss_left_star", "boss_sc_left", 0, 0, 32, 32)
LoadImage("boss_mark_point", "boss_mark", 0, 0, 65, 16)
LoadImageGroup("boss_att_ring1", "boss_att_ring", 80, 0, 16, 8, 1, 16)
for i = 1, 16 do
    SetImageState("boss_att_ring1" .. i, "mul+add", Color(0x80FFFFFF))
end
LoadImageGroup("boss_att_ring2", "boss_att_ring", 48, 0, 16, 8, 1, 16)
for i = 1, 16 do
    SetImageState("boss_att_ring2" .. i, "mul+add", Color(0x80FFFFFF))
end

--boss 信息板
function Trestone_BossInfo_Apply(target, lcount)
    target.Trestone_BossInfo = New(Trestone_BossInfo, target, lcount)
end

Trestone_BossInfo = Class(object)
function Trestone_BossInfo:init(target, lcount)
    self.ui = target.ui
    if target.__hpbartype2 and int(target.__hpbartype2 / 10) == 2 then
        self.x, self.y = -185, lstg.world.t - 10
    else
        self.x, self.y = -185, lstg.world.t
    end
    self.t = 0
    self.mt = 15
    self.txtaph = 0
    self.staraph = 0
    self.lcount = lcount
    self.stardx = 15
    self.stardy = 15
    self.target = target
    self.layer = LAYER_TOP + 3
end

function Trestone_BossInfo:frame()
    local _ui = self.ui
    local boss = self.target
    if not (IsValid(boss)) then
        return
    end

    local tm = self.timer
    if tm <= 60 then
        local aph = math.rad(tm * 90 / 60)
        self.txtaph = math.sin(aph) * 255
    elseif tm <= 120 then
        local aph = math.rad((tm - 60) * 90 / 60)
        self.staraph = math.sin(aph) * 255
    end

    local x, y
    if boss.__hpbartype2 and int(boss.__hpbartype2 / 10) == 2 then
        x, y = -185, lstg.world.t - 10
    else
        x, y = -185, lstg.world.t
    end
    if _ui.drawhp and _ui.hpbar and _ui.hpbar._mode ~= -1 and ui.lstg_weekly then
        y = y - 20
    end
    local xx,yy = self.x, self.y
    self.x = self.x + (x - xx) * 0.10
    self.y = self.y + (y - yy) * 0.10
    local bscl = boss.sc_left
    if self.sc_left == nil then
        self.sc_left = bscl
    end
    if self.sc_left > bscl then
        self.t = self.t + self.mt * (self.sc_left - bscl)
        self.sc_left = bscl
    end
    if self.t > 0 then
        self.t = self.t - 1
    end
end

function Trestone_BossInfo:render()
    local boss =  self.target
    if not (IsValid(boss)) then
        return
    end
    local dy = (boss.ui_slot - 1) * 44
    local x, y = self.x, self.y - dy
    local anisc = int(self.t / self.mt)
    local sc_left = self.sc_left + anisc
    RenderTTF('boss_name', boss.name, x, x, y, y, Color(self.txtaph, 0, 0, 0), "noclip")
    x = x - 1
    y = y + 1
    RenderTTF('boss_name', boss.name, x, x, y, y, Color(self.txtaph, 147, 202, 104), "noclip")
    local lcount = self.lcount
    local sdx, sdy = self.stardx, self.stardy
    local m = int((sc_left - 1) / 8)
    local m2 = sc_left - 1 - 8 * m
    x = self.x - 8
    y = self.y - 22 - dy
    if m >= 0 then
        SetImageState("boss_left_star", "", Color(self.staraph, 255, 255, 255))
        for i = 0, m - 1 do
            for j = 1, lcount do
                Render('boss_left_star', x + j * sdx, y - i * sdy, 0, 0.5)
            end
        end
        y = y - m * sdy
        for i = 1, m2 do
            Render("boss_left_star", x + i * sdx, y, 0, 0.5)
        end
        local t, at, x2, y2
        t = self.mt - (self.t - anisc * self.mt)
        at = self.mt
        if self.t > 0 then
            x2 = x + (m2 + 1) * sdx
            y2 = y
            SetImageState("boss_left_star", "",
                    Color(255 * (1 - (t / at)), 255, 255, 255))
            Render("boss_left_star", x2, y2, 0, 0.5 + (t / at) * 0.5)
        end
    end
end

--boss 法阵
function Trestone_Boss_Magic_Apply(target, tm)
    target.Trestone_Boss_Magic = New(Trestone_Boss_Magic, target, tm)
end

Trestone_Boss_Magic = Class(object)
function Trestone_Boss_Magic:init(target, tm)
    self.target = target
    self.layer = LAYER_ENEMY - 2
    self.bound = false

    self.x, self.y = target.x, target.y
    self.current_aph = self._aph

    self.t = 0
    self.tm = max(1, tm or 60)
    self.range = 0

    self.size = 1
    self.swing = 0
    self._aph = 128
    self.current_aph = self._aph
end

function Trestone_Boss_Magic:frame()
    local boss = self.target
    if IsValid(boss) then
        self.x = boss.x
        self.y = boss.y
    else
        Del(self)
        return
    end

    self.swing = self.swing + 0.005
    self.size = 1 + 0.05 * math.sin(self.swing)

    local now_open = (boss.magichide ~= true)

    if now_open then
        self.t = math.min(self.tm, self.t + 1)
    else
        self.t = math.max(0, self.t - 1)
    end

    local progress = math.rad(self.t / self.tm * 90)
    self.range = math.sin(progress)

    if boss.timespell == true then
        self.current_aph = math.max(self._aph / 2, self.current_aph - self._aph / 120)
    else
        self.current_aph = math.min(self._aph, self.current_aph + self._aph / 120)
    end
end

function Trestone_Boss_Magic:render()
    local boss = self.target
    if not IsValid(boss) then
        return
    end

    local size = self.size * self.range * (boss.aura_scale or 1)
    if size <= 0 then return end

    for i = 1, 25 do
        SetImageState("boss_aura_3D" .. i, "mul+add", Color(self.current_aph, 255, 255, 255))
    end
    Render("boss_aura_3D" .. boss.ani % 25 + 1, boss.x, boss.y, boss.ani * 0.75,
            0.92 * size, (0.8 + 0.12 * sin(90 + boss.ani * 0.75)) * size)
    for i = 1, 25 do
        SetImageState("boss_aura_3D" .. i, "mul+add", Color(128, 255, 255, 255))
    end
end

--boss标记
function Trestone_Boss_Mark_Apply(target)
    target.Trestone_Boss_Mark = New(Trestone_Boss_Mark, target)
end

Trestone_Boss_Mark = Class(object)

function Trestone_Boss_Mark:init(target)
    self.layer = LAYER_TOP + 5
    self.group = GROUP_GHOST
    self.target = target
    self.bound = false
    self.EnemyIndicater = 255
    self.scale = 1

    self.fade_timer = 0
    self.fade_total = 0
    self.was_hidden = false
    self.appear_count = 0
end

function Trestone_Boss_Mark:frame()
    self.y = lstg.world.b - 8
    local b = self.target
    if not (IsValid(b)) then
        return
    end

    if self.appear_count < 60 then
        self.appear_count = self.appear_count + 1
    end

    local should_hide = b.markhide or b.hp <= 0

    if should_hide ~= self.was_hidden then
        self.was_hidden = should_hide
        self.fade_timer = 0
        self.fade_total = 20
    elseif self.fade_timer < self.fade_total then
        self.fade_timer = self.fade_timer + 1
    end

    if b.hp >= 0 then
        self.EnemyIndicater = self.EnemyIndicater + (max(0, (b.maxhp / 2 - b.hp))) / (b.maxhp / 2) * 90
    end
end

function Trestone_Boss_Mark:render()
    local b = self.target
    if not (IsValid(b)) then
        return
    end

    local fade_ratio = 1.0

    if self.appear_count < 60 then
        fade_ratio = self.appear_count / 60
    else
        if self.fade_total > 0 then
            local progress = min(self.fade_timer / self.fade_total, 1.0)
            if self.was_hidden then
                fade_ratio = 1.0 - progress
            else
                fade_ratio = progress
            end
        else
            fade_ratio = self.was_hidden and 0 or 1
        end
    end

    if fade_ratio <= 0 then
        return
    end

    local w = lstg.world
    local scale = self.scale
    SetRenderRect(w.l, w.r, w.b - max(16 * scale, 0), w.t,
                  w.scrl, w.scrr, w.scrb - max(16 * scale, 0), w.scrt)

    local x, y = b.x, self.y
    local distsub = 1
    local players
    if Players then
        players = Players(b)
    else
        players = { player }
    end
    for _, p in pairs(players) do
        if IsValid(p) then
            distsub = min((1 - (min(abs(x - p.x), 64) / 128)), distsub)
        end
    end

    local hpsub = (sin(self.EnemyIndicater + 270) + 1) * 0.125
    local base_alpha = (1 - distsub * 0.6 - hpsub)
    local final_alpha = base_alpha * fade_ratio * 255
    final_alpha = max(0, min(255, final_alpha))

    SetImageState("boss_mark_point", "", Color(final_alpha, 255, 255, 255))
    Render("boss_mark_point", x, y, 0, self.scale)
    SetViewMode "world"
end

--boss 符卡环
function Trestone_Boss_Attack_Ring_Apply(target, _aph, range)
    target.Trestone_Boss_Attack_Ring = New(Trestone_Boss_Attack_Ring, target, _aph, range)
end

Trestone_Boss_Attack_Ring = Class(object)
function Trestone_Boss_Attack_Ring:init(target, _aph, range)
    self.target = target
    self.layer = LAYER_ENEMY - 1
    self.bound = false

    self.x, self.y = target.x, target.y
    self._aph = min(_aph or 144, 144)
    self.range = range or 164
    self.current_aph = self._aph
end

function Trestone_Boss_Attack_Ring:frame()
    local boss = self.target

    if IsValid(boss) then
        self.x = boss.x
        self.y = boss.y
    else
        Del(self)
        return
    end

    if boss.timespell == true then
        self.current_aph = math.max(self._aph / 2, self.current_aph - self._aph / 120)
    else
        self.current_aph = math.min(self._aph, self.current_aph + self._aph / 120)
    end

    if boss.ringkill == true then
        Del(self)
    end
end

function Trestone_Boss_Attack_Ring:render()
    local boss = self.target
    if not IsValid(boss) then
        Del(self)
        return
    end
    SetViewMode"world"
    local extend_rate = 1 + 16 / 60
    local alpha = min(self.current_aph, self.timer*1.5)
    local exr1 = -0.5
    local bold = 2
    local main_radius = self.range
    local timer, rov, cut, flag = _boss.timer, 4, 48, 1
    local pause = ext.pause_menu
    if pause and pause.IsKilled and pause:IsKilled() then
	    pause = false
    end
    local ringx = boss._sc_ring_x or boss.x
    local ringy = boss._sc_ring_y or boss.y
    if not pause then
	    local minspeed = self._sc_ring_minspeed or 0.5
	    local ratespeed = self._sc_ring_ratespeed or 0.08
	    local speed = Dist(ringx, ringy, boss.x, boss.y)
	    local angle = Angle(ringx, ringy, boss.x, boss.y)
	    speed = min(speed, max(speed * ratespeed, minspeed))
	    ringx = ringx + speed * cos(angle)
	    ringy = ringy + speed * sin(angle)
    end
    boss._sc_ring_x = ringx
    boss._sc_ring_y = ringy
    if not _boss.__is_waiting and _boss.__draw_sc_ring then
	    for i = 1, 16 do
			SetImageState('boss_att_ring1' .. i, 'mul+add', Color(alpha, 255, 255, 255))
	    end
    if timer < 90 then
	    if boss.fxr and boss.fxg and boss.fxb then
		    local of = 1 - timer / 180
		    for i = 1, 16 do
		        SetImageState('boss_att_ring2' .. i, 'mul+add',
		                Color(1.9 * alpha, boss.fxr * of, boss.fxg * of, boss.fxb * of))
	        end
	    else
		    for i = 1, 16 do
			    SetImageState('boss_att_ring2' .. i, 'mul+add',Color(alpha, 255, 255, 255))
		    end
	    end
	    misc.RenderRing('boss_att_ring1', ringx, ringy,
	    timer * (main_radius / 90) + main_radius * 1.5 * sin(timer * 2) + 14 + exr1 + bold,
	    timer * (main_radius / 90) + main_radius * 1.5 * sin(timer * 2) - 2 + exr1,
	            -boss.ani * rov, cut, 16)
	    misc.RenderRing('boss_att_ring2', ringx, ringy,
	            90 + ((main_radius - 90) / 90) * timer + 4,
	            -main_radius + (1 - cos(timer) ^ 2) * (main_radius * 2 - 12) - bold,
	            boss.ani * rov, cut, 16)
	    else
		    if boss.fxr and boss.fxg and boss.fxb then
			    for i = 1, 16 do
				    SetImageState('boss_att_ring2' .. i, 'mul+add',Color(1.9 * alpha, boss.fxr / 2, boss.fxg / 2, boss.fxb / 2))
			    end
		    else
			    for i = 1, 16 do
				    SetImageState('boss_att_ring2' .. i, 'mul+add',Color(alpha, 255, 255, 255))
			    end
		    end
	    local t = _boss.t3 * extend_rate
	    misc.RenderRing('boss_att_ring1', ringx, ringy,
	            (t - timer * 1.08) / (t - 90) * main_radius + 14 + exr1 + bold,
	            (t - timer * 1.08) / (t - 90) * main_radius - 2 + exr1,
	            -boss.ani * rov, cut, 16)
	    misc.RenderRing('boss_att_ring2', ringx, ringy,
	            (t - timer) / (t - 90) * main_radius + 4,
	            (t - timer) / (t - 90) * main_radius - 12 - bold,
	            boss.ani * rov, cut, 16)
	    end
    end
end