hakureishrine_background = Class(background)

local GROUND_PATH       = 'Trestone_Resources\\Background\\HakureiShrineGround.png'
local SAKURA1_PATH      = 'Trestone_Resources\\Background\\HakureiShrineSakura1.png'
local SAKURA2_PATH      = 'Trestone_Resources\\Background\\HakureiShrineSakura2.png'
local SAKURA3_PATH      = 'Trestone_Resources\\Background\\HakureiShrineSakura3.png'
local CHERRY_PATH       = 'Trestone_Resources\\Background\\HakureiShrineCherry.png'

local INIT_EYE_X, INIT_EYE_Y, INIT_EYE_Z 		= 0, 2.8, 0.5
local INIT_AT_X, INIT_AT_Y, INIT_AT_Z    		= 0, 0, 2.9               -- 0, 0, 2.8
local INIT_UP_X, INIT_UP_Y, INIT_UP_Z    		= 0, 1, 0
local INIT_Z_NEAR, INIT_Z_FAR            		= 0.1, 15
local INIT_FOVY                          		= 0.68                  -- 0.60
local INIT_FOG_IN, INIT_FOG_OUT                 = 0, 2                  -- 2.5, 7
local INIT_RED, INIT_GREEN, INIT_BLUE           = 20, 0, 20             -- 180, 30, 150

function hakureishrine_background:init()
    background.init(self, false)

    LoadImageFromFile('ground', GROUND_PATH)
    LoadImageFromFile('sakura1', SAKURA1_PATH)
    LoadImageFromFile('sakura2', SAKURA2_PATH)
    LoadImageFromFile('sakura3', SAKURA3_PATH)
    LoadImageFromFile('cherry', CHERRY_PATH)

    Set3D('eye', INIT_EYE_X, INIT_EYE_Y, INIT_EYE_Z)
    Set3D('at', INIT_AT_X, INIT_AT_Y, INIT_AT_Z)
    Set3D('up', INIT_UP_X, INIT_UP_Y, INIT_UP_Z)
    Set3D('z', INIT_Z_NEAR, INIT_Z_FAR)
    Set3D('fovy', INIT_FOVY)
    Set3D('fog', INIT_FOG_IN, INIT_FOG_OUT, Color(255, INIT_RED, INIT_GREEN, INIT_BLUE))

    self.zos = 0
    self.speed = 0.002      -- 0.012
    self.sakuraph = 0
    self.slant = 0
end

function hakureishrine_background:frame()
    local tm = self.timer
    self.zos = self.zos + self.speed

    if ext.sc_pr then
        self.speed = 0.012
        SetImageState('sakura1', '', Color(255, 255, 255, 255))
        SetImageState('sakura2', '', Color(255, 255, 255, 255))
        SetImageState('sakura3', '', Color(255, 255, 255, 255))
        Set3D('fovy', INIT_FOVY - 0.08)
        Set3D('fog', INIT_FOG_IN + 2.5, INIT_FOG_OUT + 5, Color(255, INIT_RED + 160, INIT_GREEN + 30, INIT_BLUE + 130))
        self.slant = self.slant + 0.08
        local sl = sin(self.slant)
        Set3D('eye', INIT_EYE_X + 0.2 * sl, INIT_EYE_Y + 0.05 * sl, INIT_EYE_Z)
        Set3D('at', INIT_AT_X + 0.3 * sl, INIT_AT_Y, INIT_AT_Z + 0.3)
        Set3D('up', INIT_UP_X - 0.1 * sl, INIT_UP_Y, INIT_UP_Z)
    else
        if tm <= 750 then
            local progress = math.rad(90 * tm / 750)
        	local s = math.sin(progress)
            self.sakuraph = s * 255
            SetImageState('sakura1', '', Color(min(255, self.sakuraph * 1.2), 255, 255, 255))
            SetImageState('sakura2', '', Color(min(255, self.sakuraph * 1.2), 255, 255, 255))
            SetImageState('sakura3', '', Color(min(255, self.sakuraph * 1.2), 255, 255, 255))
            self.speed = 0.003 + 0.009 * s
            Set3D('at', INIT_AT_X, INIT_AT_Y, INIT_AT_Z + 0.3)
            Set3D('fovy', INIT_FOVY - 0.08 * s)
            Set3D('fog', INIT_FOG_IN + 2.5 * s, INIT_FOG_OUT + 5 * s, Color(255, INIT_RED + 160 * s, INIT_GREEN + 30 * s, INIT_BLUE + 130 * s))
        else
            self.slant = self.slant + 0.08
            local sl = sin(self.slant)
            Set3D('eye', INIT_EYE_X + 0.2 * sl, INIT_EYE_Y + 0.05 * sl, INIT_EYE_Z)
            Set3D('at', INIT_AT_X + 0.3 * sl, INIT_AT_Y, INIT_AT_Z + 0.3)
            Set3D('up', INIT_UP_X - 0.1 * sl, INIT_UP_Y, INIT_UP_Z)
        end
    end

    if tm % 60 == 0 and tm > 5 then
		for i = 1, int(math.random(2, 4)) do
			local size = 0.06 + math.random() *(0.12 - 0.06)
			local x = math.random(-200, 200)
			local y = math.random(360, 280)
			local aph = math.min(250 + 90 * (size - 1), math.min(tm / 1.5, 160))
            local red, green, blue = 255, 136, 238
			if ext.sc_pr then
                aph = 250 + 90 * (size - 1)
            end
			New(shrine_cherry, x, y, size, aph, red, green, blue)
		end
	end
end

function hakureishrine_background:render()
    SetViewMode('3d')
    if not self.hide then
        background.WarpEffectCapture()
    end
    background.ClearToFogColor()

    for j = 0, 10 do
        local size = 2
        local dz = j * size - math.fmod(self.zos * 0.9, size)
        Render4V('ground',  -size, -0.1, dz + size,
                            size, -0.1, dz + size,
                            size, -0.1, dz,
                            -size, -0.1, dz)
    end

    for j = 0, 10 do
        local size = 3
        local dz = j * size - math.fmod(self.zos * 0.95, size)
        Render4V('sakura1',  size*(-0.5), 0, dz + size,
                             0, 0, dz + size,
                             0, 0, dz,
                             size*(-0.5), 0, dz)
        Render4V('sakura1',  size*(0.5), 0, dz + size,
                             0, 0, dz + size,
                             0, 0, dz,
                             size*(0.5), 0, dz)
    end

    for j = 0, 10 do
        local size = 3
        local dz = j * size - math.fmod(self.zos, size)
        Render4V('sakura2',  size*(-0.51), 0.1, dz + size,
                             size*(-0.01), 0.1, dz + size,
                             size*(-0.01), 0.1, dz,
                             size*(-0.51), 0.1, dz)
        Render4V('sakura2',  size*(0.51), 0.1, dz + size,
                             size*(0.01), 0.1, dz + size,
                             size*(0.01), 0.1, dz,
                             size*(0.51), 0.1, dz)
    end

    for j = 0, 10 do
        local size = 3
        local dz = j * size - math.fmod(self.zos * 1.05, size)
        Render4V('sakura3',  size*(-0.52), 0.2, dz + size,
                             size*(-0.02), 0.2, dz + size,
                             size*(-0.02), 0.2, dz,
                             size*(-0.52), 0.2, dz)
        Render4V('sakura3',  size*(0.52), 0.2, dz + size,
                             size*(0.02), 0.2, dz + size,
                             size*(0.02), 0.2, dz,
                             size*(0.52), 0.2, dz)
    end

    if not self.hide then
        background.WarpEffectApply()
    end
    SetViewMode('world')
end

shrine_cherry = Class(object)
function shrine_cherry:init(x, y, size, aph, red, green, blue)
	self.x = x
	self.y = y
	self.img = 'cherry'
	self.size = size
	self.hscale = size
	self.vscale = size
	self.group = GROUP_GHOST
	self.omiga = -1.2 + math.random() * 0.6
	self.layer = LAYER_BG + size
	self._aph = aph
	self._alpha = aph
	self._red = red
	self._green = green
	self._blue = blue
	self.color = Color(aph, red, green, blue)
	self._vx = 1 + math.random() * 0.7
	self.bound = false
	self.vx = -0.3 + math.random() * 0.6
	self.vy = -1.1 + math.random() * 1.5
end
function shrine_cherry:frame()
	task.Do(self)
    if IsValid(_boss) and _boss.cards[_boss.card_num] and _boss.cards[_boss.card_num].is_sc and _boss.is_combat then
        self._aph = max(0, self._aph - 20)
		self.color = Color(self._aph, self._red, self._green, self._blue)
    else
        self._aph = min(self._alpha, self._aph + 10)
		self.color = Color(self._aph, self._red, self._green, self._blue)
    end
	self._alpha = max(0, self._alpha - 0.4)
	self.hscale = self.hscale + self.size / 100
	self.vscale = self.vscale + self.size / 100
	if self._alpha <= 0 then Del(self) end
end

function shrine_cherry:render()
	SetImageState(self.img, "mul+add", self.color)
	SetViewMode"world"
	object.render(self)
	SetImageState(self.img, "mul+add", Color(255,255,255,255))
end