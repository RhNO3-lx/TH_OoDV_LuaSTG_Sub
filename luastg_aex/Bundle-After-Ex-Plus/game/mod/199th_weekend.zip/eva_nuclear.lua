local tex = "eva_bullet_nuclear"
local wait = task.Wait
function ExplosiveFlameSetA1(x, y, r, alpha, color)
	local objS = EvaExplosiveFlameSetA2(x, y, r, 15, alpha, color)
	return objS
end

local Move
local ColorManage

function EvaExplosiveFlameSetA2(x, y, r, iniTime, alpha, color)
    local objS =  EvaCreateShotA1(x,y,0,0,ADD_BGW_BALL_S_RED + color, 0)
    objS["Nuclear_R"] = r
    objS["Nuclear_Color"] = color
    objS["Nuclear_Delete_Flag"] = false
    objS.hide = true
    objS.colli = false
    Move(objS, alpha, iniTime)
    return objS
end

function Move(objS, alpha, iniTime)
    local objEfc = EvaSimpleSprite2D(tex, LAYER_ENEMY_BULLET, objS.x, objS.y)
    local RectAng = 0
    objS["Nuclear_Effect_Obj_ID"] = objEfc
    EvaSetBlendType(objEfc, EVA_BLEND_ADD_ARGB)
    EvaSetScaleXYZ(objEfc, 0, 0, 1)
    ColorManage(objS, objEfc)
    EvaSetAlpha(objEfc, alpha)
    local r = 0
    EvaTask(function ()
        for t = 1, iniTime do
            if not IsValid(objS) then break end
            r = objS["Nuclear_R"] or 0
            local SIN = sin(90*t/iniTime)
            local scale = (r+2*(t%2))/112*SIN
            EvaSetPosition(objEfc, objS.x, objS.y, 0)
            EvaSetAngleXYZ(objEfc, 0, 0, RectAng)
            EvaSetScaleXYZ(objEfc, scale, scale, 1)
            EvaSetIntersectionCircle(objS, r * SIN)
            RectAng = RectAng - 0.4
            wait()
        end
        local t = iniTime + 1
        while(not objS["Nuclear_Delete_Flag"])do
            if(not IsValid(objS)) then break end
			r = objS["Nuclear_R"]
			local scale = (r+2*(t%2))/112
			EvaSetScaleXYZ(objEfc, scale, scale, 1)
			EvaSetIntersectionCircle(objS, r)
			EvaSetPosition(objEfc, objS.x, objS.y, 0)
			EvaSetAngleXYZ(objEfc, 0, 0, RectAng)
			RectAng = RectAng - 0.4
			t = t + 1
			wait()
        end
        if(not IsValid(objS)) then
            local finTime = 15
            for tt = finTime - 1, 1, -1 do
                local SIN = sin(90*tt/finTime)
                local scale = (r+10+3*(tt%2))/128*SIN
                EvaSetScaleXYZ(objEfc, scale, scale, 1)
                if(IsValid(objS)) then
                    EvaSetPosition(objEfc, objS.x, objS.y, 0)
                end
                wait()
            end
            Del(objEfc)
        end
    end)
end

function ColorManage(objS, objEfc)
    local CurrentColor = objS["Nuclear_Color"] or EVA_COLOR_RED
    local RectX = 256*(CurrentColor%4)
    local RectY = 256*int(CurrentColor/4)
    local RectW = 256
    local RectH = 256
    EvaSetSourceRect(objEfc, RectX, RectY, RectX + RectW, RectY + RectH)
    EvaSetDestRect(objEfc, -128, -128, 128, 128)
    EvaTask(function ()
        while(not IsValid(objS)) do
            if(objS["Nuclear_Color"] ~= CurrentColor) then
                CurrentColor = objS["Nuclear_Color"] or EVA_COLOR_RED
                RectX = 256*(CurrentColor%4)
                RectY = 256*int(CurrentColor/4)
                EvaSetSourceRect(objEfc, RectX, RectY, RectX + RectW, RectY + RectH)
            end
            wait()
        end
    end)
end

function EvaExplosiveFlameDeleteA1(objS)
    EvaExplosiveFlameDeleteA2(objS, 15)
end

function EvaExplosiveFlameDeleteA2(objS, finTime)
    local objEfc = objS["Nuclear_Effect_Obj_ID"] or -1
    local r = objS["Nuclear_R"] or 0
    objS["Nuclear_Delete_Flag"] = true
    EvaTask(function ()
        for t = finTime - 1, 1, -1 do
            local SIN = sin(90*t/finTime)
            local scale = (r+10+3*(t%2))/128*SIN
            EvaSetScaleXYZ(objEfc, scale, scale, 1.0)
            if(IsValid(objS)) then
                EvaSetPosition(objEfc, objS.x, objS.y, 0)
            end
            wait()
        end
        Del(objS)
        Del(objEfc)
    end)
end

function EvaExplosiveFlameA1(x, y, r, time, alpha, color)
    local objS = EvaExplosiveFlameA2(x, y, r, 15, time, 15, alpha, color)
	return objS
end

local Move2

function EvaExplosiveFlameA2(x, y, r, iniTime, time, finTime, alpha, color)
    time = max(time, iniTime)
    local objS = EvaExplosiveFlameSetA2(x, y, r, iniTime, alpha, color)
	Move(objS, time, finTime)
	return objS
end

function Move2(objS, time, finTime)
    EvaTask(function ()
        wait(time)
        EvaExplosiveFlameDeleteA2(objS, finTime)
    end)
end

function EvaSetNuclearR(objS, r)
    objS["Nuclear_R"] = r
end

function EvaGetNuclearR(objS)
    return objS["Nuclear_R"] or 0
end

function EvaSetNuclearColor(objS, color)
    objS["Nuclear_Color"] = color
end

function EvaGetNuclearColor(objS)
    return objS["Nuclear_Color"] or EVA_COLOR_RED
end