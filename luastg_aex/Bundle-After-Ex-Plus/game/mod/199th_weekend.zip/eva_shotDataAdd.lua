---@diagnostic disable: undefined-field
local data = {}
local data_n = 1

function EvaNewShotData(tab)
    data[data_n] = tab
    data_n = data_n + 1
end


----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　BALL_S　丸弾
	
	--　黒透過
	EvaNewShotData{	id = 401		,rect = {0,112,16,128}		,delay_color = {255,32,32}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	EvaNewShotData{	id = 402		,rect = {16,112,32,128}		,delay_color = {32,255,32}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	EvaNewShotData{	id = 403		,rect = {32,112,48,128}		,delay_color = {32,32,255}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	EvaNewShotData{	id = 404		,rect = {48,112,64,128}		,delay_color = {255,255,32}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	EvaNewShotData{	id = 405		,rect = {64,112,80,128}		,delay_color = {255,32,255}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	EvaNewShotData{	id = 406		,rect = {80,112,96,128}		,delay_color = {32,255,255}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	EvaNewShotData{	id = 407		,rect = {96,112,112,128}		,delay_color = {255,128,32}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	EvaNewShotData{	id = 408		,rect = {112,112,128,128}	,delay_color = {255,255,255}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	
	--　黒透過ナシ
	EvaNewShotData{	id = 409		,rect = {128,112,144,128}	,delay_color = {255,32,32}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	EvaNewShotData{	id = 410		,rect = {144,112,160,128}	,delay_color = {32,255,32}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	EvaNewShotData{	id = 411		,rect = {160,112,176,128}	,delay_color = {32,32,255}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	EvaNewShotData{	id = 412		,rect = {176,112,192,128}	,delay_color = {255,255,32}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	EvaNewShotData{	id = 413		,rect = {192,112,208,128}	,delay_color = {255,32,255}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	EvaNewShotData{	id = 414		,rect = {208,112,224,128}	,delay_color = {32,255,255}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	EvaNewShotData{	id = 415		,rect = {224,112,240,128}	,delay_color = {255,128,32}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	EvaNewShotData{	id = 416		,rect = {240,112,256,128}	,delay_color = {255,255,255}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　02　中丸弾
	
	EvaNewShotData{	id = 417		,rect = {0,192,32,224}		,delay_color = {255,32,32}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	EvaNewShotData{	id = 418		,rect = {32,192,64,224}		,delay_color = {32,255,32}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	EvaNewShotData{	id = 419		,rect = {64,192,96,224}		,delay_color = {32,32,255}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	EvaNewShotData{	id = 420		,rect = {96,192,128,224}		,delay_color = {255,255,32}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	EvaNewShotData{	id = 421		,rect = {128,192,160,224}	,delay_color = {255,32,255}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	EvaNewShotData{	id = 422		,rect = {160,192,192,224}	,delay_color = {32,255,255}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	EvaNewShotData{	id = 423		,rect = {192,192,224,224}	,delay_color = {255,128,32}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	EvaNewShotData{	id = 424		,rect = {224,192,256,224}	,delay_color = {255,255,255}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　03　大弾
	
	EvaNewShotData{	id = 425		,rect = {0,448,64,512}		,delay_color = {255,32,32}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 128	}
	EvaNewShotData{	id = 426		,rect = {64,448,128,512}		,delay_color = {32,255,32}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 128	}
	EvaNewShotData{	id = 427		,rect = {128,448,192,512}	,delay_color = {32,32,255}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 128	}
	EvaNewShotData{	id = 428		,rect = {192,448,256,512}	,delay_color = {255,255,32}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 128	}
	EvaNewShotData{	id = 429		,rect = {0,512,64,576}		,delay_color = {255,32,255}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 128	}
	EvaNewShotData{	id = 430		,rect = {64,512,128,576}		,delay_color = {32,255,255}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 128	}
	EvaNewShotData{	id = 431		,rect = {128,512,192,576}	,delay_color = {255,128,32}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 128	}
	EvaNewShotData{	id = 432		,rect = {192,512,256,576}	,delay_color = {255,255,255}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 128	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　04　二重丸弾
	
	--　黒透過
	EvaNewShotData{	id = 433		,rect = {0,128,16,144}		,delay_color = {255,32,32}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	EvaNewShotData{	id = 434		,rect = {16,128,32,144}		,delay_color = {32,255,32}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	EvaNewShotData{	id = 435		,rect = {32,128,48,144}		,delay_color = {32,32,255}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	EvaNewShotData{	id = 436		,rect = {48,128,64,144}		,delay_color = {255,255,32}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	EvaNewShotData{	id = 437		,rect = {64,128,80,144}		,delay_color = {255,32,255}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	EvaNewShotData{	id = 438		,rect = {80,128,96,144}		,delay_color = {32,255,255}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	EvaNewShotData{	id = 439		,rect = {96,128,112,144}		,delay_color = {255,128,32}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	EvaNewShotData{	id = 440		,rect = {112,128,128,144}	,delay_color = {255,255,255}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	
	--　黒透過ナシ
	EvaNewShotData{	id = 441		,rect = {128,128,144,144}	,delay_color = {255,32,32}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	EvaNewShotData{	id = 442		,rect = {144,128,160,144}	,delay_color = {32,255,32}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	EvaNewShotData{	id = 443		,rect = {160,128,176,144}	,delay_color = {32,32,255}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	EvaNewShotData{	id = 444		,rect = {176,128,192,144}	,delay_color = {255,255,32}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	EvaNewShotData{	id = 445		,rect = {192,128,208,144}	,delay_color = {255,32,255}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	EvaNewShotData{	id = 446		,rect = {208,128,224,144}	,delay_color = {32,255,255}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	EvaNewShotData{	id = 447		,rect = {224,128,240,144}	,delay_color = {255,128,32}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	EvaNewShotData{	id = 448		,rect = {240,128,256,144}	,delay_color = {255,255,255}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　05　小弾
	
	--　黒透過
	EvaNewShotData{	id = 449		,rect = {0,320,8,328}		,delay_color = {255,32,32}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	EvaNewShotData{	id = 450		,rect = {8,320,16,328}		,delay_color = {32,255,32}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	EvaNewShotData{	id = 451		,rect = {16,320,24,328}		,delay_color = {32,32,255}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	EvaNewShotData{	id = 452		,rect = {24,320,32,328}		,delay_color = {255,255,32}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	EvaNewShotData{	id = 453		,rect = {32,320,40,328}		,delay_color = {255,32,255}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true}
	EvaNewShotData{	id = 454		,rect = {40,320,48,328}		,delay_color = {32,255,255}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	EvaNewShotData{	id = 455		,rect = {48,320,56,328}		,delay_color = {255,128,32}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	EvaNewShotData{	id = 456		,rect = {56,320,64,328}		,delay_color = {255,255,255}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	
	--　黒透過ナシ
	EvaNewShotData{	id = 457		,rect = {64,320,72,328}		,delay_color = {255,32,32}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	EvaNewShotData{	id = 458		,rect = {72,320,80,328}		,delay_color = {32,255,32}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	EvaNewShotData{	id = 459		,rect = {80,320,88,328}		,delay_color = {32,32,255}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	EvaNewShotData{	id = 460		,rect = {88,320,96,328}		,delay_color = {255,255,32}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	EvaNewShotData{	id = 461		,rect = {96,320,104,328}		,delay_color = {255,32,255}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	EvaNewShotData{	id = 462		,rect = {104,320,112,328}	,delay_color = {32,255,255}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	EvaNewShotData{	id = 463		,rect = {112,320,120,328}	,delay_color = {255,128,32}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	EvaNewShotData{	id = 464		,rect = {120,320,128,328}	,delay_color = {255,255,255}	,render = EVA_BLEND_ADD_ARGB, fixed_angle = true	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　06　菌弾
	
	--　黒透過
	EvaNewShotData{	id = 465		,rect = {0,432,16,448}		,delay_color = {255,32,32}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = ran:Float(-8, 8)	,collision = 2	}
	EvaNewShotData{	id = 466		,rect = {16,432,32,448}		,delay_color = {32,255,32}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = ran:Float(-8, 8)	,collision = 2	}
	EvaNewShotData{	id = 467		,rect = {32,432,48,448}		,delay_color = {32,32,255}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = ran:Float(-8, 8)	,collision = 2	}
	EvaNewShotData{	id = 468		,rect = {48,432,64,448}		,delay_color = {255,255,32}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = ran:Float(-8, 8)	,collision = 2	}
	EvaNewShotData{	id = 469		,rect = {64,432,80,448}		,delay_color = {255,32,255}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = ran:Float(-8, 8)	,collision = 2	}
	EvaNewShotData{	id = 470		,rect = {80,432,96,448}		,delay_color = {32,255,255}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = ran:Float(-8, 8)	,collision = 2	}
	EvaNewShotData{	id = 471		,rect = {96,432,112,448}		,delay_color = {255,128,32}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = ran:Float(-8, 8)	,collision = 2	}
	EvaNewShotData{	id = 472		,rect = {112,432,128,448}	,delay_color = {255,255,255}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = ran:Float(-8, 8)	,collision = 2	}
	
	--　黒透過ナシ
	EvaNewShotData{	id = 473		,rect = {128,432,144,448}	,delay_color = {255,32,32}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = ran:Float(-8, 8)	,collision = 2	}
	EvaNewShotData{	id = 474		,rect = {144,432,160,448}	,delay_color = {32,255,32}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = ran:Float(-8, 8)	,collision = 2	}
	EvaNewShotData{	id = 475		,rect = {160,432,176,448}	,delay_color = {32,32,255}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = ran:Float(-8, 8)	,collision = 2	}
	EvaNewShotData{	id = 476		,rect = {176,432,192,448}	,delay_color = {255,255,32}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = ran:Float(-8, 8)	,collision = 2	}
	EvaNewShotData{	id = 477		,rect = {192,432,208,448}	,delay_color = {255,32,255}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = ran:Float(-8, 8)	,collision = 2	}
	EvaNewShotData{	id = 478		,rect = {208,432,224,448}	,delay_color = {32,255,255}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = ran:Float(-8, 8)	,collision = 2	}
	EvaNewShotData{	id = 479		,rect = {224,432,240,448}	,delay_color = {255,128,32}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = ran:Float(-8, 8)	,collision = 2	}
	EvaNewShotData{	id = 480		,rect = {240,432,256,448}	,delay_color = {255,255,255}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = ran:Float(-8, 8)	,collision = 2	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　07　銃弾
	
	--　黒透過
	EvaNewShotData{	id = 481		,rect = {0,32,16,48}			,delay_color = {255,32,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 482		,rect = {16,32,32,48}		,delay_color = {32,255,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 483		,rect = {32,32,48,48}		,delay_color = {32,32,255}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 484		,rect = {48,32,64,48}		,delay_color = {255,255,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 485		,rect = {64,32,80,48}		,delay_color = {255,32,255}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 486		,rect = {80,32,96,48}		,delay_color = {32,255,255}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 487		,rect = {96,32,112,48}		,delay_color = {255,128,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 488		,rect = {112,32,128,48}		,delay_color = {255,255,255}	,render = EVA_BLEND_ADD_ARGB	}
	
	--　黒透過ナシ
	EvaNewShotData{	id = 489		,rect = {128,32,144,48}		,delay_color = {255,32,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 490		,rect = {144,32,160,48}		,delay_color = {32,255,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 491		,rect = {160,32,176,48}		,delay_color = {32,32,255}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 492		,rect = {176,32,192,48}		,delay_color = {255,255,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 493		,rect = {192,32,208,48}		,delay_color = {255,32,255}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 494		,rect = {208,32,224,48}		,delay_color = {32,255,255}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 495		,rect = {224,32,240,48}		,delay_color = {255,128,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 496		,rect = {240,32,256,48}		,delay_color = {255,255,255}	,render = EVA_BLEND_ADD_ARGB	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　08　米弾
	
	--　黒透過
	EvaNewShotData{	id = 497		,rect = {0,16,16,32}			,delay_color = {255,32,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 498		,rect = {16,16,32,32}		,delay_color = {32,255,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 499		,rect = {32,16,48,32}		,delay_color = {32,32,255}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 500	,rect = {48,16,64,32}		,delay_color = {255,255,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 501	,rect = {64,16,80,32}		,delay_color = {255,32,255}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 502	,rect = {80,16,96,32}		,delay_color = {32,255,255}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 503	,rect = {96,16,112,32}		,delay_color = {255,128,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 504	,rect = {112,16,128,32}		,delay_color = {255,255,255}	,render = EVA_BLEND_ADD_ARGB	}
	
	--　黒透過ナシ
	EvaNewShotData{	id = 505	,rect = {128,16,144,32}		,delay_color = {255,32,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 506	,rect = {144,16,160,32}		,delay_color = {32,255,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 507	,rect = {160,16,176,32}		,delay_color = {32,32,255}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 508	,rect = {176,16,192,32}		,delay_color = {255,255,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 509	,rect = {192,16,208,32}		,delay_color = {255,32,255}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 510	,rect = {208,16,224,32}		,delay_color = {32,255,255}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 511	,rect = {224,16,240,32}		,delay_color = {255,128,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 512	,rect = {240,16,256,32}		,delay_color = {255,255,255}	,render = EVA_BLEND_ADD_ARGB	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　09　星弾
	
	--　黒透過
	EvaNewShotData{	id = 513	,rect = {0,64,16,80}			,delay_color = {255,32,32}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 5	}
	EvaNewShotData{	id = 514	,rect = {16,64,32,80}		,delay_color = {32,255,32}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 5	}
	EvaNewShotData{	id = 515	,rect = {32,64,48,80}		,delay_color = {32,32,255}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 5	}
	EvaNewShotData{	id = 516	,rect = {48,64,64,80}		,delay_color = {255,255,32}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 5	}
	EvaNewShotData{	id = 517	,rect = {64,64,80,80}		,delay_color = {255,32,255}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 5	}
	EvaNewShotData{	id = 518	,rect = {80,64,96,80}		,delay_color = {32,255,255}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 5	}
	EvaNewShotData{	id = 519	,rect = {96,64,112,80}		,delay_color = {255,128,32}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 5	}
	EvaNewShotData{	id = 520	,rect = {112,64,128,80}		,delay_color = {255,255,255}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 5	}
	
	--　黒透過ナシ
	EvaNewShotData{	id = 521	,rect = {128,64,144,80}		,delay_color = {255,32,32}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 5	}
	EvaNewShotData{	id = 522	,rect = {144,64,160,80}		,delay_color = {32,255,32}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 5	}
	EvaNewShotData{	id = 523	,rect = {160,64,176,80}		,delay_color = {32,32,255}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 5	}
	EvaNewShotData{	id = 524	,rect = {176,64,192,80}		,delay_color = {255,255,32}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 5	}
	EvaNewShotData{	id = 525	,rect = {192,64,208,80}		,delay_color = {255,32,255}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 5	}
	EvaNewShotData{	id = 526	,rect = {208,64,224,80}		,delay_color = {32,255,255}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 5	}
	EvaNewShotData{	id = 527	,rect = {224,64,240,80}		,delay_color = {255,128,32}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 5	}
	EvaNewShotData{	id = 528	,rect = {240,64,256,80}		,delay_color = {255,255,255}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 5	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　10　クナイ弾
	
	--　黒透過
	EvaNewShotData{	id = 529	,rect = {0,0,16,16}			,delay_color = {255,32,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 530	,rect = {16,0,32,16}			,delay_color = {32,255,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 531	,rect = {32,0,48,16}			,delay_color = {32,32,255}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 532	,rect = {48,0,64,16}			,delay_color = {255,255,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 533	,rect = {64,0,80,16}			,delay_color = {255,32,255}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 534	,rect = {80,0,96,16}			,delay_color = {32,255,255}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 535	,rect = {96,0,112,16}		,delay_color = {255,128,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 536	,rect = {112,0,128,16}		,delay_color = {255,255,255}	,render = EVA_BLEND_ADD_ARGB	}
	
	--　黒透過ナシ
	EvaNewShotData{	id = 537	,rect = {128,0,144,16}		,delay_color = {255,32,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 538	,rect = {144,0,160,16}		,delay_color = {32,255,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 539	,rect = {160,0,176,16}		,delay_color = {32,32,255}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 540	,rect = {176,0,192,16}		,delay_color = {255,255,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 541	,rect = {192,0,208,16}		,delay_color = {255,32,255}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 542	,rect = {208,0,224,16}		,delay_color = {32,255,255}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 543	,rect = {224,0,240,16}		,delay_color = {255,128,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 544	,rect = {240,0,256,16}		,delay_color = {255,255,255}	,render = EVA_BLEND_ADD_ARGB	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　11　細弾
	
	--　黒透過
	EvaNewShotData{	id = 545	,rect = {0,144,16,160}		,delay_color = {255,32,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 546	,rect = {16,144,32,160}		,delay_color = {32,255,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 547	,rect = {32,144,48,160}		,delay_color = {32,32,255}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 548	,rect = {48,144,64,160}		,delay_color = {255,255,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 549	,rect = {64,144,80,160}		,delay_color = {255,32,255}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 550	,rect = {80,144,96,160}		,delay_color = {32,255,255}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 551	,rect = {96,144,112,160}		,delay_color = {255,128,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 552	,rect = {112,144,128,160}	,delay_color = {255,255,255}	,render = EVA_BLEND_ADD_ARGB	}
	
	--　黒透過ナシ
	EvaNewShotData{	id = 553	,rect = {128,144,144,160}	,delay_color = {255,32,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 554	,rect = {144,144,160,160}	,delay_color = {32,255,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 555	,rect = {160,144,176,160}	,delay_color = {32,32,255}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 556	,rect = {176,144,192,160}	,delay_color = {255,255,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 557	,rect = {192,144,208,160}	,delay_color = {255,32,255}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 558	,rect = {208,144,224,160}	,delay_color = {32,255,255}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 559	,rect = {224,144,240,160}	,delay_color = {255,128,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 560	,rect = {240,144,256,160}	,delay_color = {255,255,255}	,render = EVA_BLEND_ADD_ARGB	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　12　札弾
	
	--　黒透過
	EvaNewShotData{	id = 561	,rect = {0,96,16,112}		,delay_color = {255,32,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 562	,rect = {16,96,32,112}		,delay_color = {32,255,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 563	,rect = {32,96,48,112}		,delay_color = {32,32,255}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 564	,rect = {48,96,64,112}		,delay_color = {255,255,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 565	,rect = {64,96,80,112}		,delay_color = {255,32,255}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 566	,rect = {80,96,96,112}		,delay_color = {32,255,255}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 567	,rect = {96,96,112,112}		,delay_color = {255,128,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 568	,rect = {112,96,128,112}		,delay_color = {255,255,255}	,render = EVA_BLEND_ADD_ARGB	}
	
	--　黒透過ナシ
	EvaNewShotData{	id = 569	,rect = {128,96,144,112}		,delay_color = {255,32,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 570	,rect = {144,96,160,112}		,delay_color = {32,255,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 571	,rect = {160,96,176,112}		,delay_color = {32,32,255}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 572	,rect = {176,96,192,112}		,delay_color = {255,255,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 573	,rect = {192,96,208,112}		,delay_color = {255,32,255}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 574	,rect = {208,96,224,112}		,delay_color = {32,255,255}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 575	,rect = {224,96,240,112}		,delay_color = {255,128,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 576	,rect = {240,96,256,112}		,delay_color = {255,255,255}	,render = EVA_BLEND_ADD_ARGB	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　13　ゾウリムシ弾　（永琳奴）
	
	--　黒透過
	EvaNewShotData{	id = 577	,rect = {0,48,16,64}			,delay_color = {255,32,32}	,render = EVA_BLEND_ADD_ARGB	,collision = 1	}
	EvaNewShotData{	id = 578	,rect = {16,48,32,64}		,delay_color = {32,255,32}	,render = EVA_BLEND_ADD_ARGB	,collision = 1	}
	EvaNewShotData{	id = 579	,rect = {32,48,48,64}		,delay_color = {32,32,255}	,render = EVA_BLEND_ADD_ARGB	,collision = 1	}
	EvaNewShotData{	id = 580	,rect = {48,48,64,64}		,delay_color = {255,255,32}	,render = EVA_BLEND_ADD_ARGB	,collision = 1	}
	EvaNewShotData{	id = 581	,rect = {64,48,80,64}		,delay_color = {255,32,255}	,render = EVA_BLEND_ADD_ARGB	,collision = 1	}
	EvaNewShotData{	id = 582	,rect = {80,48,96,64}		,delay_color = {32,255,255}	,render = EVA_BLEND_ADD_ARGB	,collision = 1	}
	EvaNewShotData{	id = 583	,rect = {96,48,112,64}		,delay_color = {255,128,32}	,render = EVA_BLEND_ADD_ARGB	,collision = 1	}
	EvaNewShotData{	id = 584	,rect = {112,48,128,64}		,delay_color = {255,255,255}	,render = EVA_BLEND_ADD_ARGB	,collision = 1	}
	
	--　黒透過ナシ
	EvaNewShotData{	id = 585	,rect = {128,48,144,64}		,delay_color = {255,32,32}	,render = EVA_BLEND_ADD_ARGB	,collision = 1	}
	EvaNewShotData{	id = 586	,rect = {144,48,160,64}		,delay_color = {32,255,32}	,render = EVA_BLEND_ADD_ARGB	,collision = 1	}
	EvaNewShotData{	id = 587	,rect = {160,48,176,64}		,delay_color = {32,32,255}	,render = EVA_BLEND_ADD_ARGB	,collision = 1	}
	EvaNewShotData{	id = 588	,rect = {176,48,192,64}		,delay_color = {255,255,32}	,render = EVA_BLEND_ADD_ARGB	,collision = 1	}
	EvaNewShotData{	id = 589	,rect = {192,48,208,64}		,delay_color = {255,32,255}	,render = EVA_BLEND_ADD_ARGB	,collision = 1	}
	EvaNewShotData{	id = 590	,rect = {208,48,224,64}		,delay_color = {32,255,255}	,render = EVA_BLEND_ADD_ARGB	,collision = 1	}
	EvaNewShotData{	id = 591	,rect = {224,48,240,64}		,delay_color = {255,128,32}	,render = EVA_BLEND_ADD_ARGB	,collision = 1	}
	EvaNewShotData{	id = 592	,rect = {240,48,256,64}		,delay_color = {255,255,255}	,render = EVA_BLEND_ADD_ARGB	,collision = 1	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　14　鱗弾
	
	--　黒透過
	EvaNewShotData{	id = 593	,rect = {0,80,16,96}			,delay_color = {255,32,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 594	,rect = {16,80,32,96}		,delay_color = {32,255,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 595	,rect = {32,80,48,96}		,delay_color = {32,32,255}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 596	,rect = {48,80,64,96}		,delay_color = {255,255,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 597	,rect = {64,80,80,96}		,delay_color = {255,32,255}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 598	,rect = {80,80,96,96}		,delay_color = {32,255,255}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 599	,rect = {96,80,112,96}		,delay_color = {255,128,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 600	,rect = {112,80,128,96}		,delay_color = {255,255,255}	,render = EVA_BLEND_ADD_ARGB	}
	
	--　黒透過ナシ
	EvaNewShotData{	id = 601	,rect = {128,80,144,96}		,delay_color = {255,32,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 602	,rect = {144,80,160,96}		,delay_color = {32,255,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 603	,rect = {160,80,176,96}		,delay_color = {32,32,255}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 604	,rect = {176,80,192,96}		,delay_color = {255,255,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 605	,rect = {192,80,208,96}		,delay_color = {255,32,255}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 606	,rect = {208,80,224,96}		,delay_color = {32,255,255}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 607	,rect = {224,80,240,96}		,delay_color = {255,128,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 608	,rect = {240,80,256,96}		,delay_color = {255,255,255}	,render = EVA_BLEND_ADD_ARGB	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　15　大星弾
	
	EvaNewShotData{	id = 609	,rect = {0,160,32,192}		,delay_color = {255,32,32}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 5	}
	EvaNewShotData{	id = 610	,rect = {32,160,64,192}		,delay_color = {32,255,32}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 5	}
	EvaNewShotData{	id = 611	,rect = {64,160,96,192}		,delay_color = {32,32,255}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 5	}
	EvaNewShotData{	id = 612	,rect = {96,160,128,192}		,delay_color = {255,255,32}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 5	}
	EvaNewShotData{	id = 613	,rect = {128,160,160,192}	,delay_color = {255,32,255}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 5	}
	EvaNewShotData{	id = 614	,rect = {160,160,192,192}	,delay_color = {32,255,255}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 5	}
	EvaNewShotData{	id = 615	,rect = {192,160,224,192}	,delay_color = {255,128,32}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 5	}
	EvaNewShotData{	id = 616	,rect = {224,160,256,192}	,delay_color = {255,255,255}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 5	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　16　蝶弾
	
	EvaNewShotData{	id = 617	,rect = {0,224,32,256}		,delay_color = {255,32,32}	,render = EVA_BLEND_ADD_ARGB	,collision = {4,0,0}	}
	EvaNewShotData{	id = 618	,rect = {32,224,64,256}		,delay_color = {32,255,32}	,render = EVA_BLEND_ADD_ARGB	,collision = {4,0,0}	}
	EvaNewShotData{	id = 619	,rect = {64,224,96,256}		,delay_color = {32,32,255}	,render = EVA_BLEND_ADD_ARGB	,collision = {4,0,0}	}
	EvaNewShotData{	id = 620	,rect = {96,224,128,256}		,delay_color = {255,255,32}	,render = EVA_BLEND_ADD_ARGB	,collision = {4,0,0}	}
	EvaNewShotData{	id = 621	,rect = {128,224,160,256}	,delay_color = {255,32,255}	,render = EVA_BLEND_ADD_ARGB	,collision = {4,0,0}	}
	EvaNewShotData{	id = 622	,rect = {160,224,192,256}	,delay_color = {32,255,255}	,render = EVA_BLEND_ADD_ARGB	,collision = {4,0,0}	}
	EvaNewShotData{	id = 623	,rect = {192,224,224,256}	,delay_color = {255,128,32}	,render = EVA_BLEND_ADD_ARGB	,collision = {4,0,0}	}
	EvaNewShotData{	id = 624	,rect = {224,224,256,256}	,delay_color = {255,255,255}	,render = EVA_BLEND_ADD_ARGB	,collision = {4,0,0}	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　17　ナイフ弾
	
	EvaNewShotData{	id = 625	,rect = {0,256,32,288}		,delay_color = {255,32,32}	,render = EVA_BLEND_ADD_ARGB	,collision = {3,0,4}	}
	EvaNewShotData{	id = 626	,rect = {32,256,64,288}		,delay_color = {32,255,32}	,render = EVA_BLEND_ADD_ARGB	,collision = {3,0,4}	}
	EvaNewShotData{	id = 627	,rect = {64,256,96,288}		,delay_color = {32,32,255}	,render = EVA_BLEND_ADD_ARGB	,collision = {3,0,4}	}
	EvaNewShotData{	id = 628	,rect = {96,256,128,288}		,delay_color = {255,255,32}	,render = EVA_BLEND_ADD_ARGB	,collision = {3,0,4}	}
	EvaNewShotData{	id = 629	,rect = {128,256,160,288}	,delay_color = {255,32,255}	,render = EVA_BLEND_ADD_ARGB	,collision = {3,0,4}	}
	EvaNewShotData{	id = 630	,rect = {160,256,192,288}	,delay_color = {32,255,255}	,render = EVA_BLEND_ADD_ARGB	,collision = {3,0,4}	}
	EvaNewShotData{	id = 631	,rect = {192,256,224,288}	,delay_color = {255,128,32}	,render = EVA_BLEND_ADD_ARGB	,collision = {3,0,4}	}
	EvaNewShotData{	id = 632	,rect = {224,256,256,288}	,delay_color = {255,255,255}	,render = EVA_BLEND_ADD_ARGB	,collision = {3,0,4}	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　18　グミ弾
	
	EvaNewShotData{	id = 633	,rect = {0,289,32,319}		,delay_color = {255,32,32}	,render = EVA_BLEND_ADD_ARGB	,collision = 4	}
	EvaNewShotData{	id = 634	,rect = {32,289,64,319}		,delay_color = {32,255,32}	,render = EVA_BLEND_ADD_ARGB	,collision = 4	}
	EvaNewShotData{	id = 635	,rect = {64,289,96,319}		,delay_color = {32,32,255}	,render = EVA_BLEND_ADD_ARGB	,collision = 4	}
	EvaNewShotData{	id = 636	,rect = {96,289,128,319}		,delay_color = {255,255,32}	,render = EVA_BLEND_ADD_ARGB	,collision = 4	}
	EvaNewShotData{	id = 637	,rect = {128,289,160,319}	,delay_color = {255,32,255}	,render = EVA_BLEND_ADD_ARGB	,collision = 4	}
	EvaNewShotData{	id = 638	,rect = {160,289,192,319}	,delay_color = {32,255,255}	,render = EVA_BLEND_ADD_ARGB	,collision = 4	}
	EvaNewShotData{	id = 639	,rect = {192,289,224,319}	,delay_color = {255,128,32}	,render = EVA_BLEND_ADD_ARGB	,collision = 4	}
	EvaNewShotData{	id = 640	,rect = {224,289,256,319}	,delay_color = {255,255,255}	,render = EVA_BLEND_ADD_ARGB	,collision = 4	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　19　ハート弾
	
	EvaNewShotData{	id = 641	,rect = {256,0,288,32}	,delay_color = {255,32,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 642	,rect = {288,0,320,32}	,delay_color = {32,255,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 643	,rect = {320,0,352,32}	,delay_color = {32,32,255}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 644	,rect = {352,0,384,32}	,delay_color = {255,255,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 645	,rect = {384,0,416,32}	,delay_color = {255,32,255}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 646	,rect = {416,0,448,32}	,delay_color = {32,255,255}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 647	,rect = {448,0,480,32}	,delay_color = {255,128,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 648	,rect = {480,0,512,32}	,delay_color = {255,255,255}	,render = EVA_BLEND_ADD_ARGB	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　20　矢弾
	
	EvaNewShotData{	id = 649	,rect = {256,32,288,64}	,delay_color = {255,32,32}	,render = EVA_BLEND_ADD_ARGB	,collision = {2,0,8}	}
	EvaNewShotData{	id = 650	,rect = {288,32,320,64}	,delay_color = {32,255,32}	,render = EVA_BLEND_ADD_ARGB	,collision = {2,0,8}	}
	EvaNewShotData{	id = 651	,rect = {320,32,352,64}	,delay_color = {32,32,255}	,render = EVA_BLEND_ADD_ARGB	,collision = {2,0,8}	}
	EvaNewShotData{	id = 652	,rect = {352,32,384,64}	,delay_color = {255,255,32}	,render = EVA_BLEND_ADD_ARGB	,collision = {2,0,8}	}
	EvaNewShotData{	id = 653	,rect = {384,32,416,64}	,delay_color = {255,32,255}	,render = EVA_BLEND_ADD_ARGB	,collision = {2,0,8}	}
	EvaNewShotData{	id = 654	,rect = {416,32,448,64}	,delay_color = {32,255,255}	,render = EVA_BLEND_ADD_ARGB	,collision = {2,0,8}	}
	EvaNewShotData{	id = 655	,rect = {448,32,480,64}	,delay_color = {255,128,32}	,render = EVA_BLEND_ADD_ARGB	,collision = {2,0,8}	}
	EvaNewShotData{	id = 656	,rect = {480,32,512,64}	,delay_color = {255,255,255}	,render = EVA_BLEND_ADD_ARGB	,collision = {2,0,8}	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　21　神霊弾の元
	
	EvaNewShotData{	id = 657	,rect = {256,96,288,128}	,delay_color = {255,32,32}	,render = EVA_BLEND_ADD_ARGB	,collision = 6	}
	EvaNewShotData{	id = 658	,rect = {288,96,320,128}	,delay_color = {32,255,32}	,render = EVA_BLEND_ADD_ARGB	,collision = 6	}
	EvaNewShotData{	id = 659	,rect = {320,96,352,128}	,delay_color = {32,32,255}	,render = EVA_BLEND_ADD_ARGB	,collision = 6	}
	EvaNewShotData{	id = 660	,rect = {352,96,384,128}	,delay_color = {255,255,32}	,render = EVA_BLEND_ADD_ARGB	,collision = 6	}
	EvaNewShotData{	id = 661	,rect = {384,96,416,128}	,delay_color = {255,32,255}	,render = EVA_BLEND_ADD_ARGB	,collision = 6	}
	EvaNewShotData{	id = 662	,rect = {416,96,448,128}	,delay_color = {32,255,255}	,render = EVA_BLEND_ADD_ARGB	,collision = 6	}
	EvaNewShotData{	id = 663	,rect = {448,96,480,128}	,delay_color = {255,128,32}	,render = EVA_BLEND_ADD_ARGB	,collision = 6	}
	EvaNewShotData{	id = 664	,rect = {480,96,512,128}	,delay_color = {255,255,255}	,render = EVA_BLEND_ADD_ARGB	,collision = 6	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　22　神霊弾
	
	EvaNewShotData{	id = 665	,rect = {260,132,316,188}	,delay_color = {255,32,32}	,render = EVA_BLEND_ADD_ARGB	,collision = 15	}
	EvaNewShotData{	id = 666	,rect = {324,132,380,188}	,delay_color = {32,255,32}	,render = EVA_BLEND_ADD_ARGB	,collision = 15	}
	EvaNewShotData{	id = 667	,rect = {388,132,444,188}	,delay_color = {32,32,255}	,render = EVA_BLEND_ADD_ARGB	,collision = 15	}
	EvaNewShotData{	id = 668	,rect = {452,132,508,188}	,delay_color = {255,255,32}	,render = EVA_BLEND_ADD_ARGB	,collision = 15	}
	EvaNewShotData{	id = 669	,rect = {260,196,316,252}	,delay_color = {255,32,255}	,render = EVA_BLEND_ADD_ARGB	,collision = 15	}
	EvaNewShotData{	id = 670	,rect = {324,196,380,252}	,delay_color = {32,255,255}	,render = EVA_BLEND_ADD_ARGB	,collision = 15	}
	EvaNewShotData{	id = 671	,rect = {388,196,444,252}	,delay_color = {255,128,32}	,render = EVA_BLEND_ADD_ARGB	,collision = 15	}
	EvaNewShotData{	id = 672	,rect = {452,196,508,252}	,delay_color = {255,255,255}	,render = EVA_BLEND_ADD_ARGB	,collision = 15	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　23　サニーレーザーの先っちょ
	
	EvaNewShotData{	id = 673	,rect = {256,384,288,416}	,delay_color = {255,32,32}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 6	}
	EvaNewShotData{	id = 674	,rect = {288,384,320,416}	,delay_color = {32,255,32}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 6	}
	EvaNewShotData{	id = 675	,rect = {320,384,352,416}	,delay_color = {32,32,255}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 6	}
	EvaNewShotData{	id = 676	,rect = {352,384,384,416}	,delay_color = {255,255,32}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 6	}
	EvaNewShotData{	id = 677	,rect = {384,384,416,416}	,delay_color = {255,32,255}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 6	}
	EvaNewShotData{	id = 678	,rect = {416,384,448,416}	,delay_color = {32,255,255}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 6	}
	EvaNewShotData{	id = 679	,rect = {448,384,480,416}	,delay_color = {255,128,32}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 6	}
	EvaNewShotData{	id = 680	,rect = {480,384,512,416}	,delay_color = {255,255,255}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 6	}
	
	--　階調反転
	EvaNewShotData{	id = 681	,rect = {256,416,288,448}	,delay_color = {255,32,32}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 6	}
	EvaNewShotData{	id = 682	,rect = {288,416,320,448}	,delay_color = {32,255,32}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 6	}
	EvaNewShotData{	id = 683	,rect = {320,416,352,448}	,delay_color = {32,32,255}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 6	}
	EvaNewShotData{	id = 684	,rect = {352,416,384,448}	,delay_color = {255,255,32}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 6	}
	EvaNewShotData{	id = 685	,rect = {384,416,416,448}	,delay_color = {255,32,255}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 6	}
	EvaNewShotData{	id = 686	,rect = {416,416,448,448}	,delay_color = {32,255,255}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 6	}
	EvaNewShotData{	id = 687	,rect = {448,416,480,448}	,delay_color = {255,128,32}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 6	}
	EvaNewShotData{	id = 688	,rect = {480,416,512,448}	,delay_color = {255,255,255}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 6	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　FIRE　炎弾
	EvaNewShotData{
		id = 689
		,delay_color = {255,32,32}
		,render = EVA_BLEND_ADD_ARGB
		,collision = 4
		,AnimationData = {
			{4, 256, 256, 288, 288 },
			{4, 256, 288, 288, 320 },
			{4, 256, 320, 288, 352 },
			{4, 256, 352, 288, 384 },
		}
	}
	EvaNewShotData{
		id = 690
		,delay_color = {32,255,32}
		,render = EVA_BLEND_ADD_ARGB
		,collision = 4
		,AnimationData = {
			{4, 288, 256, 320, 288 },
			{4, 288, 288, 320, 320 },
			{4, 288, 320, 320, 352 },
			{4, 288, 352, 320, 384 },
		}
	}
	EvaNewShotData{
		id = 691
		,delay_color = {32,32,255}
		,render = EVA_BLEND_ADD_ARGB
		,collision = 4
		,AnimationData = {
			{4, 320, 256, 352, 288 },
			{4, 320, 288, 352, 320 },
			{4, 320, 320, 352, 352 },
			{4, 320, 352, 352, 384 },
		}
	}
	EvaNewShotData{
		id = 692
		,delay_color = {255,255,32}
		,render = EVA_BLEND_ADD_ARGB
		,collision = 4
		,AnimationData = {
			{4, 352, 256, 384, 288 },
			{4, 352, 288, 384, 320 },
			{4, 352, 320, 384, 352 },
			{4, 352, 352, 384, 384 },
		}
	}
	EvaNewShotData{
		id = 693
		,delay_color = {255,32,255}
		,render = EVA_BLEND_ADD_ARGB
		,collision = 4
		,AnimationData = {
			{4, 384, 256, 416, 288 },
			{4, 384, 288, 416, 320 },
			{4, 384, 320, 416, 352 },
			{4, 384, 352, 416, 384 },
		}
	}
	EvaNewShotData{
		id = 694
		,delay_color = {32,255,255}
		,render = EVA_BLEND_ADD_ARGB
		,collision = 4
		,AnimationData = {
			{4, 416, 256, 448, 288 },
			{4, 416, 288, 448, 320 },
			{4, 416, 320, 448, 352 },
			{4, 416, 352, 448, 384 },
		}
	}
	EvaNewShotData{
		id = 695
		,delay_color = {255,128,32}
		,render = EVA_BLEND_ADD_ARGB
		,collision = 4
		,AnimationData = {
			{4, 448, 256, 480, 288 },
			{4, 448, 288, 480, 320 },
			{4, 448, 320, 480, 352 },
			{4, 448, 352, 480, 384 },
		}
	}
	EvaNewShotData{
		id = 696
		,delay_color = {255,255,255}
		,render = EVA_BLEND_ADD_ARGB
		,collision = 4
		,AnimationData = {
			{4, 480, 256, 512, 288 },
			{4, 480, 288, 512, 320 },
			{4, 480, 320, 512, 352 },
			{4, 480, 352, 512, 384 },
		}
	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　WATER　水滴弾
	
	--　黒透過
	EvaNewShotData{	id = 697	,rect = {  0,416, 16,432}	,delay_color = {255,32,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 698	,rect = { 16,416, 32,432}	,delay_color = {32,255,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 699	,rect = { 32,416, 48,432}	,delay_color = {32,32,255}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 700	,rect = { 48,416, 64,432}	,delay_color = {255,255,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 701	,rect = { 64,416, 80,432}	,delay_color = {255,32,255}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 702	,rect = { 80,416, 96,432}	,delay_color = {32,255,255}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 703	,rect = { 96,416,112,432}	,delay_color = {255,128,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 704	,rect = {112,416,128,432}	,delay_color = {255,255,255}	,render = EVA_BLEND_ADD_ARGB	}
	
	--　黒透過ナシ
	EvaNewShotData{	id = 705	,rect = {128,416,144,432}	,delay_color = {255,32,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 706	,rect = {144,416,160,432}	,delay_color = {32,255,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 707	,rect = {160,416,176,432}	,delay_color = {32,32,255}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 708	,rect = {176,416,192,432}	,delay_color = {255,255,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 709	,rect = {192,416,208,432}	,delay_color = {255,32,255}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 710	,rect = {208,416,224,432}	,delay_color = {32,255,255}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 711	,rect = {224,416,240,432}	,delay_color = {255,128,32}	,render = EVA_BLEND_ADD_ARGB	}
	EvaNewShotData{	id = 712	,rect = {240,416,256,432}	,delay_color = {255,255,255}	,render = EVA_BLEND_ADD_ARGB	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　29　金弾　回転　-8,8
	
	EvaNewShotData{	id = 713	,rect = {128,320,144,336}	,delay_color = {255,32,32}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 6	}
	EvaNewShotData{	id = 714	,rect = {144,320,160,336}	,delay_color = {32,255,32}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 6	}
	EvaNewShotData{	id = 715	,rect = {160,320,176,336}	,delay_color = {32,32,255}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 6	}
	EvaNewShotData{	id = 716	,rect = {176,320,192,336}	,delay_color = {255,255,32}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 6	}
	EvaNewShotData{	id = 717	,rect = {192,320,208,336}	,delay_color = {255,32,255}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 6	}
	EvaNewShotData{	id = 718	,rect = {208,320,224,336}	,delay_color = {32,255,255}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 6	}
	EvaNewShotData{	id = 719	,rect = {224,320,240,336}	,delay_color = {255,128,32}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 6	}
	EvaNewShotData{	id = 720	,rect = {240,320,256,336}	,delay_color = {255,255,255}	,render = EVA_BLEND_ADD_ARGB	,angular_velocity = 6	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　30　へにょり用
	
	EvaNewShotData{	id = 721	,rect = {256,64,288,96}	,delay_color = {255,32,32}	,render = EVA_BLEND_ADD_ARGB	,collision = 1	}
	EvaNewShotData{	id = 722	,rect = {288,64,320,96}	,delay_color = {32,255,32}	,render = EVA_BLEND_ADD_ARGB	,collision = 1	}
	EvaNewShotData{	id = 723	,rect = {320,64,352,96}	,delay_color = {32,32,255}	,render = EVA_BLEND_ADD_ARGB	,collision = 1	}
	EvaNewShotData{	id = 724	,rect = {352,64,384,96}	,delay_color = {255,255,32}	,render = EVA_BLEND_ADD_ARGB	,collision = 1	}
	EvaNewShotData{	id = 725	,rect = {384,64,416,96}	,delay_color = {255,32,255}	,render = EVA_BLEND_ADD_ARGB	,collision = 1	}
	EvaNewShotData{	id = 726	,rect = {416,64,448,96}	,delay_color = {32,255,255}	,render = EVA_BLEND_ADD_ARGB	,collision = 1	}
	EvaNewShotData{	id = 727	,rect = {448,64,480,96}	,delay_color = {255,128,32}	,render = EVA_BLEND_ADD_ARGB	,collision = 1	}
	EvaNewShotData{	id = 728	,rect = {480,64,512,96}	,delay_color = {255,255,255}	,render = EVA_BLEND_ADD_ARGB	,collision = 1	}
	
	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　31　音符弾
	EvaNewShotData{
		id = 729
		,delay_color = {255,32,32}
		,render = EVA_BLEND_ADD_ARGB
		,collision = {3,-1,-9}
		,fixed_angle = true
		,AnimationData = {
			{ 8, 0, 576, 32, 608 },
			{ 8, 0, 608, 32, 640 },
			{ 8, 0, 640, 32, 672 },
			{ 8, 0, 672, 32, 704 },
		}
	}
	EvaNewShotData{
		id = 730
		,delay_color = {32,255,32}
		,render = EVA_BLEND_ADD_ARGB
		,collision = {3,-1,-9}
		,fixed_angle = true
		,AnimationData = {
			{ 8, 32, 576, 64, 608 },
			{ 8, 32, 608, 64, 640 },
			{ 8, 32, 640, 64, 672 },
			{ 8, 32, 672, 64, 704 },
		}
	}
	EvaNewShotData{
		id = 731
		,delay_color = {32,32,255}
		,render = EVA_BLEND_ADD_ARGB
		,collision = {3,-1,-9}
		,fixed_angle = true
		,AnimationData = {
			{ 8, 64, 576, 96, 608 },
			{ 8, 64, 608, 96, 640 },
			{ 8, 64, 640, 96, 672 },
			{ 8, 64, 672, 96, 704 },
		}
	}
	EvaNewShotData{
		id = 732
		,delay_color = {255,255,32}
		,render = EVA_BLEND_ADD_ARGB
		,collision = {3,-1,-9}
		,fixed_angle = true
		,AnimationData = {
			{ 8, 96, 576, 128, 608 },
			{ 8, 96, 608, 128, 640 },
			{ 8, 96, 640, 128, 672 },
			{ 8, 96, 672, 128, 704 },
		}
	}
	EvaNewShotData{
		id = 733
		,delay_color = {255,32,255}
		,render = EVA_BLEND_ADD_ARGB
		,collision = {3,-1,-9}
		,fixed_angle = true
		,AnimationData = {
			{ 8, 128, 576, 160, 608 },
			{ 8, 128, 608, 160, 640 },
			{ 8, 128, 640, 160, 672 },
			{ 8, 128, 672, 160, 704 },
		}
	}
	EvaNewShotData{
		id = 734
		,delay_color = {32,255,255}
		,render = EVA_BLEND_ADD_ARGB
		,collision = {3,-1,-9}
		,fixed_angle = true
		,AnimationData = {
			{ 8, 160, 576, 192, 608 },
			{ 8, 160, 608, 192, 640 },
			{ 8, 160, 640, 192, 672 },
			{ 8, 160, 672, 192, 704 },
		}
	}
	EvaNewShotData{
		id = 735
		,delay_color = {255,128,32}
		,render = EVA_BLEND_ADD_ARGB
		,collision = {3,-1,-9}
		,fixed_angle = true
		,AnimationData = {
			{ 8, 192, 576, 224, 608 },
			{ 8, 192, 608, 224, 640 },
			{ 8, 192, 640, 224, 672 },
			{ 8, 192, 672, 224, 704 },
		}
	}
	EvaNewShotData{
		id = 736
		,delay_color = {255,255,255}
		,render = EVA_BLEND_ADD_ARGB
		,collision = {3,-1,-9}
		,fixed_angle = true
		,AnimationData = {
			{ 8, 224, 576, 256, 608 },
			{ 8, 224, 608, 256, 640 },
			{ 8, 224, 640, 256, 672 },
			{ 8, 224, 672, 256, 704 },
		}
	}

	----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　BEAM_ST　直線レーザー用
	EvaNewShotData{
		id = 737
		,delay_color = {255,32,32}
		,render = EVA_BLEND_ADD_ARGB
		,AnimationData = {
			{ 4, 0, 354, 32, 382 },
			{ 4, 0, 386, 32, 414 },
		}
	}
	EvaNewShotData{
		id = 738
		,delay_color = {32,255,32}
		,render = EVA_BLEND_ADD_ARGB
		,AnimationData = {
			{ 4, 32, 354, 64, 382 },
			{ 4, 32, 386, 64, 414 },
		}
	}
	EvaNewShotData{
		id = 739
		,delay_color = {32,32,255}
		,render = EVA_BLEND_ADD_ARGB
		,AnimationData = {
			{ 4, 64, 354, 96, 382 },
			{ 4, 64, 386, 96, 414 },
		}
	}
	EvaNewShotData{
		id = 740
		,delay_color = {255,255,32}
		,render = EVA_BLEND_ADD_ARGB
		,AnimationData = {
			{ 8, 96, 354, 128, 382 },
			{ 8, 96, 386, 128, 414 },
		}
	}
	EvaNewShotData{
		id = 741
		,delay_color = {255,32,255}
		,render = EVA_BLEND_ADD_ARGB
		,AnimationData = {
			{ 8, 128, 354, 160, 382 },
			{ 8, 128, 386, 160, 414 },
		}
	}
	EvaNewShotData{
		id = 742
		,delay_color = {32,255,255}
		,render = EVA_BLEND_ADD_ARGB
		,AnimationData = {
			{ 8, 160, 354, 192, 382 },
			{ 8, 160, 386, 192, 414 },
		}
	}
	EvaNewShotData{
		id = 743
		,delay_color = {255,128,32}
		,render = EVA_BLEND_ADD_ARGB
		,AnimationData = {
			{ 8, 192, 354, 224, 382 },
			{ 8, 192, 386, 224, 414 },
		}
	}
	EvaNewShotData{
		id = 744
		,delay_color = {255,255,255}
		,render = EVA_BLEND_ADD_ARGB
		,AnimationData = {
			{ 8, 224, 354, 256, 382 },
			{ 8, 224, 386, 256, 414 },
		}
	}

		----------------------------------------------------------------------------------------------------------------
	----------------------------------------------------------------------------------------------------------------
	--　HUMAN　人間弾　赤
	EvaNewShotData{
		id = 745
		,delay_color = {255,32,32}
		,render = EVA_BLEND_ALPHA
		,collision = 5
		,fixed_angle = true
		,AnimationData = {
			{4, 128, 704, 160, 736 },
			{4, 160, 704, 192, 736 },
			{4, 192, 704, 224, 736 },
			{4, 224, 704, 256, 736 },
		}
	}
	--　DOG　犬弾　緑
	EvaNewShotData{
		id = 746
		,delay_color = {32,255,32}
		,render = EVA_BLEND_ALPHA
		,collision = 5
		,AnimationData = {
			{4,   0, 736,  32, 768 },
			{4,  32, 736,  64, 768 },
			{4,  64, 736,  96, 768 },
			{4,  96, 736, 128, 768 },
		}
	}
	--　HUMAN　人間弾　青
	EvaNewShotData{
		id = 747
		,delay_color = {32,32,255}
		,render = EVA_BLEND_ALPHA
		,collision = 5
		,fixed_angle = true
		,AnimationData = {
			{4,   0, 704,  32, 736 },
			{4,  32, 704,  64, 736 },
			{4,  64, 704,  96, 736 },
			{4,  96, 704, 128, 736 },
		}
	}
	--　FROG　蛙弾　水色
	EvaNewShotData{
		id = 750
		,delay_color = {32,255,255}
		,render = EVA_BLEND_ALPHA
		,collision = 5
		,fixed_angle = true
		,AnimationData = {
			{4,   0, 768,  32, 800 },
			{4,  32, 768,  64, 800 },
			{4,  64, 768,  96, 800 },
			{4,  96, 768, 128, 800 },
		}
	}
	--　BIRD　鳥弾　橙
	EvaNewShotData{
		id = 751
		,delay_color = {255,128,32}
		,render = EVA_BLEND_ALPHA
		,collision = 5
		,AnimationData = {
			{4, 128, 736, 160, 768 },
			{4, 160, 736, 192, 768 },
			{4, 192, 736, 224, 768 },
			{4, 224, 736, 256, 768 },
		}
	}


    return data