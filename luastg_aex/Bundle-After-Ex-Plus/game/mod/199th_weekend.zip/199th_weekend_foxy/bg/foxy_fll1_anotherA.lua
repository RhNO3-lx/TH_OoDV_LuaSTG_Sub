﻿LoadImageFromFile('image:'..'st7','199th_weekend_foxy\\bg\\st7.png',true,0,0,false,0)
fll1_anotherA = Class(background)
fll1_anotherA.init = function(self)
    background.init(self, false)
    Set3D("eye", 0.5,3.42,0)
    Set3D("at", 0.5,0.50,1.22)
    Set3D("up", 0,1,0)
    Set3D("z", 0.4,6)
    Set3D("fovy", 0.41)
    Set3D("fog", 0,0,Color(255, 0, 0, 0))
	self.zos=0
	self.speed=0.004
end
fll1_anotherA.frame = function(self)
    self.zos=self.zos+self.speed
	Set3D("at", 0.5+0.05*sin(self.timer/2),0.50,1.22)
end
fll1_anotherA.render = function(self)
    SetViewMode'3d'
    background.WarpEffectCapture()
    --[[ Start code here ]]
	local x=self.zos%1
	for i=0,3 do
    Render4V("image:st7", 0,0,1-x+i
                          , 1,0,1-x+i
                          , 1,0,0-x+i
                          , 0, 0, 0-x+i)
	end
	for i=0,3 do
	Render4V("image:st7", -1,0,1-x+i
                          , 0,0,1-x+i
                          , 0,0,0-x+i
                          , -1, 0, 0-x+i)
	end
	for i=0,3 do
	Render4V("image:st7", 1,0,1-x+i
                          , 2,0,1-x+i
                          , 2,0,0-x+i
                          , 1, 0, 0-x+i)
	end
    background.WarpEffectApply()
    SetViewMode'world'
end