--||||||||||||| 3D Background Sprite ||||||||||||||
local bg = Class(object)

function bg:init(texture, layer, x, y)
    self.x = x
    self.y = y
    self.z = 0
    self.layer = layer
    self.group = GROUP_GHOST
    self.bound = false
    --|||||||||||||||||||||||||
    self.texture = texture
    self.dest   = {0, 0, 0, 0}
    self.source = {0, 0, 0, 0}
    self.blend  = EVA_BLEND_ALPHA
    self.alpha  = 255
    self.R      = 255
    self.G      = 255
    self.B      = 255
    self.angleX = 0
    self.angleY = 0
    self.angleZ = 0
    self.scaleX = 1
    self.scaleY = 1
    self.scaleZ = 0
end

function bg:frame()
    task.Do(self)
end

function bg:render()
    if(not self.texture)then return end
    local color = Color(self.alpha, self.R, self.G, self.B)
    local x = self.x
    local y = self.y
    local z = self.z
    local angleX = self.angleX
    local angleY = self.angleY
    local angleZ = self.angleZ
    local dest = {
        self.dest[1] * self.scaleX, self.dest[2]* self.scaleY,
        self.dest[3]* self.scaleX, self.dest[4]* self.scaleY}
    local source = self.source
    SetViewMode("3d")
    EvaDrawRectA3(self.texture, dest, source, self.blend, color, x, y, z, angleX, angleY, angleZ)
    SetViewMode("world")
end

function EvaSimpleSprite3D(texture, layer, x, y)
    return New(bg, texture, layer, x, y)
end