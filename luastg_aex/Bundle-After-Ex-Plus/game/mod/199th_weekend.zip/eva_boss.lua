local wisys = DoFile("eva_patchouli_anim.lua")

local wait = task.Wait
local scRing

local function CastCardEx(self, name)
    local b = self.boss
    self:setIsSpellcard(true)
    self:setSCName(name)
    self:resetBonus()
    --New(spell_card_ef)
    EvaCallSE(EVA_SE_USE_SPELL, 2.0)
    b.card_timer = -1
    if IsValid(b._sc_name_obj) then
        Kill(b._sc_name_obj)
    end
    local last = New(boss.sc_name, b, name)
    b._sc_name_obj = last
    _connect(b, last, 0, true)
end

function EvaBossBasicAttr(self)
    local sys = self._bosssys
    sys.aura = nil --绞杀默认魔法阵
    sys.sc_ring = nil --绞杀默认符卡环
    sys.castcard = CastCardEx

    self._wisys = wisys(self) --绞杀默认行走动画系统  
    self.aura_alpha_d = -255 --不显示默认扭曲效果
end

function EvaCallSCRing(obj, t)
    return New(scRing, obj, t)
end

scRing = Class(object)

function scRing:init(target, t)
    self.target = target
    self.x = target.x
    self.y = target.y
    self.z = 0
    self.group = GROUP_GHOST
    self.bound = false
    self.layer = LAYER_ENEMY - 5
    self.blend = EVA_BLEND_ADD_ARGB
    --|||||||||||||||||||||||||
    self.time = t * 60
    self.alpha = 255
    self.texture = "eva_MagicCircle"
    self.angle = 0
    self.maxRadius = 256 * 1.2
    self.innerR = 0
    self.outerR = 0
    self.loop = 4
    self.cut = 32
    self.countdown = self.time
    self.count = 0
end

function scRing:frame()
    if not IsValid(self.target) then Del(self) return end
    if self.countdown == 0 then Del(self) return end

    self.x = self.x + (self.target.x - self.x)*0.15
    self.y = self.y + (self.target.y - self.y)*0.15

    self.angle = self.angle - 360 / (self.cut * 2 + 2) / 3

    local rRate = self.countdown/self.time
    local dR = (self.maxRadius * rRate - self.outerR)/16
    self.outerR = self.outerR + dR

    if(self.count > 45) then
        local rRateIn = rRate - 0.06;
        rRateIn = max(rRateIn, 0)
        dR = (self.maxRadius * rRateIn - self.innerR) / 64
        self.innerR = self.innerR + dR
    end
    self.countdown = max(self.countdown - 1, 0)
    self.count = self.count + 1
end

function scRing:render()
    local color = Color(255, 95, 95, 95)
    local x1, y1, x2, y2, x3, y3, x4, y4
    local cosA, sinA, cosB, sinB
    local r1 = self.innerR
    local r2 = self.outerR
    local us, vs = 1024 * self.loop, 64
    for i = 0, self.cut - 1 do
        cosA = cos(self.angle + i * (360/self.cut))
        sinA = sin(self.angle + i * (360/self.cut))
        cosB = cos(self.angle + (i+1) * (360/self.cut))
        sinB = sin(self.angle + (i+1) * (360/self.cut))
        x1 = self.x + r1 * cosA
        y1 = self.y + r1 * sinA
        x2 = self.x + r1 * cosB
        y2 = self.y + r1 * sinB
        x3 = self.x + r2 * cosB
        y3 = self.y + r2 * sinB
        x4 = self.x + r2 * cosA
        y4 = self.y + r2 * sinA
        RenderTexture(self.texture, self.blend,
        {x1, y1, 0, (us/self.cut) * i,          vs, color},
        {x2, y2, 0, (us/self.cut) * (i + 1),    vs, color},
        {x3, y3, 0, (us/self.cut) * (i + 1),    0, color},
        {x4, y4, 0, (us/self.cut) * i,          0, color})
    end
end

local EvaBarrierRing
local EvaBarrierAI
local EvaBarrierColor


function EvaBarrierEffect(colorTime, cRate)
    local objEnemy = _boss
	local flag = true
    EvaTask(function()
        while(IsValid(objEnemy) and not EvaIsTimeOut())do
            if(not objEnemy.colli)then
                if(flag)then
                    EvaSetBossAlpha(objEnemy,127)
                    EvaBarrierRing(objEnemy, colorTime, cRate, 80, 0, 1, 90, 0.6)
                    EvaBarrierRing(objEnemy, colorTime, cRate, 80, 90, 1, 0, 0.6)
                    flag = false
                end
            else
                EvaSetBossAlpha(objEnemy, 255)
                flag = true
            end
            task.Wait()
        end
	end)
end

function EvaBarrierRing(objE, color, cRate, rMax, aY, aYRate, aZ, aZRate)
    local i = 1
    local A_R = 0
    local A_G = 0
    local A_B = 0
    local r = 0

    EvaTask(function()
        while(not objE.colli)do
            r = rMax*sin(min(90, i*3))
            A_R, A_G, A_B = EvaBarrierColor(color%360)
            if(i%2 == 0)then
                EvaBarrierAI(objE, r, aY, aZ, A_R, A_G, A_B)
            end
            aY = aY + aYRate
            aZ = aZ + aZRate
            color = color + cRate
            i = i + 1
            task.Wait()
        end
        for _ = 19, 0, -1 do
            r = rMax*sin(90*i/20)
            Color(color%360)
            if(i%2 == 0)then
                EvaBarrierAI(objE, r, aY, aZ, A_R, A_G, A_B)
            end
            aY = aY + aYRate
            aZ = aZ + aZRate
            color = color + cRate
            i = i + 1
            task.Wait()
        end
    end)
end

function EvaBarrierAI(objE, r, aY, aZ, A_R, A_G, A_B)
    local obj = EvaSimpleSprite2D("eva_barrierRing", LAYER_ENEMY + 1, 0, 0)
    task.New(obj, function()
        EvaSetBlendType(obj, EVA_BLEND_ADD_ARGB)
        EvaSetSourceRect(obj, 0, 0, 256, 255)
        EvaSetDestRect(obj, -r, -r, r, r)
        EvaSetAlpha(obj, 255)
        EvaSetScaleXYZ(obj, 1, 1*sin(aY), 1)
        EvaSetAngleXYZ(obj, 0, 0, aZ)
        EvaSetPosition(obj, EvaGetX(objE), EvaGetY(objE), 0)
        for i = 12, 1, -1 do
            EvaSetColor(obj, A_R*i/18, A_G*i/18, A_B*i/18)
            task.Wait()
        end
        Del(obj)
    end)
end

function EvaBarrierColor(time)
    local A_R = 0
    local A_G = 0
    local A_B = 0
    local val = int(time/60)
    if(val == 0)then
        A_R = 127
        A_G = 127*time/60
        A_B = 0
    elseif(val == 1)then
        A_R = 127*(120-time)/60
        A_G = 127
        A_B = 0
    elseif(val == 2)then
        A_R = 0
        A_G = 127
        A_B = 127*(time-120)/60
    elseif(val == 3)then
        A_R = 0
        A_G = 127*(240-time)/60
        A_B = 127
    elseif(val == 4)then
        A_R = 127*(time-240)/60
        A_G = 0
        A_B = 127
    elseif(val == 5)then
        A_R = 127
        A_G = 0
        A_B = 127*(360-time)/60
    end
    return A_R, A_G, A_B
end


function EvaBossFinalize(obj)
    if(IsValid(obj.hpHelper))then
        Del(obj.hpHelper.text)
        Del(obj.hpHelper)
    end
    if(IsValid(obj.scRing))then
        Del(obj.scRing)
    end
    New(bullet_cleaner,obj.x, obj.y, 1280, 15, 30, true, true, 0)
end

local EvaCreateCircle
local EvaStartCircle
local EvaRenderCircle

local angleZ = 0 --多boss的时候共享角度Z
local angleX = 0--多boss的时候共享角度X
local angleY = 0 --多boss的时候共享角度Y
local is_Shared = false

function EvaSetMagicCircle(objE)
    local objC = {}
    local Scale = 0

    local local_is_Shared = is_Shared
    is_Shared = true

    function RenderCircle()
        local ex = EvaGetX(objE)
        local ey = EvaGetY(objE)
        angleZ = angleZ + 1.5
        angleX = angleX + 0.15
        angleY = angleY + 0.09
        for i = 1, #objC do
            EvaSetPosition(objC[i], ex, ey, 0)
            EvaSetAngleXYZ(objC[i], angleX+90*(i - 1), angleY+90*(i - 1), angleZ)
            EvaSetScaleXYZ(objC[i], Scale, Scale, 1.0)
        end
    end

    function EvaStartCircle()
        EvaTask(function()
            for i = 1, 90 do
                if(#objC <= 0) then return end
                Scale = sin(90*i/90)
                if(not local_is_Shared) then
                    angleZ = angleZ + 6.0*(1-i/90)
                end
                wait()
            end
        end)
    end

    objC[1] = EvaCreateCircle()
    objC[2] = EvaCreateCircle()

    objE.objC = objC

    EvaStartCircle()
    EvaTask(function()
        while IsValid(objE) do
            EvaRenderCircle(objE, objC, Scale)
            wait()
        end
        for i = 1, #objC do
            Del(objC[i])
        end
        EvaStopCircle()
    end)
end

function EvaStopCircle()
    is_Shared = false
    angleX = 0
    angleY = 0
    angleZ = 0
end

function EvaCreateCircle()
    local objC = EvaSimpleSprite2D_A("eva_Hexagram", LAYER_ENEMY - 3, 0, 0)
    EvaSetBlendType(objC, EVA_BLEND_ADD_ARGB)
    EvaSetSourceRect(objC, 0, 0, 256, 256)
    EvaSetDestRect(objC, -128, -128, 128, 128)
    EvaSetAlpha(objC, 95)
    return objC
end

function EvaRenderCircle(objE, objC, Scale)
    local ex = EvaGetX(objE)
    local ey = EvaGetY(objE)
    angleZ = angleZ + 1.5
    angleX = angleX + 0.15
    angleY = angleY + 0.09
    for i = 1, #objC do
        EvaSetPosition(objC[i], ex, ey, 0);
        EvaSetAngleXYZ(objC[i], angleX+90*i, angleY+90*i, angleZ);
        EvaSetScaleXYZ(objC[i], Scale, Scale, 1.0)
    end
end